# Lagiah Vercel Deployment Instructions

## Quick Setup

### 1. Setup Vercel Account
1. Go to https://vercel.com
2. Sign up with GitHub account
3. Verify email

### 2. Deploy Backend
1. Click "New Project"
2. Connect GitHub repository: lagiah
3. Configure:
   ```
   Framework Preset: Next.js
   Root Directory: backend
   Build Command: npm run build
   Output Directory: .next
   Install Command: npm install
   ```

### 3. Environment Variables
Add these in Vercel dashboard:
```env
NODE_ENV=production
DATABASE_URL=postgresql://username:password@host:5432/database
JWT_SECRET=your-super-secret-jwt-key
NEXTAUTH_SECRET=your-nextauth-secret
NEXTAUTH_URL=https://your-backend.vercel.app
```

### 4. Database Setup (External)
Vercel tidak menyediakan database, jadi gunakan:

#### Option A: Neon (Recommended)
1. Go to https://neon.tech
2. Sign up and create project
3. Copy connection string
4. Update DATABASE_URL in Vercel

#### Option B: Supabase
1. Go to https://supabase.com
2. Create new project
3. Copy connection string
4. Update DATABASE_URL in Vercel

#### Option C: Railway PostgreSQL
1. Go to https://railway.app
2. Create PostgreSQL database
3. Copy connection string
4. Update DATABASE_URL in Vercel

### 5. Deploy
1. Click "Deploy"
2. Wait for build to complete (2-5 minutes)

### 6. Test Deployment
```bash
curl https://your-backend.vercel.app/api/v1/health
```

## Frontend Deployment

### Option 1: Vercel Static Site (Recommended)
1. In Vercel dashboard, click "New Project"
2. Connect GitHub repository: lagiah
3. Configure:
   - Framework Preset: Vite
   - Root Directory: frontend
   - Build Command: npm run build
   - Output Directory: dist
4. Add environment variable:
   - `VITE_API_BASE_URL=https://your-backend.vercel.app/api/v1`

### Option 2: LiteSpeed Shared Hosting
1. Upload frontend files to shared hosting
2. Update API URL in environment
3. Configure .htaccess for SPA routing

## File Structure
```
lagiah-vercel-YYYYMMDD_HHMMSS/
├── index.html              # Frontend files
├── assets/
├── api/                    # Backend files
│   ├── .next/
│   ├── prisma/
│   ├── package.json
│   └── next.config.js
├── .env.example
└── VERCEL_DEPLOYMENT_INSTRUCTIONS.md
```

## Vercel Free Tier Limits
- **Projects**: Unlimited
- **Bandwidth**: 100 GB/month
- **Function Execution**: 100 GB-hours/month
- **Build Time**: 6000 minutes/month
- **Edge Functions**: 500,000 invocations/month

## Troubleshooting
- Check build logs in Vercel dashboard
- Verify environment variables
- Test database connectivity
- Review function logs

## URLs
- Backend: https://your-backend.vercel.app
- Frontend: https://your-frontend.vercel.app
- Health Check: https://your-backend.vercel.app/api/v1/health

## Advantages of Vercel
✅ Excellent Next.js support
✅ Global CDN
✅ Automatic deployments
✅ Great performance
✅ Edge functions
✅ Free tier is generous
✅ No cold starts for paid plans
