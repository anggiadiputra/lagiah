-- AlterTable
ALTER TABLE `domains` ADD COLUMN `renewalPrice` DOUBLE NULL;
