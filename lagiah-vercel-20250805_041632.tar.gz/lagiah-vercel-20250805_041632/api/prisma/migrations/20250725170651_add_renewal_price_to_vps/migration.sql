-- AlterTable
ALTER TABLE `vps` ADD COLUMN `renewalPrice` DOUBLE NULL;
