# 🚀 Lagiah Production Deployment Guide

## 📋 Overview
This zip file contains the complete Lagiah Domain Management System ready for production deployment.

## 📁 Contents
```
lagiah-production/
├── 📁 backend/                 # Next.js API
│   ├── 📁 src/                # Source code
│   ├── 📁 prisma/             # Database schema
│   ├── 📁 scripts/            # Production scripts
│   ├── 📄 Dockerfile          # Production ready
│   └── 📄 env.production.example
├── 📁 frontend/               # Vue.js application
│   ├── 📁 src/                # Source code
│   ├── 📁 public/             # Static assets
│   ├── 📄 Dockerfile          # Production ready
│   ├── 📄 nginx.conf          # Production ready
│   └── 📄 env.production.example
├── 📁 scripts/                # Deployment scripts
├── .github/workflows/      # CI/CD configuration
├── 📄 README.md               # Main documentation
├── 📄 LICENSE                 # MIT License
├── docker-compose.prod.yml # Production ready
├── 📄 nginx.conf              # Production ready
└── 📄 env.production.example  # Production environment
```

## 🚀 Quick Deployment Options

### 1. Docker Deployment (Recommended)
```bash
# Extract the zip file
unzip lagiah-production.zip
cd lagiah-production

# Setup environment
cp env.production.example .env.production
# Edit .env.production with your configuration

# Deploy with Docker Compose
docker-compose -f docker-compose.prod.yml up -d
```

### 2. VPS Deployment (Without Docker)
```bash
# Extract the zip file
unzip lagiah-production.zip
cd lagiah-production

# Run VPS deployment script
chmod +x scripts/vps-deploy-no-docker.sh
./scripts/vps-deploy-no-docker.sh
```

### 3. Shared Hosting (cPanel)
```bash
# Extract the zip file
unzip lagiah-production.zip
cd lagiah-production

# Run shared hosting deployment script
chmod +x scripts/shared-hosting-deploy.sh
./scripts/shared-hosting-deploy.sh
```

## 📚 Detailed Documentation

### Deployment Guides:
- **VPS_DEPLOYMENT_GUIDE.md** - Complete VPS deployment with Docker
- **VPS_DEPLOYMENT_NO_DOCKER.md** - VPS deployment without Docker
- **SHARED_HOSTING_DEPLOYMENT.md** - Shared hosting deployment
- **CPANEL_NODEJS_DEPLOYMENT.md** - cPanel Node.js deployment
- **DEPLOYMENT.md** - General deployment documentation

### Quick Start Guides:
- **VPS_QUICK_START.md** - Quick VPS deployment
- **VPS_QUICK_START_NO_DOCKER.md** - Quick VPS without Docker
- **SHARED_HOSTING_QUICK_START.md** - Quick shared hosting

## 🔧 Environment Setup

### Required Environment Variables:
```bash
# Database
DATABASE_URL="mysql://user:password@localhost:3306/lagiah"

# Authentication
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="https://yourdomain.com"

# API Keys
WHOIS_API_URL="https://api.whois.com/v1"
WHOIS_API_KEY="your-whois-api-key"
WHATSAPP_API_URL="https://api.whatsapp.com"
WHATSAPP_API_KEY="your-whatsapp-api-key"

# Security
JWT_SECRET="your-jwt-secret"
ENCRYPTION_KEY="your-32-char-encryption-key"
```

## 🌐 Access Information

### Default Login:
- **Email**: admin@lagiah.com
- **Password**: admin123

### URLs:
- **Frontend**: http://localhost:5178 (dev) / https://yourdomain.com (prod)
- **Backend API**: http://localhost:3004 (dev) / https://yourdomain.com/api (prod)

## 🔒 Security Features

- ✅ JWT token authentication
- ✅ Role-based access control (Admin, Staff, Viewer, Finance)
- ✅ Password encryption with bcrypt
- ✅ API rate limiting
- ✅ CORS protection
- ✅ SSL/HTTPS support
- ✅ SQL injection prevention
- ✅ XSS protection

## 📊 System Requirements

### Minimum Requirements:
- **Node.js**: 18+
- **MySQL**: 8.0+ or MariaDB 10.5+
- **Redis**: 7+ (optional, for caching)
- **Memory**: 2GB RAM
- **Storage**: 10GB free space

### Recommended Requirements:
- **Node.js**: 20+
- **MySQL**: 8.0+
- **Redis**: 7+
- **Memory**: 4GB RAM
- **Storage**: 20GB free space

## 🆘 Support

If you encounter any issues:

1. Check the detailed documentation in the respective `.md` files
2. Verify environment variables are correctly set
3. Check system requirements
4. Review logs for error messages

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

**Made with ❤️ by the Lagiah Team** 