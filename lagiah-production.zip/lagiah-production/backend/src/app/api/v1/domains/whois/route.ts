import { NextRequest } from 'next/server'
import { successResponse, errorResponse } from '@/lib/utils'
import { withApiMiddleware, withMethods, withRoles } from '@/middleware/api-middleware'
import { fetchWhoisData, getDomainExpirationStatus } from '@/lib/services/whois'
import { z } from 'zod'

// Validation schema for domain lookup
const whoisLookupSchema = z.object({
  domain: z.string().min(3, 'Domain name must be at least 3 characters'),
})

/**
 * Simple check if domain is available by attempting to fetch Whois data
 */
async function isDomainAvailable(domain: string): Promise<boolean> {
  try {
    const whoisData = await fetchWhoisData(domain)
    return whoisData === null
  } catch (error) {
    console.error(`Error checking domain availability for ${domain}:`, error)
    return false
  }
}

/**
 * POST /api/v1/domains/whois
 * Fetch Whois data for a domain manually
 */
async function lookupWhoisData(req: NextRequest) {
  const body = await req.json()
  
  // Validate request body
  const result = whoisLookupSchema.safeParse(body)
  if (!result.success) {
    return errorResponse('Invalid domain name', 'VALIDATION_ERROR', 400, result.error.issues)
  }
  
  const { domain } = result.data
  
  console.log(`Manual Whois lookup requested for: ${domain}`)
  
  try {
    // Check if domain is available first
    const isAvailable = await isDomainAvailable(domain)
    
    if (isAvailable) {
      return successResponse({
        domain,
        isAvailable: true,
        message: 'Domain is available for registration',
        data: null
      })
    }
    
    // Fetch detailed Whois data
    const whoisResult = await fetchWhoisData(domain)
    
    if (!whoisResult || !whoisResult.data) {
      return errorResponse(
        'Unable to fetch Whois data for this domain. The domain may not exist or the Whois service is unavailable.',
        'WHOIS_UNAVAILABLE',
        404
      )
    }
    
    const whoisData = whoisResult.data
    
    return successResponse({
      domain,
      isAvailable: false,
      message: 'Whois data retrieved successfully',
      data: {
        registrar: whoisData.registrar,
        registeredAt: whoisData.registeredAt,
        expiresAt: whoisData.expiresAt,
        nameservers: whoisData.nameservers,
        status: whoisData.status,
        // Include sanitized version of full whois data
        whoisInfo: whoisData.whoisData ? {
          registrantName: whoisData.whoisData.registrantName,
          registrantOrganization: whoisData.whoisData.registrantOrganization,
          adminEmail: whoisData.whoisData.adminEmail,
          techEmail: whoisData.whoisData.techEmail,
          status: whoisData.whoisData.status,
        } : null,
        // Add frontend-expected properties
        fetchedAt: new Date().toISOString(),
        updated_date: whoisData.registeredAt?.toISOString(),
        dnssec: whoisData.whoisData?.DNSSEC || 'unsigned',
        source: 'indexof.id',
        // Include raw WHOIS data for frontend access
        'Domain ID': whoisData.whoisData?.data?.['Domain ID'] || whoisData.whoisData?.['Domain ID'] || 'N/A',
        'Domain Name': whoisData.whoisData?.data?.['Domain Name'] || whoisData.whoisData?.['Domain Name'] || domain,
        'Created On': whoisData.whoisData?.data?.['Created On'] || whoisData.whoisData?.['Created On'] || whoisData.registeredAt?.toISOString(),
        'Last Update On': whoisData.whoisData?.data?.['Last Update On'] || whoisData.whoisData?.['Last Update On'] || whoisData.registeredAt?.toISOString(),
        'Expiration Date': whoisData.whoisData?.data?.['Expiration Date'] || whoisData.whoisData?.['Expiration Date'] || whoisData.expiresAt?.toISOString(),
        'Status': whoisData.whoisData?.data?.Status || whoisData.whoisData?.Status || whoisData.status,
        'Registrar Name': whoisData.whoisData?.data?.['Registrar Name'] || whoisData.whoisData?.['Registrar Name'] || whoisData.registrar,
        'DNSSEC': whoisData.whoisData?.data?.DNSSEC || whoisData.whoisData?.DNSSEC || 'unsigned',
        // Include nameservers in the expected format
        ...Object.fromEntries(
          Object.entries(whoisData.whoisData?.data || whoisData.whoisData || {})
            .filter(([key]) => key.startsWith('Nameserver '))
        )
      }
    })
    
  } catch (error) {
    console.error(`Error during Whois lookup for ${domain}:`, error)
    return errorResponse(
      'Failed to fetch Whois data. Please try again later.',
      'WHOIS_ERROR',
      500
    )
  }
}

// Export handler with middleware
export const POST = withApiMiddleware(
  withMethods(['POST'], 
    withRoles(['ADMIN', 'STAFF', 'FINANCE', 'VIEWER'], lookupWhoisData)
  )
) 