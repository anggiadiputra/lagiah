import { NextRequest } from 'next/server'
import { prisma } from '@/lib/database'
import { successResponse, errorResponse, getUserFromHeaders } from '@/lib/utils'
import { withApiMiddleware, withMethods, withRoles } from '@/middleware/api-middleware'
import { createDomainSchema, paginationSchema, sortSchema } from '@/lib/validation/schemas'
import { DomainStatus } from '@/generated/prisma'
import { fetchWhoisData, getDomainExpirationStatus } from '@/lib/services/whois'
import { Prisma } from '@/generated/prisma'

/**
 * GET /api/v1/domains
 * Get all domains with pagination and filtering
 */
async function getDomains(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const page = Number(url.searchParams.get('page') || '1')
    const limit = Number(url.searchParams.get('limit') || '10')
    const sortParam = url.searchParams.get('sort') || 'createdAt'
    const orderParam = url.searchParams.get('order') || 'desc'
    const statusParam = url.searchParams.get('status')
    const registrarParam = url.searchParams.get('registrar')
    const search = url.searchParams.get('search')
    
    // Parse sort parameter - handle both "field:order" format and separate parameters
    let sort = sortParam
    let order = orderParam
    
    if (sortParam.includes(':')) {
      const [sortField, sortOrder] = sortParam.split(':')
      sort = sortField
      order = sortOrder
    }
    
    console.log('Parsed sorting:', { sort, order })
    
    // Validate pagination and sorting
    const paginationResult = paginationSchema.safeParse({ page, limit })
    const sortResult = sortSchema.safeParse({ sort, order })
    
    if (!paginationResult.success) {
      return errorResponse('Invalid pagination parameters', 'VALIDATION_ERROR', 400)
    }
    
    if (!sortResult.success) {
      return errorResponse('Invalid sorting parameters', 'VALIDATION_ERROR', 400)
    }
    
    // Get user from headers
    const user = getUserFromHeaders(req.headers)
    console.log('User from headers:', user)
    
    // Convert status string to enum if provided
    const status = statusParam as DomainStatus | undefined
    
    // Build query - simplified approach without search for now
    const where: any = {}
    
    // Add status filter if provided
    if (status) {
      where.status = status
    }
    
    // Add registrar filter if provided
    if (registrarParam) {
      where.registrar = registrarParam
    }
    
    // Temporarily disable search to isolate the issue
    // if (search && search.trim()) {
    //   where.name = {
    //     contains: search.trim(),
    //     mode: 'insensitive'
    //   }
    // }
    
    console.log('Search parameter:', search)
    console.log('Where clause:', JSON.stringify(where, null, 2))
    
    console.log('Query where clause:', where)
    
    // Get total count
    const total = await prisma.domain.count({ where })
    console.log('Total domains found:', total)
    
    // Get domains with error handling
    let domains: any[] = []
    try {
      domains = await prisma.domain.findMany({
        where,
        orderBy: {
          [sort]: order,
        },
        skip: (page - 1) * limit,
        take: limit,
        select: {
          id: true,
          name: true,
          registrar: true,
          status: true,
          registeredAt: true,
          expiresAt: true,
          nameservers: true,
          whoisData: true,
          notes: true,

          isMainDomain: true,
          domainHosting: true,
          createdAt: true,
          updatedAt: true,
          createdBy: true,
          hostingId: true,
          vpsId: true,
          hosting: {
            select: {
              id: true,
              name: true,
              provider: true,
            },
          },
          vps: {
            select: {
              id: true,
              name: true,
              provider: true,
            },
          },
          websites: {
            select: {
              id: true,
              name: true,
              url: true,
              status: true,
            },
          },
        },
      })
    } catch (dbError) {
      console.error('Database query error:', dbError)
      console.error('Error details:', {
        message: dbError instanceof Error ? dbError.message : 'Unknown error',
        stack: dbError instanceof Error ? dbError.stack : undefined
      })
      
      // Return empty result instead of throwing
      domains = []
      console.log('Returning empty result due to database error')
    }
    
    console.log('Domains fetched:', domains.length)
    
    return successResponse({
      items: domains,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error fetching domains:', error)
    
    // Log more details for debugging
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      console.error('Prisma error code:', error.code)
      console.error('Prisma error message:', error.message)
    }
    
    return errorResponse(
      'An error occurred while fetching domains',
      'INTERNAL_SERVER_ERROR',
      500
    )
  }
}

/**
 * POST /api/v1/domains
 * Create a new domain, with intelligent Whois data integration.
 */
async function createDomain(req: NextRequest) {
  console.log('[CreateDomain] Received request');
  try {
    const body = await req.json();
    console.log('[CreateDomain] Parsed body:', body);

    const result = createDomainSchema.safeParse(body);
    if (!result.success) {
      console.error('[CreateDomain] Validation failed:', result.error.flatten());
      return errorResponse('Invalid data', 'VALIDATION_ERROR', 400, result.error.flatten());
    }
    console.log('[CreateDomain] Validation successful');
    const { name, hostingId, ...domainInput } = result.data;
    console.log('[CreateDomain] Parsed data:', { name, hostingId, domainInput });


    const user = getUserFromHeaders(req.headers);
    console.log(`[CreateDomain] Authenticated user: ${user.email}`);

    console.log(`[CreateDomain] Checking for existing domain: ${name}`);
    const existingDomain = await prisma.domain.findUnique({ where: { name } });
    if (existingDomain) {
      console.warn(`[CreateDomain] Domain ${name} already exists.`);
      return errorResponse('Domain already exists', 'CONFLICT', 409);
    }

    console.log(`[CreateDomain] Fetching Whois for ${name}`);
    const whoisResult = await fetchWhoisData(name);
    const whoisData = whoisResult.data;
    console.log(`[CreateDomain] Whois fetch completed. Data found: ${!!whoisData}`);

    const dataToCreate: Prisma.DomainCreateInput = {
      name: name,
      user: {
        connect: { id: user.id }
      },
      status: domainInput.status || (whoisData?.status) || 'ACTIVE',
    };

    if (domainInput.registrar || whoisData?.registrar) {
      dataToCreate.registrar = domainInput.registrar || whoisData?.registrar;
    }

    if (domainInput.notes) {
      dataToCreate.notes = domainInput.notes;
    }

    if (domainInput.registeredAt) {
      dataToCreate.registeredAt = new Date(domainInput.registeredAt);
    } else if (whoisData?.registeredAt) {
      dataToCreate.registeredAt = new Date(whoisData.registeredAt);
    }
    if (domainInput.expiresAt) {
      dataToCreate.expiresAt = new Date(domainInput.expiresAt);
    } else if (whoisData?.expiresAt) {
      dataToCreate.expiresAt = new Date(whoisData.expiresAt);
    }
    if (domainInput.nameservers) {
      dataToCreate.nameservers = domainInput.nameservers;
    } else if (whoisData?.nameservers) {
      dataToCreate.nameservers = whoisData.nameservers;
    }
    if (whoisData?.whoisData) {
      dataToCreate.whoisData = { ...whoisData.whoisData, fetchedAt: new Date().toISOString() };
    }
    if (hostingId) {
      dataToCreate.hosting = { connect: { id: hostingId } };
    }
    
    console.log('[CreateDomain] Attempting to create in DB with data:', JSON.stringify(dataToCreate, null, 2));

    try {
      const newDomain = await prisma.domain.create({
        data: dataToCreate,
        include: { hosting: { select: { id: true, name: true } } },
      });
      console.log(`[CreateDomain] DB creation successful. ID: ${newDomain.id}`);
      
      // Activity Log can be added here
      
      return successResponse({ ...newDomain, whoisIntegrated: !!whoisData }, 201);
    } catch (dbError: any) {
      console.error('[CreateDomain] DATABASE ERROR:', dbError);
      return errorResponse(`Database Error: ${dbError.code || 'Unknown'}`, 'DATABASE_ERROR', 500, {
        message: dbError.message,
        meta: dbError.meta,
      });
    }
  } catch (error: any) {
    console.error('[CreateDomain] UNHANDLED ERROR:', error);
    return errorResponse('An unexpected server error occurred.', 'INTERNAL_SERVER_ERROR', 500);
  }
}

// Export handler with middleware
export const GET = withApiMiddleware(
  withMethods(['GET'], 
    withRoles(['ADMIN', 'STAFF', 'FINANCE', 'VIEWER'], getDomains)
  )
)

export const POST = withApiMiddleware(
  withMethods(['POST'], 
    withRoles(['ADMIN', 'STAFF'], createDomain)
  )
) 