import { NextRequest } from 'next/server'
import { prisma } from '@/lib/database'
import { successResponse, errorResponse } from '@/lib/utils'
import { verifyJwtToken, getTokenFromHeader } from '@/lib/auth/jwt'

export async function GET(req: NextRequest) {
  try {
    // Get token from Authorization header
    const authHeader = req.headers.get('authorization')
    console.log('Auth header:', authHeader)
    const token = getTokenFromHeader(authHeader)
    console.log('Extracted token:', token ? token.substring(0, 10) + '...' : 'null')
    
    if (!token) {
      console.log('No token found in header')
      return errorResponse('Unauthorized', 'UNAUTHORIZED', 401)
    }
    
    // Verify and decode JWT token (synchronous)
    const decoded = verifyJwtToken(token)
    console.log('Token verification result:', decoded ? 'success' : 'failed')
    
    if (!decoded || !decoded.id) {
      console.log('Invalid token or missing ID in token')
      return errorResponse('Invalid token', 'INVALID_TOKEN', 401)
    }
    
    // Get user from database
    console.log('Looking up user with ID:', decoded.id)
    const user = await prisma.user.findUnique({
      where: { id: decoded.id },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
      },
    })
    
    if (!user) {
      console.log('User not found in database')
      return errorResponse('User not found', 'USER_NOT_FOUND', 404)
    }
    
    console.log('User found:', user.email)
    
    // Get recent activity
    const recentActivity = await prisma.activityLog.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: {
        action: true,
        entity: true,
        description: true,
        createdAt: true,
      },
    })
    
    return successResponse({
      user,
      recentActivity,
    })
  } catch (error) {
    console.error('Error fetching user profile:', error)
    return errorResponse('Failed to fetch user profile', 'PROFILE_ERROR', 500)
  }
} 