# Lagiah Render Deployment Instructions

## Quick Setup

### 1. Setup Render Account
1. Go to https://render.com
2. Sign up with GitHub account
3. Verify email

### 2. Create Web Service
1. Click "New +" → "Web Service"
2. Connect GitHub repository
3. Select repository: lagiah

### 3. Configure Service
```
Name: lagiah-backend
Environment: Node
Region: Singapore (or nearest)
Branch: main
Root Directory: backend
Build Command: npm install && npm run build
Start Command: npm start
```

### 4. Environment Variables
Add these in Render dashboard:
```env
NODE_ENV=production
PORT=10000
DATABASE_URL=postgresql://username:password@host:5432/database
JWT_SECRET=your-super-secret-jwt-key
NEXTAUTH_SECRET=your-nextauth-secret
NEXTAUTH_URL=https://your-backend.onrender.com
```

### 5. Create PostgreSQL Database
1. In Render dashboard, click "New +" → "PostgreSQL"
2. Choose plan (Free tier for testing)
3. Copy connection string to DATABASE_URL

### 6. Deploy
1. Click "Create Web Service"
2. Wait for build to complete (5-10 minutes)

### 7. Test Deployment
```bash
curl https://your-backend.onrender.com/api/v1/health
```

## Frontend Deployment

### Option 1: Static Site (Recommended)
1. In Render dashboard, click "New +" → "Static Site"
2. Connect GitHub repository
3. Configure:
   - Build Command: `cd frontend && npm install && npm run build`
   - Publish Directory: `frontend/dist`
4. Add environment variable:
   - `VITE_API_BASE_URL=https://your-backend.onrender.com/api/v1`

### Option 2: LiteSpeed Shared Hosting
1. Upload frontend files to shared hosting
2. Update API URL in environment
3. Configure .htaccess for SPA routing

## File Structure
```
lagiah-render-YYYYMMDD_HHMMSS/
├── index.html              # Frontend files
├── assets/
├── api/                    # Backend files
│   ├── .next/
│   ├── prisma/
│   ├── package.json
│   └── next.config.js
├── .env.example
└── RENDER_DEPLOYMENT_INSTRUCTIONS.md
```

## Troubleshooting
- Check build logs in Render dashboard
- Verify environment variables
- Test database connectivity
- Review error logs

## URLs
- Backend: https://your-backend.onrender.com
- Frontend: https://your-frontend.onrender.com
- Health Check: https://your-backend.onrender.com/api/v1/health
