-- AlterTable
ALTER TABLE `websites` ADD COLUMN `password` VARCHAR(191) NULL,
    ADD COLUMN `username` VARCHAR(191) NULL;
