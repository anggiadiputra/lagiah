-- AlterTable
ALTER TABLE `domains` ADD COLUMN `domainHosting` VARCHAR(191) NULL;
