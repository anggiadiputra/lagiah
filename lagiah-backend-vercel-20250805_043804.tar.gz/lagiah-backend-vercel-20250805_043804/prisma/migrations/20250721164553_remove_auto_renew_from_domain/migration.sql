/*
  Warnings:

  - You are about to drop the column `autoRenew` on the `domains` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `domains` DROP COLUMN `autoRenew`;
