
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model Session
 * 
 */
export type Session = $Result.DefaultSelection<Prisma.$SessionPayload>
/**
 * Model Domain
 * 
 */
export type Domain = $Result.DefaultSelection<Prisma.$DomainPayload>
/**
 * Model Hosting
 * 
 */
export type Hosting = $Result.DefaultSelection<Prisma.$HostingPayload>
/**
 * Model VPS
 * 
 */
export type VPS = $Result.DefaultSelection<Prisma.$VPSPayload>
/**
 * Model Website
 * 
 */
export type Website = $Result.DefaultSelection<Prisma.$WebsitePayload>
/**
 * Model ActivityLog
 * 
 */
export type ActivityLog = $Result.DefaultSelection<Prisma.$ActivityLogPayload>
/**
 * Model Setting
 * 
 */
export type Setting = $Result.DefaultSelection<Prisma.$SettingPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const UserRole: {
  ADMIN: 'ADMIN',
  STAFF: 'STAFF',
  FINANCE: 'FINANCE',
  VIEWER: 'VIEWER'
};

export type UserRole = (typeof UserRole)[keyof typeof UserRole]


export const DomainStatus: {
  ACTIVE: 'ACTIVE',
  EXPIRED: 'EXPIRED',
  SUSPENDED: 'SUSPENDED',
  TRANSFERRED: 'TRANSFERRED',
  DELETED: 'DELETED',
  AVAILABLE_TO_ORDER: 'AVAILABLE_TO_ORDER'
};

export type DomainStatus = (typeof DomainStatus)[keyof typeof DomainStatus]


export const HostingStatus: {
  ACTIVE: 'ACTIVE',
  SUSPENDED: 'SUSPENDED',
  EXPIRED: 'EXPIRED',
  CANCELLED: 'CANCELLED',
  EXPIRING_SOON: 'EXPIRING_SOON'
};

export type HostingStatus = (typeof HostingStatus)[keyof typeof HostingStatus]


export const VPSStatus: {
  ACTIVE: 'ACTIVE',
  SUSPENDED: 'SUSPENDED',
  STOPPED: 'STOPPED',
  EXPIRED: 'EXPIRED',
  CANCELLED: 'CANCELLED'
};

export type VPSStatus = (typeof VPSStatus)[keyof typeof VPSStatus]


export const WebsiteStatus: {
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE',
  MAINTENANCE: 'MAINTENANCE',
  SUSPENDED: 'SUSPENDED'
};

export type WebsiteStatus = (typeof WebsiteStatus)[keyof typeof WebsiteStatus]


export const SSLStatus: {
  NONE: 'NONE',
  ACTIVE: 'ACTIVE',
  EXPIRED: 'EXPIRED',
  PENDING: 'PENDING'
};

export type SSLStatus = (typeof SSLStatus)[keyof typeof SSLStatus]


export const ActivityType: {
  CREATE: 'CREATE',
  READ: 'READ',
  UPDATE: 'UPDATE',
  DELETE: 'DELETE',
  LOGIN: 'LOGIN',
  LOGOUT: 'LOGOUT',
  EXPORT: 'EXPORT',
  IMPORT: 'IMPORT'
};

export type ActivityType = (typeof ActivityType)[keyof typeof ActivityType]


export const EntityType: {
  USER: 'USER',
  DOMAIN: 'DOMAIN',
  HOSTING: 'HOSTING',
  VPS: 'VPS',
  WEBSITE: 'WEBSITE',
  SETTING: 'SETTING'
};

export type EntityType = (typeof EntityType)[keyof typeof EntityType]

}

export type UserRole = $Enums.UserRole

export const UserRole: typeof $Enums.UserRole

export type DomainStatus = $Enums.DomainStatus

export const DomainStatus: typeof $Enums.DomainStatus

export type HostingStatus = $Enums.HostingStatus

export const HostingStatus: typeof $Enums.HostingStatus

export type VPSStatus = $Enums.VPSStatus

export const VPSStatus: typeof $Enums.VPSStatus

export type WebsiteStatus = $Enums.WebsiteStatus

export const WebsiteStatus: typeof $Enums.WebsiteStatus

export type SSLStatus = $Enums.SSLStatus

export const SSLStatus: typeof $Enums.SSLStatus

export type ActivityType = $Enums.ActivityType

export const ActivityType: typeof $Enums.ActivityType

export type EntityType = $Enums.EntityType

export const EntityType: typeof $Enums.EntityType

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.session`: Exposes CRUD operations for the **Session** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Sessions
    * const sessions = await prisma.session.findMany()
    * ```
    */
  get session(): Prisma.SessionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.domain`: Exposes CRUD operations for the **Domain** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Domains
    * const domains = await prisma.domain.findMany()
    * ```
    */
  get domain(): Prisma.DomainDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.hosting`: Exposes CRUD operations for the **Hosting** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Hostings
    * const hostings = await prisma.hosting.findMany()
    * ```
    */
  get hosting(): Prisma.HostingDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.vPS`: Exposes CRUD operations for the **VPS** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more VPS
    * const vPS = await prisma.vPS.findMany()
    * ```
    */
  get vPS(): Prisma.VPSDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.website`: Exposes CRUD operations for the **Website** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Websites
    * const websites = await prisma.website.findMany()
    * ```
    */
  get website(): Prisma.WebsiteDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.activityLog`: Exposes CRUD operations for the **ActivityLog** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ActivityLogs
    * const activityLogs = await prisma.activityLog.findMany()
    * ```
    */
  get activityLog(): Prisma.ActivityLogDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.setting`: Exposes CRUD operations for the **Setting** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Settings
    * const settings = await prisma.setting.findMany()
    * ```
    */
  get setting(): Prisma.SettingDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.12.0
   * Query Engine version: 8047c96bbd92db98a2abc7c9323ce77c02c89dbc
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    Session: 'Session',
    Domain: 'Domain',
    Hosting: 'Hosting',
    VPS: 'VPS',
    Website: 'Website',
    ActivityLog: 'ActivityLog',
    Setting: 'Setting'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "session" | "domain" | "hosting" | "vPS" | "website" | "activityLog" | "setting"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      Session: {
        payload: Prisma.$SessionPayload<ExtArgs>
        fields: Prisma.SessionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SessionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SessionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          findFirst: {
            args: Prisma.SessionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SessionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          findMany: {
            args: Prisma.SessionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>[]
          }
          create: {
            args: Prisma.SessionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          createMany: {
            args: Prisma.SessionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SessionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          update: {
            args: Prisma.SessionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          deleteMany: {
            args: Prisma.SessionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SessionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SessionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SessionPayload>
          }
          aggregate: {
            args: Prisma.SessionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSession>
          }
          groupBy: {
            args: Prisma.SessionGroupByArgs<ExtArgs>
            result: $Utils.Optional<SessionGroupByOutputType>[]
          }
          count: {
            args: Prisma.SessionCountArgs<ExtArgs>
            result: $Utils.Optional<SessionCountAggregateOutputType> | number
          }
        }
      }
      Domain: {
        payload: Prisma.$DomainPayload<ExtArgs>
        fields: Prisma.DomainFieldRefs
        operations: {
          findUnique: {
            args: Prisma.DomainFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DomainPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.DomainFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          findFirst: {
            args: Prisma.DomainFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DomainPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.DomainFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          findMany: {
            args: Prisma.DomainFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>[]
          }
          create: {
            args: Prisma.DomainCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          createMany: {
            args: Prisma.DomainCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.DomainDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          update: {
            args: Prisma.DomainUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          deleteMany: {
            args: Prisma.DomainDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.DomainUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.DomainUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DomainPayload>
          }
          aggregate: {
            args: Prisma.DomainAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateDomain>
          }
          groupBy: {
            args: Prisma.DomainGroupByArgs<ExtArgs>
            result: $Utils.Optional<DomainGroupByOutputType>[]
          }
          count: {
            args: Prisma.DomainCountArgs<ExtArgs>
            result: $Utils.Optional<DomainCountAggregateOutputType> | number
          }
        }
      }
      Hosting: {
        payload: Prisma.$HostingPayload<ExtArgs>
        fields: Prisma.HostingFieldRefs
        operations: {
          findUnique: {
            args: Prisma.HostingFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HostingPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.HostingFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HostingPayload>
          }
          findFirst: {
            args: Prisma.HostingFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HostingPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.HostingFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HostingPayload>
          }
          findMany: {
            args: Prisma.HostingFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HostingPayload>[]
          }
          create: {
            args: Prisma.HostingCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HostingPayload>
          }
          createMany: {
            args: Prisma.HostingCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.HostingDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HostingPayload>
          }
          update: {
            args: Prisma.HostingUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HostingPayload>
          }
          deleteMany: {
            args: Prisma.HostingDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.HostingUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.HostingUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HostingPayload>
          }
          aggregate: {
            args: Prisma.HostingAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateHosting>
          }
          groupBy: {
            args: Prisma.HostingGroupByArgs<ExtArgs>
            result: $Utils.Optional<HostingGroupByOutputType>[]
          }
          count: {
            args: Prisma.HostingCountArgs<ExtArgs>
            result: $Utils.Optional<HostingCountAggregateOutputType> | number
          }
        }
      }
      VPS: {
        payload: Prisma.$VPSPayload<ExtArgs>
        fields: Prisma.VPSFieldRefs
        operations: {
          findUnique: {
            args: Prisma.VPSFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VPSPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.VPSFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VPSPayload>
          }
          findFirst: {
            args: Prisma.VPSFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VPSPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.VPSFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VPSPayload>
          }
          findMany: {
            args: Prisma.VPSFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VPSPayload>[]
          }
          create: {
            args: Prisma.VPSCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VPSPayload>
          }
          createMany: {
            args: Prisma.VPSCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.VPSDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VPSPayload>
          }
          update: {
            args: Prisma.VPSUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VPSPayload>
          }
          deleteMany: {
            args: Prisma.VPSDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.VPSUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.VPSUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VPSPayload>
          }
          aggregate: {
            args: Prisma.VPSAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateVPS>
          }
          groupBy: {
            args: Prisma.VPSGroupByArgs<ExtArgs>
            result: $Utils.Optional<VPSGroupByOutputType>[]
          }
          count: {
            args: Prisma.VPSCountArgs<ExtArgs>
            result: $Utils.Optional<VPSCountAggregateOutputType> | number
          }
        }
      }
      Website: {
        payload: Prisma.$WebsitePayload<ExtArgs>
        fields: Prisma.WebsiteFieldRefs
        operations: {
          findUnique: {
            args: Prisma.WebsiteFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WebsitePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.WebsiteFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WebsitePayload>
          }
          findFirst: {
            args: Prisma.WebsiteFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WebsitePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.WebsiteFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WebsitePayload>
          }
          findMany: {
            args: Prisma.WebsiteFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WebsitePayload>[]
          }
          create: {
            args: Prisma.WebsiteCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WebsitePayload>
          }
          createMany: {
            args: Prisma.WebsiteCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.WebsiteDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WebsitePayload>
          }
          update: {
            args: Prisma.WebsiteUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WebsitePayload>
          }
          deleteMany: {
            args: Prisma.WebsiteDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.WebsiteUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.WebsiteUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WebsitePayload>
          }
          aggregate: {
            args: Prisma.WebsiteAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateWebsite>
          }
          groupBy: {
            args: Prisma.WebsiteGroupByArgs<ExtArgs>
            result: $Utils.Optional<WebsiteGroupByOutputType>[]
          }
          count: {
            args: Prisma.WebsiteCountArgs<ExtArgs>
            result: $Utils.Optional<WebsiteCountAggregateOutputType> | number
          }
        }
      }
      ActivityLog: {
        payload: Prisma.$ActivityLogPayload<ExtArgs>
        fields: Prisma.ActivityLogFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ActivityLogFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActivityLogPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ActivityLogFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActivityLogPayload>
          }
          findFirst: {
            args: Prisma.ActivityLogFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActivityLogPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ActivityLogFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActivityLogPayload>
          }
          findMany: {
            args: Prisma.ActivityLogFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActivityLogPayload>[]
          }
          create: {
            args: Prisma.ActivityLogCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActivityLogPayload>
          }
          createMany: {
            args: Prisma.ActivityLogCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.ActivityLogDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActivityLogPayload>
          }
          update: {
            args: Prisma.ActivityLogUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActivityLogPayload>
          }
          deleteMany: {
            args: Prisma.ActivityLogDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ActivityLogUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.ActivityLogUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActivityLogPayload>
          }
          aggregate: {
            args: Prisma.ActivityLogAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateActivityLog>
          }
          groupBy: {
            args: Prisma.ActivityLogGroupByArgs<ExtArgs>
            result: $Utils.Optional<ActivityLogGroupByOutputType>[]
          }
          count: {
            args: Prisma.ActivityLogCountArgs<ExtArgs>
            result: $Utils.Optional<ActivityLogCountAggregateOutputType> | number
          }
        }
      }
      Setting: {
        payload: Prisma.$SettingPayload<ExtArgs>
        fields: Prisma.SettingFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SettingFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SettingFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          findFirst: {
            args: Prisma.SettingFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SettingFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          findMany: {
            args: Prisma.SettingFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>[]
          }
          create: {
            args: Prisma.SettingCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          createMany: {
            args: Prisma.SettingCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SettingDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          update: {
            args: Prisma.SettingUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          deleteMany: {
            args: Prisma.SettingDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SettingUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SettingUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          aggregate: {
            args: Prisma.SettingAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSetting>
          }
          groupBy: {
            args: Prisma.SettingGroupByArgs<ExtArgs>
            result: $Utils.Optional<SettingGroupByOutputType>[]
          }
          count: {
            args: Prisma.SettingCountArgs<ExtArgs>
            result: $Utils.Optional<SettingCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    session?: SessionOmit
    domain?: DomainOmit
    hosting?: HostingOmit
    vPS?: VPSOmit
    website?: WebsiteOmit
    activityLog?: ActivityLogOmit
    setting?: SettingOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    activities: number
    domains: number
    hosting: number
    sessions: number
    vps: number
    websites: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    activities?: boolean | UserCountOutputTypeCountActivitiesArgs
    domains?: boolean | UserCountOutputTypeCountDomainsArgs
    hosting?: boolean | UserCountOutputTypeCountHostingArgs
    sessions?: boolean | UserCountOutputTypeCountSessionsArgs
    vps?: boolean | UserCountOutputTypeCountVpsArgs
    websites?: boolean | UserCountOutputTypeCountWebsitesArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountActivitiesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ActivityLogWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountDomainsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DomainWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountHostingArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: HostingWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountSessionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SessionWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountVpsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VPSWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountWebsitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WebsiteWhereInput
  }


  /**
   * Count Type DomainCountOutputType
   */

  export type DomainCountOutputType = {
    activities: number
    websites: number
  }

  export type DomainCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    activities?: boolean | DomainCountOutputTypeCountActivitiesArgs
    websites?: boolean | DomainCountOutputTypeCountWebsitesArgs
  }

  // Custom InputTypes
  /**
   * DomainCountOutputType without action
   */
  export type DomainCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DomainCountOutputType
     */
    select?: DomainCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * DomainCountOutputType without action
   */
  export type DomainCountOutputTypeCountActivitiesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ActivityLogWhereInput
  }

  /**
   * DomainCountOutputType without action
   */
  export type DomainCountOutputTypeCountWebsitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WebsiteWhereInput
  }


  /**
   * Count Type HostingCountOutputType
   */

  export type HostingCountOutputType = {
    activities: number
    domains: number
    websites: number
  }

  export type HostingCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    activities?: boolean | HostingCountOutputTypeCountActivitiesArgs
    domains?: boolean | HostingCountOutputTypeCountDomainsArgs
    websites?: boolean | HostingCountOutputTypeCountWebsitesArgs
  }

  // Custom InputTypes
  /**
   * HostingCountOutputType without action
   */
  export type HostingCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HostingCountOutputType
     */
    select?: HostingCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * HostingCountOutputType without action
   */
  export type HostingCountOutputTypeCountActivitiesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ActivityLogWhereInput
  }

  /**
   * HostingCountOutputType without action
   */
  export type HostingCountOutputTypeCountDomainsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DomainWhereInput
  }

  /**
   * HostingCountOutputType without action
   */
  export type HostingCountOutputTypeCountWebsitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WebsiteWhereInput
  }


  /**
   * Count Type VPSCountOutputType
   */

  export type VPSCountOutputType = {
    activities: number
    domains: number
    websites: number
  }

  export type VPSCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    activities?: boolean | VPSCountOutputTypeCountActivitiesArgs
    domains?: boolean | VPSCountOutputTypeCountDomainsArgs
    websites?: boolean | VPSCountOutputTypeCountWebsitesArgs
  }

  // Custom InputTypes
  /**
   * VPSCountOutputType without action
   */
  export type VPSCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPSCountOutputType
     */
    select?: VPSCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * VPSCountOutputType without action
   */
  export type VPSCountOutputTypeCountActivitiesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ActivityLogWhereInput
  }

  /**
   * VPSCountOutputType without action
   */
  export type VPSCountOutputTypeCountDomainsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DomainWhereInput
  }

  /**
   * VPSCountOutputType without action
   */
  export type VPSCountOutputTypeCountWebsitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WebsiteWhereInput
  }


  /**
   * Count Type WebsiteCountOutputType
   */

  export type WebsiteCountOutputType = {
    activities: number
  }

  export type WebsiteCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    activities?: boolean | WebsiteCountOutputTypeCountActivitiesArgs
  }

  // Custom InputTypes
  /**
   * WebsiteCountOutputType without action
   */
  export type WebsiteCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebsiteCountOutputType
     */
    select?: WebsiteCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * WebsiteCountOutputType without action
   */
  export type WebsiteCountOutputTypeCountActivitiesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ActivityLogWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserMinAggregateOutputType = {
    id: string | null
    email: string | null
    password: string | null
    name: string | null
    role: $Enums.UserRole | null
    isActive: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserMaxAggregateOutputType = {
    id: string | null
    email: string | null
    password: string | null
    name: string | null
    role: $Enums.UserRole | null
    isActive: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    email: number
    password: number
    name: number
    role: number
    isActive: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type UserMinAggregateInputType = {
    id?: true
    email?: true
    password?: true
    name?: true
    role?: true
    isActive?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    email?: true
    password?: true
    name?: true
    role?: true
    isActive?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    email?: true
    password?: true
    name?: true
    role?: true
    isActive?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: string
    email: string
    password: string
    name: string | null
    role: $Enums.UserRole
    isActive: boolean
    createdAt: Date
    updatedAt: Date
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    password?: boolean
    name?: boolean
    role?: boolean
    isActive?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    activities?: boolean | User$activitiesArgs<ExtArgs>
    domains?: boolean | User$domainsArgs<ExtArgs>
    hosting?: boolean | User$hostingArgs<ExtArgs>
    sessions?: boolean | User$sessionsArgs<ExtArgs>
    vps?: boolean | User$vpsArgs<ExtArgs>
    websites?: boolean | User$websitesArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>



  export type UserSelectScalar = {
    id?: boolean
    email?: boolean
    password?: boolean
    name?: boolean
    role?: boolean
    isActive?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "email" | "password" | "name" | "role" | "isActive" | "createdAt" | "updatedAt", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    activities?: boolean | User$activitiesArgs<ExtArgs>
    domains?: boolean | User$domainsArgs<ExtArgs>
    hosting?: boolean | User$hostingArgs<ExtArgs>
    sessions?: boolean | User$sessionsArgs<ExtArgs>
    vps?: boolean | User$vpsArgs<ExtArgs>
    websites?: boolean | User$websitesArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      activities: Prisma.$ActivityLogPayload<ExtArgs>[]
      domains: Prisma.$DomainPayload<ExtArgs>[]
      hosting: Prisma.$HostingPayload<ExtArgs>[]
      sessions: Prisma.$SessionPayload<ExtArgs>[]
      vps: Prisma.$VPSPayload<ExtArgs>[]
      websites: Prisma.$WebsitePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      email: string
      password: string
      name: string | null
      role: $Enums.UserRole
      isActive: boolean
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    activities<T extends User$activitiesArgs<ExtArgs> = {}>(args?: Subset<T, User$activitiesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    domains<T extends User$domainsArgs<ExtArgs> = {}>(args?: Subset<T, User$domainsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    hosting<T extends User$hostingArgs<ExtArgs> = {}>(args?: Subset<T, User$hostingArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    sessions<T extends User$sessionsArgs<ExtArgs> = {}>(args?: Subset<T, User$sessionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    vps<T extends User$vpsArgs<ExtArgs> = {}>(args?: Subset<T, User$vpsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    websites<T extends User$websitesArgs<ExtArgs> = {}>(args?: Subset<T, User$websitesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly password: FieldRef<"User", 'String'>
    readonly name: FieldRef<"User", 'String'>
    readonly role: FieldRef<"User", 'UserRole'>
    readonly isActive: FieldRef<"User", 'Boolean'>
    readonly createdAt: FieldRef<"User", 'DateTime'>
    readonly updatedAt: FieldRef<"User", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User.activities
   */
  export type User$activitiesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    where?: ActivityLogWhereInput
    orderBy?: ActivityLogOrderByWithRelationInput | ActivityLogOrderByWithRelationInput[]
    cursor?: ActivityLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ActivityLogScalarFieldEnum | ActivityLogScalarFieldEnum[]
  }

  /**
   * User.domains
   */
  export type User$domainsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    where?: DomainWhereInput
    orderBy?: DomainOrderByWithRelationInput | DomainOrderByWithRelationInput[]
    cursor?: DomainWhereUniqueInput
    take?: number
    skip?: number
    distinct?: DomainScalarFieldEnum | DomainScalarFieldEnum[]
  }

  /**
   * User.hosting
   */
  export type User$hostingArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    where?: HostingWhereInput
    orderBy?: HostingOrderByWithRelationInput | HostingOrderByWithRelationInput[]
    cursor?: HostingWhereUniqueInput
    take?: number
    skip?: number
    distinct?: HostingScalarFieldEnum | HostingScalarFieldEnum[]
  }

  /**
   * User.sessions
   */
  export type User$sessionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    where?: SessionWhereInput
    orderBy?: SessionOrderByWithRelationInput | SessionOrderByWithRelationInput[]
    cursor?: SessionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SessionScalarFieldEnum | SessionScalarFieldEnum[]
  }

  /**
   * User.vps
   */
  export type User$vpsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    where?: VPSWhereInput
    orderBy?: VPSOrderByWithRelationInput | VPSOrderByWithRelationInput[]
    cursor?: VPSWhereUniqueInput
    take?: number
    skip?: number
    distinct?: VPSScalarFieldEnum | VPSScalarFieldEnum[]
  }

  /**
   * User.websites
   */
  export type User$websitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    where?: WebsiteWhereInput
    orderBy?: WebsiteOrderByWithRelationInput | WebsiteOrderByWithRelationInput[]
    cursor?: WebsiteWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WebsiteScalarFieldEnum | WebsiteScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model Session
   */

  export type AggregateSession = {
    _count: SessionCountAggregateOutputType | null
    _min: SessionMinAggregateOutputType | null
    _max: SessionMaxAggregateOutputType | null
  }

  export type SessionMinAggregateOutputType = {
    id: string | null
    sessionToken: string | null
    userId: string | null
    expires: Date | null
    createdAt: Date | null
  }

  export type SessionMaxAggregateOutputType = {
    id: string | null
    sessionToken: string | null
    userId: string | null
    expires: Date | null
    createdAt: Date | null
  }

  export type SessionCountAggregateOutputType = {
    id: number
    sessionToken: number
    userId: number
    expires: number
    createdAt: number
    _all: number
  }


  export type SessionMinAggregateInputType = {
    id?: true
    sessionToken?: true
    userId?: true
    expires?: true
    createdAt?: true
  }

  export type SessionMaxAggregateInputType = {
    id?: true
    sessionToken?: true
    userId?: true
    expires?: true
    createdAt?: true
  }

  export type SessionCountAggregateInputType = {
    id?: true
    sessionToken?: true
    userId?: true
    expires?: true
    createdAt?: true
    _all?: true
  }

  export type SessionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Session to aggregate.
     */
    where?: SessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sessions to fetch.
     */
    orderBy?: SessionOrderByWithRelationInput | SessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Sessions
    **/
    _count?: true | SessionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SessionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SessionMaxAggregateInputType
  }

  export type GetSessionAggregateType<T extends SessionAggregateArgs> = {
        [P in keyof T & keyof AggregateSession]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSession[P]>
      : GetScalarType<T[P], AggregateSession[P]>
  }




  export type SessionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SessionWhereInput
    orderBy?: SessionOrderByWithAggregationInput | SessionOrderByWithAggregationInput[]
    by: SessionScalarFieldEnum[] | SessionScalarFieldEnum
    having?: SessionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SessionCountAggregateInputType | true
    _min?: SessionMinAggregateInputType
    _max?: SessionMaxAggregateInputType
  }

  export type SessionGroupByOutputType = {
    id: string
    sessionToken: string
    userId: string
    expires: Date
    createdAt: Date
    _count: SessionCountAggregateOutputType | null
    _min: SessionMinAggregateOutputType | null
    _max: SessionMaxAggregateOutputType | null
  }

  type GetSessionGroupByPayload<T extends SessionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SessionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SessionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SessionGroupByOutputType[P]>
            : GetScalarType<T[P], SessionGroupByOutputType[P]>
        }
      >
    >


  export type SessionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sessionToken?: boolean
    userId?: boolean
    expires?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["session"]>



  export type SessionSelectScalar = {
    id?: boolean
    sessionToken?: boolean
    userId?: boolean
    expires?: boolean
    createdAt?: boolean
  }

  export type SessionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "sessionToken" | "userId" | "expires" | "createdAt", ExtArgs["result"]["session"]>
  export type SessionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $SessionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Session"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      sessionToken: string
      userId: string
      expires: Date
      createdAt: Date
    }, ExtArgs["result"]["session"]>
    composites: {}
  }

  type SessionGetPayload<S extends boolean | null | undefined | SessionDefaultArgs> = $Result.GetResult<Prisma.$SessionPayload, S>

  type SessionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SessionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SessionCountAggregateInputType | true
    }

  export interface SessionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Session'], meta: { name: 'Session' } }
    /**
     * Find zero or one Session that matches the filter.
     * @param {SessionFindUniqueArgs} args - Arguments to find a Session
     * @example
     * // Get one Session
     * const session = await prisma.session.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SessionFindUniqueArgs>(args: SelectSubset<T, SessionFindUniqueArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Session that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SessionFindUniqueOrThrowArgs} args - Arguments to find a Session
     * @example
     * // Get one Session
     * const session = await prisma.session.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SessionFindUniqueOrThrowArgs>(args: SelectSubset<T, SessionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Session that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionFindFirstArgs} args - Arguments to find a Session
     * @example
     * // Get one Session
     * const session = await prisma.session.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SessionFindFirstArgs>(args?: SelectSubset<T, SessionFindFirstArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Session that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionFindFirstOrThrowArgs} args - Arguments to find a Session
     * @example
     * // Get one Session
     * const session = await prisma.session.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SessionFindFirstOrThrowArgs>(args?: SelectSubset<T, SessionFindFirstOrThrowArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Sessions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Sessions
     * const sessions = await prisma.session.findMany()
     * 
     * // Get first 10 Sessions
     * const sessions = await prisma.session.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sessionWithIdOnly = await prisma.session.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SessionFindManyArgs>(args?: SelectSubset<T, SessionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Session.
     * @param {SessionCreateArgs} args - Arguments to create a Session.
     * @example
     * // Create one Session
     * const Session = await prisma.session.create({
     *   data: {
     *     // ... data to create a Session
     *   }
     * })
     * 
     */
    create<T extends SessionCreateArgs>(args: SelectSubset<T, SessionCreateArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Sessions.
     * @param {SessionCreateManyArgs} args - Arguments to create many Sessions.
     * @example
     * // Create many Sessions
     * const session = await prisma.session.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SessionCreateManyArgs>(args?: SelectSubset<T, SessionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Session.
     * @param {SessionDeleteArgs} args - Arguments to delete one Session.
     * @example
     * // Delete one Session
     * const Session = await prisma.session.delete({
     *   where: {
     *     // ... filter to delete one Session
     *   }
     * })
     * 
     */
    delete<T extends SessionDeleteArgs>(args: SelectSubset<T, SessionDeleteArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Session.
     * @param {SessionUpdateArgs} args - Arguments to update one Session.
     * @example
     * // Update one Session
     * const session = await prisma.session.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SessionUpdateArgs>(args: SelectSubset<T, SessionUpdateArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Sessions.
     * @param {SessionDeleteManyArgs} args - Arguments to filter Sessions to delete.
     * @example
     * // Delete a few Sessions
     * const { count } = await prisma.session.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SessionDeleteManyArgs>(args?: SelectSubset<T, SessionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Sessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Sessions
     * const session = await prisma.session.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SessionUpdateManyArgs>(args: SelectSubset<T, SessionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Session.
     * @param {SessionUpsertArgs} args - Arguments to update or create a Session.
     * @example
     * // Update or create a Session
     * const session = await prisma.session.upsert({
     *   create: {
     *     // ... data to create a Session
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Session we want to update
     *   }
     * })
     */
    upsert<T extends SessionUpsertArgs>(args: SelectSubset<T, SessionUpsertArgs<ExtArgs>>): Prisma__SessionClient<$Result.GetResult<Prisma.$SessionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Sessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionCountArgs} args - Arguments to filter Sessions to count.
     * @example
     * // Count the number of Sessions
     * const count = await prisma.session.count({
     *   where: {
     *     // ... the filter for the Sessions we want to count
     *   }
     * })
    **/
    count<T extends SessionCountArgs>(
      args?: Subset<T, SessionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SessionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Session.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SessionAggregateArgs>(args: Subset<T, SessionAggregateArgs>): Prisma.PrismaPromise<GetSessionAggregateType<T>>

    /**
     * Group by Session.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SessionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SessionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SessionGroupByArgs['orderBy'] }
        : { orderBy?: SessionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SessionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSessionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Session model
   */
  readonly fields: SessionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Session.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SessionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Session model
   */
  interface SessionFieldRefs {
    readonly id: FieldRef<"Session", 'String'>
    readonly sessionToken: FieldRef<"Session", 'String'>
    readonly userId: FieldRef<"Session", 'String'>
    readonly expires: FieldRef<"Session", 'DateTime'>
    readonly createdAt: FieldRef<"Session", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Session findUnique
   */
  export type SessionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter, which Session to fetch.
     */
    where: SessionWhereUniqueInput
  }

  /**
   * Session findUniqueOrThrow
   */
  export type SessionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter, which Session to fetch.
     */
    where: SessionWhereUniqueInput
  }

  /**
   * Session findFirst
   */
  export type SessionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter, which Session to fetch.
     */
    where?: SessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sessions to fetch.
     */
    orderBy?: SessionOrderByWithRelationInput | SessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Sessions.
     */
    cursor?: SessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Sessions.
     */
    distinct?: SessionScalarFieldEnum | SessionScalarFieldEnum[]
  }

  /**
   * Session findFirstOrThrow
   */
  export type SessionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter, which Session to fetch.
     */
    where?: SessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sessions to fetch.
     */
    orderBy?: SessionOrderByWithRelationInput | SessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Sessions.
     */
    cursor?: SessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Sessions.
     */
    distinct?: SessionScalarFieldEnum | SessionScalarFieldEnum[]
  }

  /**
   * Session findMany
   */
  export type SessionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter, which Sessions to fetch.
     */
    where?: SessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sessions to fetch.
     */
    orderBy?: SessionOrderByWithRelationInput | SessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Sessions.
     */
    cursor?: SessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sessions.
     */
    skip?: number
    distinct?: SessionScalarFieldEnum | SessionScalarFieldEnum[]
  }

  /**
   * Session create
   */
  export type SessionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * The data needed to create a Session.
     */
    data: XOR<SessionCreateInput, SessionUncheckedCreateInput>
  }

  /**
   * Session createMany
   */
  export type SessionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Sessions.
     */
    data: SessionCreateManyInput | SessionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Session update
   */
  export type SessionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * The data needed to update a Session.
     */
    data: XOR<SessionUpdateInput, SessionUncheckedUpdateInput>
    /**
     * Choose, which Session to update.
     */
    where: SessionWhereUniqueInput
  }

  /**
   * Session updateMany
   */
  export type SessionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Sessions.
     */
    data: XOR<SessionUpdateManyMutationInput, SessionUncheckedUpdateManyInput>
    /**
     * Filter which Sessions to update
     */
    where?: SessionWhereInput
    /**
     * Limit how many Sessions to update.
     */
    limit?: number
  }

  /**
   * Session upsert
   */
  export type SessionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * The filter to search for the Session to update in case it exists.
     */
    where: SessionWhereUniqueInput
    /**
     * In case the Session found by the `where` argument doesn't exist, create a new Session with this data.
     */
    create: XOR<SessionCreateInput, SessionUncheckedCreateInput>
    /**
     * In case the Session was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SessionUpdateInput, SessionUncheckedUpdateInput>
  }

  /**
   * Session delete
   */
  export type SessionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
    /**
     * Filter which Session to delete.
     */
    where: SessionWhereUniqueInput
  }

  /**
   * Session deleteMany
   */
  export type SessionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Sessions to delete
     */
    where?: SessionWhereInput
    /**
     * Limit how many Sessions to delete.
     */
    limit?: number
  }

  /**
   * Session without action
   */
  export type SessionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Session
     */
    select?: SessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Session
     */
    omit?: SessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SessionInclude<ExtArgs> | null
  }


  /**
   * Model Domain
   */

  export type AggregateDomain = {
    _count: DomainCountAggregateOutputType | null
    _min: DomainMinAggregateOutputType | null
    _max: DomainMaxAggregateOutputType | null
  }

  export type DomainMinAggregateOutputType = {
    id: string | null
    name: string | null
    registrar: string | null
    status: $Enums.DomainStatus | null
    registeredAt: Date | null
    expiresAt: Date | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
    createdBy: string | null
    hostingId: string | null
    vpsId: string | null
    isMainDomain: boolean | null
    domainHosting: string | null
  }

  export type DomainMaxAggregateOutputType = {
    id: string | null
    name: string | null
    registrar: string | null
    status: $Enums.DomainStatus | null
    registeredAt: Date | null
    expiresAt: Date | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
    createdBy: string | null
    hostingId: string | null
    vpsId: string | null
    isMainDomain: boolean | null
    domainHosting: string | null
  }

  export type DomainCountAggregateOutputType = {
    id: number
    name: number
    registrar: number
    status: number
    registeredAt: number
    expiresAt: number
    nameservers: number
    whoisData: number
    notes: number
    createdAt: number
    updatedAt: number
    createdBy: number
    hostingId: number
    vpsId: number
    isMainDomain: number
    domainHosting: number
    _all: number
  }


  export type DomainMinAggregateInputType = {
    id?: true
    name?: true
    registrar?: true
    status?: true
    registeredAt?: true
    expiresAt?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
    hostingId?: true
    vpsId?: true
    isMainDomain?: true
    domainHosting?: true
  }

  export type DomainMaxAggregateInputType = {
    id?: true
    name?: true
    registrar?: true
    status?: true
    registeredAt?: true
    expiresAt?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
    hostingId?: true
    vpsId?: true
    isMainDomain?: true
    domainHosting?: true
  }

  export type DomainCountAggregateInputType = {
    id?: true
    name?: true
    registrar?: true
    status?: true
    registeredAt?: true
    expiresAt?: true
    nameservers?: true
    whoisData?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
    hostingId?: true
    vpsId?: true
    isMainDomain?: true
    domainHosting?: true
    _all?: true
  }

  export type DomainAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Domain to aggregate.
     */
    where?: DomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Domains to fetch.
     */
    orderBy?: DomainOrderByWithRelationInput | DomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: DomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Domains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Domains.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Domains
    **/
    _count?: true | DomainCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: DomainMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: DomainMaxAggregateInputType
  }

  export type GetDomainAggregateType<T extends DomainAggregateArgs> = {
        [P in keyof T & keyof AggregateDomain]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateDomain[P]>
      : GetScalarType<T[P], AggregateDomain[P]>
  }




  export type DomainGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DomainWhereInput
    orderBy?: DomainOrderByWithAggregationInput | DomainOrderByWithAggregationInput[]
    by: DomainScalarFieldEnum[] | DomainScalarFieldEnum
    having?: DomainScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: DomainCountAggregateInputType | true
    _min?: DomainMinAggregateInputType
    _max?: DomainMaxAggregateInputType
  }

  export type DomainGroupByOutputType = {
    id: string
    name: string
    registrar: string | null
    status: $Enums.DomainStatus
    registeredAt: Date | null
    expiresAt: Date | null
    nameservers: JsonValue | null
    whoisData: JsonValue | null
    notes: string | null
    createdAt: Date
    updatedAt: Date
    createdBy: string
    hostingId: string | null
    vpsId: string | null
    isMainDomain: boolean
    domainHosting: string | null
    _count: DomainCountAggregateOutputType | null
    _min: DomainMinAggregateOutputType | null
    _max: DomainMaxAggregateOutputType | null
  }

  type GetDomainGroupByPayload<T extends DomainGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<DomainGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof DomainGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], DomainGroupByOutputType[P]>
            : GetScalarType<T[P], DomainGroupByOutputType[P]>
        }
      >
    >


  export type DomainSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    registrar?: boolean
    status?: boolean
    registeredAt?: boolean
    expiresAt?: boolean
    nameservers?: boolean
    whoisData?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    createdBy?: boolean
    hostingId?: boolean
    vpsId?: boolean
    isMainDomain?: boolean
    domainHosting?: boolean
    activities?: boolean | Domain$activitiesArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    hosting?: boolean | Domain$hostingArgs<ExtArgs>
    vps?: boolean | Domain$vpsArgs<ExtArgs>
    websites?: boolean | Domain$websitesArgs<ExtArgs>
    _count?: boolean | DomainCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["domain"]>



  export type DomainSelectScalar = {
    id?: boolean
    name?: boolean
    registrar?: boolean
    status?: boolean
    registeredAt?: boolean
    expiresAt?: boolean
    nameservers?: boolean
    whoisData?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    createdBy?: boolean
    hostingId?: boolean
    vpsId?: boolean
    isMainDomain?: boolean
    domainHosting?: boolean
  }

  export type DomainOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "registrar" | "status" | "registeredAt" | "expiresAt" | "nameservers" | "whoisData" | "notes" | "createdAt" | "updatedAt" | "createdBy" | "hostingId" | "vpsId" | "isMainDomain" | "domainHosting", ExtArgs["result"]["domain"]>
  export type DomainInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    activities?: boolean | Domain$activitiesArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    hosting?: boolean | Domain$hostingArgs<ExtArgs>
    vps?: boolean | Domain$vpsArgs<ExtArgs>
    websites?: boolean | Domain$websitesArgs<ExtArgs>
    _count?: boolean | DomainCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $DomainPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Domain"
    objects: {
      activities: Prisma.$ActivityLogPayload<ExtArgs>[]
      user: Prisma.$UserPayload<ExtArgs>
      hosting: Prisma.$HostingPayload<ExtArgs> | null
      vps: Prisma.$VPSPayload<ExtArgs> | null
      websites: Prisma.$WebsitePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      registrar: string | null
      status: $Enums.DomainStatus
      registeredAt: Date | null
      expiresAt: Date | null
      nameservers: Prisma.JsonValue | null
      whoisData: Prisma.JsonValue | null
      notes: string | null
      createdAt: Date
      updatedAt: Date
      createdBy: string
      hostingId: string | null
      vpsId: string | null
      isMainDomain: boolean
      domainHosting: string | null
    }, ExtArgs["result"]["domain"]>
    composites: {}
  }

  type DomainGetPayload<S extends boolean | null | undefined | DomainDefaultArgs> = $Result.GetResult<Prisma.$DomainPayload, S>

  type DomainCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<DomainFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: DomainCountAggregateInputType | true
    }

  export interface DomainDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Domain'], meta: { name: 'Domain' } }
    /**
     * Find zero or one Domain that matches the filter.
     * @param {DomainFindUniqueArgs} args - Arguments to find a Domain
     * @example
     * // Get one Domain
     * const domain = await prisma.domain.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends DomainFindUniqueArgs>(args: SelectSubset<T, DomainFindUniqueArgs<ExtArgs>>): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Domain that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {DomainFindUniqueOrThrowArgs} args - Arguments to find a Domain
     * @example
     * // Get one Domain
     * const domain = await prisma.domain.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends DomainFindUniqueOrThrowArgs>(args: SelectSubset<T, DomainFindUniqueOrThrowArgs<ExtArgs>>): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Domain that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainFindFirstArgs} args - Arguments to find a Domain
     * @example
     * // Get one Domain
     * const domain = await prisma.domain.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends DomainFindFirstArgs>(args?: SelectSubset<T, DomainFindFirstArgs<ExtArgs>>): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Domain that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainFindFirstOrThrowArgs} args - Arguments to find a Domain
     * @example
     * // Get one Domain
     * const domain = await prisma.domain.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends DomainFindFirstOrThrowArgs>(args?: SelectSubset<T, DomainFindFirstOrThrowArgs<ExtArgs>>): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Domains that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Domains
     * const domains = await prisma.domain.findMany()
     * 
     * // Get first 10 Domains
     * const domains = await prisma.domain.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const domainWithIdOnly = await prisma.domain.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends DomainFindManyArgs>(args?: SelectSubset<T, DomainFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Domain.
     * @param {DomainCreateArgs} args - Arguments to create a Domain.
     * @example
     * // Create one Domain
     * const Domain = await prisma.domain.create({
     *   data: {
     *     // ... data to create a Domain
     *   }
     * })
     * 
     */
    create<T extends DomainCreateArgs>(args: SelectSubset<T, DomainCreateArgs<ExtArgs>>): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Domains.
     * @param {DomainCreateManyArgs} args - Arguments to create many Domains.
     * @example
     * // Create many Domains
     * const domain = await prisma.domain.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends DomainCreateManyArgs>(args?: SelectSubset<T, DomainCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Domain.
     * @param {DomainDeleteArgs} args - Arguments to delete one Domain.
     * @example
     * // Delete one Domain
     * const Domain = await prisma.domain.delete({
     *   where: {
     *     // ... filter to delete one Domain
     *   }
     * })
     * 
     */
    delete<T extends DomainDeleteArgs>(args: SelectSubset<T, DomainDeleteArgs<ExtArgs>>): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Domain.
     * @param {DomainUpdateArgs} args - Arguments to update one Domain.
     * @example
     * // Update one Domain
     * const domain = await prisma.domain.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends DomainUpdateArgs>(args: SelectSubset<T, DomainUpdateArgs<ExtArgs>>): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Domains.
     * @param {DomainDeleteManyArgs} args - Arguments to filter Domains to delete.
     * @example
     * // Delete a few Domains
     * const { count } = await prisma.domain.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends DomainDeleteManyArgs>(args?: SelectSubset<T, DomainDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Domains.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Domains
     * const domain = await prisma.domain.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends DomainUpdateManyArgs>(args: SelectSubset<T, DomainUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Domain.
     * @param {DomainUpsertArgs} args - Arguments to update or create a Domain.
     * @example
     * // Update or create a Domain
     * const domain = await prisma.domain.upsert({
     *   create: {
     *     // ... data to create a Domain
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Domain we want to update
     *   }
     * })
     */
    upsert<T extends DomainUpsertArgs>(args: SelectSubset<T, DomainUpsertArgs<ExtArgs>>): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Domains.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainCountArgs} args - Arguments to filter Domains to count.
     * @example
     * // Count the number of Domains
     * const count = await prisma.domain.count({
     *   where: {
     *     // ... the filter for the Domains we want to count
     *   }
     * })
    **/
    count<T extends DomainCountArgs>(
      args?: Subset<T, DomainCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], DomainCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Domain.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends DomainAggregateArgs>(args: Subset<T, DomainAggregateArgs>): Prisma.PrismaPromise<GetDomainAggregateType<T>>

    /**
     * Group by Domain.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DomainGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends DomainGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: DomainGroupByArgs['orderBy'] }
        : { orderBy?: DomainGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, DomainGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetDomainGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Domain model
   */
  readonly fields: DomainFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Domain.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__DomainClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    activities<T extends Domain$activitiesArgs<ExtArgs> = {}>(args?: Subset<T, Domain$activitiesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    hosting<T extends Domain$hostingArgs<ExtArgs> = {}>(args?: Subset<T, Domain$hostingArgs<ExtArgs>>): Prisma__HostingClient<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    vps<T extends Domain$vpsArgs<ExtArgs> = {}>(args?: Subset<T, Domain$vpsArgs<ExtArgs>>): Prisma__VPSClient<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    websites<T extends Domain$websitesArgs<ExtArgs> = {}>(args?: Subset<T, Domain$websitesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Domain model
   */
  interface DomainFieldRefs {
    readonly id: FieldRef<"Domain", 'String'>
    readonly name: FieldRef<"Domain", 'String'>
    readonly registrar: FieldRef<"Domain", 'String'>
    readonly status: FieldRef<"Domain", 'DomainStatus'>
    readonly registeredAt: FieldRef<"Domain", 'DateTime'>
    readonly expiresAt: FieldRef<"Domain", 'DateTime'>
    readonly nameservers: FieldRef<"Domain", 'Json'>
    readonly whoisData: FieldRef<"Domain", 'Json'>
    readonly notes: FieldRef<"Domain", 'String'>
    readonly createdAt: FieldRef<"Domain", 'DateTime'>
    readonly updatedAt: FieldRef<"Domain", 'DateTime'>
    readonly createdBy: FieldRef<"Domain", 'String'>
    readonly hostingId: FieldRef<"Domain", 'String'>
    readonly vpsId: FieldRef<"Domain", 'String'>
    readonly isMainDomain: FieldRef<"Domain", 'Boolean'>
    readonly domainHosting: FieldRef<"Domain", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Domain findUnique
   */
  export type DomainFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter, which Domain to fetch.
     */
    where: DomainWhereUniqueInput
  }

  /**
   * Domain findUniqueOrThrow
   */
  export type DomainFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter, which Domain to fetch.
     */
    where: DomainWhereUniqueInput
  }

  /**
   * Domain findFirst
   */
  export type DomainFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter, which Domain to fetch.
     */
    where?: DomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Domains to fetch.
     */
    orderBy?: DomainOrderByWithRelationInput | DomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Domains.
     */
    cursor?: DomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Domains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Domains.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Domains.
     */
    distinct?: DomainScalarFieldEnum | DomainScalarFieldEnum[]
  }

  /**
   * Domain findFirstOrThrow
   */
  export type DomainFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter, which Domain to fetch.
     */
    where?: DomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Domains to fetch.
     */
    orderBy?: DomainOrderByWithRelationInput | DomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Domains.
     */
    cursor?: DomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Domains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Domains.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Domains.
     */
    distinct?: DomainScalarFieldEnum | DomainScalarFieldEnum[]
  }

  /**
   * Domain findMany
   */
  export type DomainFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter, which Domains to fetch.
     */
    where?: DomainWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Domains to fetch.
     */
    orderBy?: DomainOrderByWithRelationInput | DomainOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Domains.
     */
    cursor?: DomainWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Domains from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Domains.
     */
    skip?: number
    distinct?: DomainScalarFieldEnum | DomainScalarFieldEnum[]
  }

  /**
   * Domain create
   */
  export type DomainCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * The data needed to create a Domain.
     */
    data: XOR<DomainCreateInput, DomainUncheckedCreateInput>
  }

  /**
   * Domain createMany
   */
  export type DomainCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Domains.
     */
    data: DomainCreateManyInput | DomainCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Domain update
   */
  export type DomainUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * The data needed to update a Domain.
     */
    data: XOR<DomainUpdateInput, DomainUncheckedUpdateInput>
    /**
     * Choose, which Domain to update.
     */
    where: DomainWhereUniqueInput
  }

  /**
   * Domain updateMany
   */
  export type DomainUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Domains.
     */
    data: XOR<DomainUpdateManyMutationInput, DomainUncheckedUpdateManyInput>
    /**
     * Filter which Domains to update
     */
    where?: DomainWhereInput
    /**
     * Limit how many Domains to update.
     */
    limit?: number
  }

  /**
   * Domain upsert
   */
  export type DomainUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * The filter to search for the Domain to update in case it exists.
     */
    where: DomainWhereUniqueInput
    /**
     * In case the Domain found by the `where` argument doesn't exist, create a new Domain with this data.
     */
    create: XOR<DomainCreateInput, DomainUncheckedCreateInput>
    /**
     * In case the Domain was found with the provided `where` argument, update it with this data.
     */
    update: XOR<DomainUpdateInput, DomainUncheckedUpdateInput>
  }

  /**
   * Domain delete
   */
  export type DomainDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    /**
     * Filter which Domain to delete.
     */
    where: DomainWhereUniqueInput
  }

  /**
   * Domain deleteMany
   */
  export type DomainDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Domains to delete
     */
    where?: DomainWhereInput
    /**
     * Limit how many Domains to delete.
     */
    limit?: number
  }

  /**
   * Domain.activities
   */
  export type Domain$activitiesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    where?: ActivityLogWhereInput
    orderBy?: ActivityLogOrderByWithRelationInput | ActivityLogOrderByWithRelationInput[]
    cursor?: ActivityLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ActivityLogScalarFieldEnum | ActivityLogScalarFieldEnum[]
  }

  /**
   * Domain.hosting
   */
  export type Domain$hostingArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    where?: HostingWhereInput
  }

  /**
   * Domain.vps
   */
  export type Domain$vpsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    where?: VPSWhereInput
  }

  /**
   * Domain.websites
   */
  export type Domain$websitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    where?: WebsiteWhereInput
    orderBy?: WebsiteOrderByWithRelationInput | WebsiteOrderByWithRelationInput[]
    cursor?: WebsiteWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WebsiteScalarFieldEnum | WebsiteScalarFieldEnum[]
  }

  /**
   * Domain without action
   */
  export type DomainDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
  }


  /**
   * Model Hosting
   */

  export type AggregateHosting = {
    _count: HostingCountAggregateOutputType | null
    _min: HostingMinAggregateOutputType | null
    _max: HostingMaxAggregateOutputType | null
  }

  export type HostingMinAggregateOutputType = {
    id: string | null
    name: string | null
    provider: string | null
    status: $Enums.HostingStatus | null
    planName: string | null
    cpanelUrl: string | null
    username: string | null
    password: string | null
    expiresAt: Date | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
    createdBy: string | null
  }

  export type HostingMaxAggregateOutputType = {
    id: string | null
    name: string | null
    provider: string | null
    status: $Enums.HostingStatus | null
    planName: string | null
    cpanelUrl: string | null
    username: string | null
    password: string | null
    expiresAt: Date | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
    createdBy: string | null
  }

  export type HostingCountAggregateOutputType = {
    id: number
    name: number
    provider: number
    status: number
    planName: number
    resources: number
    cpanelUrl: number
    username: number
    password: number
    expiresAt: number
    notes: number
    createdAt: number
    updatedAt: number
    createdBy: number
    _all: number
  }


  export type HostingMinAggregateInputType = {
    id?: true
    name?: true
    provider?: true
    status?: true
    planName?: true
    cpanelUrl?: true
    username?: true
    password?: true
    expiresAt?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
  }

  export type HostingMaxAggregateInputType = {
    id?: true
    name?: true
    provider?: true
    status?: true
    planName?: true
    cpanelUrl?: true
    username?: true
    password?: true
    expiresAt?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
  }

  export type HostingCountAggregateInputType = {
    id?: true
    name?: true
    provider?: true
    status?: true
    planName?: true
    resources?: true
    cpanelUrl?: true
    username?: true
    password?: true
    expiresAt?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
    _all?: true
  }

  export type HostingAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Hosting to aggregate.
     */
    where?: HostingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Hostings to fetch.
     */
    orderBy?: HostingOrderByWithRelationInput | HostingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: HostingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Hostings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Hostings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Hostings
    **/
    _count?: true | HostingCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: HostingMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: HostingMaxAggregateInputType
  }

  export type GetHostingAggregateType<T extends HostingAggregateArgs> = {
        [P in keyof T & keyof AggregateHosting]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateHosting[P]>
      : GetScalarType<T[P], AggregateHosting[P]>
  }




  export type HostingGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: HostingWhereInput
    orderBy?: HostingOrderByWithAggregationInput | HostingOrderByWithAggregationInput[]
    by: HostingScalarFieldEnum[] | HostingScalarFieldEnum
    having?: HostingScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: HostingCountAggregateInputType | true
    _min?: HostingMinAggregateInputType
    _max?: HostingMaxAggregateInputType
  }

  export type HostingGroupByOutputType = {
    id: string
    name: string
    provider: string
    status: $Enums.HostingStatus
    planName: string | null
    resources: JsonValue | null
    cpanelUrl: string | null
    username: string | null
    password: string | null
    expiresAt: Date | null
    notes: string | null
    createdAt: Date
    updatedAt: Date
    createdBy: string
    _count: HostingCountAggregateOutputType | null
    _min: HostingMinAggregateOutputType | null
    _max: HostingMaxAggregateOutputType | null
  }

  type GetHostingGroupByPayload<T extends HostingGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<HostingGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof HostingGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], HostingGroupByOutputType[P]>
            : GetScalarType<T[P], HostingGroupByOutputType[P]>
        }
      >
    >


  export type HostingSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    provider?: boolean
    status?: boolean
    planName?: boolean
    resources?: boolean
    cpanelUrl?: boolean
    username?: boolean
    password?: boolean
    expiresAt?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    createdBy?: boolean
    activities?: boolean | Hosting$activitiesArgs<ExtArgs>
    domains?: boolean | Hosting$domainsArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    websites?: boolean | Hosting$websitesArgs<ExtArgs>
    _count?: boolean | HostingCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["hosting"]>



  export type HostingSelectScalar = {
    id?: boolean
    name?: boolean
    provider?: boolean
    status?: boolean
    planName?: boolean
    resources?: boolean
    cpanelUrl?: boolean
    username?: boolean
    password?: boolean
    expiresAt?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    createdBy?: boolean
  }

  export type HostingOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "provider" | "status" | "planName" | "resources" | "cpanelUrl" | "username" | "password" | "expiresAt" | "notes" | "createdAt" | "updatedAt" | "createdBy", ExtArgs["result"]["hosting"]>
  export type HostingInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    activities?: boolean | Hosting$activitiesArgs<ExtArgs>
    domains?: boolean | Hosting$domainsArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    websites?: boolean | Hosting$websitesArgs<ExtArgs>
    _count?: boolean | HostingCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $HostingPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Hosting"
    objects: {
      activities: Prisma.$ActivityLogPayload<ExtArgs>[]
      domains: Prisma.$DomainPayload<ExtArgs>[]
      user: Prisma.$UserPayload<ExtArgs>
      websites: Prisma.$WebsitePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      provider: string
      status: $Enums.HostingStatus
      planName: string | null
      resources: Prisma.JsonValue | null
      cpanelUrl: string | null
      username: string | null
      password: string | null
      expiresAt: Date | null
      notes: string | null
      createdAt: Date
      updatedAt: Date
      createdBy: string
    }, ExtArgs["result"]["hosting"]>
    composites: {}
  }

  type HostingGetPayload<S extends boolean | null | undefined | HostingDefaultArgs> = $Result.GetResult<Prisma.$HostingPayload, S>

  type HostingCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<HostingFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: HostingCountAggregateInputType | true
    }

  export interface HostingDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Hosting'], meta: { name: 'Hosting' } }
    /**
     * Find zero or one Hosting that matches the filter.
     * @param {HostingFindUniqueArgs} args - Arguments to find a Hosting
     * @example
     * // Get one Hosting
     * const hosting = await prisma.hosting.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends HostingFindUniqueArgs>(args: SelectSubset<T, HostingFindUniqueArgs<ExtArgs>>): Prisma__HostingClient<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Hosting that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {HostingFindUniqueOrThrowArgs} args - Arguments to find a Hosting
     * @example
     * // Get one Hosting
     * const hosting = await prisma.hosting.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends HostingFindUniqueOrThrowArgs>(args: SelectSubset<T, HostingFindUniqueOrThrowArgs<ExtArgs>>): Prisma__HostingClient<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Hosting that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HostingFindFirstArgs} args - Arguments to find a Hosting
     * @example
     * // Get one Hosting
     * const hosting = await prisma.hosting.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends HostingFindFirstArgs>(args?: SelectSubset<T, HostingFindFirstArgs<ExtArgs>>): Prisma__HostingClient<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Hosting that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HostingFindFirstOrThrowArgs} args - Arguments to find a Hosting
     * @example
     * // Get one Hosting
     * const hosting = await prisma.hosting.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends HostingFindFirstOrThrowArgs>(args?: SelectSubset<T, HostingFindFirstOrThrowArgs<ExtArgs>>): Prisma__HostingClient<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Hostings that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HostingFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Hostings
     * const hostings = await prisma.hosting.findMany()
     * 
     * // Get first 10 Hostings
     * const hostings = await prisma.hosting.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const hostingWithIdOnly = await prisma.hosting.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends HostingFindManyArgs>(args?: SelectSubset<T, HostingFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Hosting.
     * @param {HostingCreateArgs} args - Arguments to create a Hosting.
     * @example
     * // Create one Hosting
     * const Hosting = await prisma.hosting.create({
     *   data: {
     *     // ... data to create a Hosting
     *   }
     * })
     * 
     */
    create<T extends HostingCreateArgs>(args: SelectSubset<T, HostingCreateArgs<ExtArgs>>): Prisma__HostingClient<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Hostings.
     * @param {HostingCreateManyArgs} args - Arguments to create many Hostings.
     * @example
     * // Create many Hostings
     * const hosting = await prisma.hosting.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends HostingCreateManyArgs>(args?: SelectSubset<T, HostingCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Hosting.
     * @param {HostingDeleteArgs} args - Arguments to delete one Hosting.
     * @example
     * // Delete one Hosting
     * const Hosting = await prisma.hosting.delete({
     *   where: {
     *     // ... filter to delete one Hosting
     *   }
     * })
     * 
     */
    delete<T extends HostingDeleteArgs>(args: SelectSubset<T, HostingDeleteArgs<ExtArgs>>): Prisma__HostingClient<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Hosting.
     * @param {HostingUpdateArgs} args - Arguments to update one Hosting.
     * @example
     * // Update one Hosting
     * const hosting = await prisma.hosting.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends HostingUpdateArgs>(args: SelectSubset<T, HostingUpdateArgs<ExtArgs>>): Prisma__HostingClient<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Hostings.
     * @param {HostingDeleteManyArgs} args - Arguments to filter Hostings to delete.
     * @example
     * // Delete a few Hostings
     * const { count } = await prisma.hosting.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends HostingDeleteManyArgs>(args?: SelectSubset<T, HostingDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Hostings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HostingUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Hostings
     * const hosting = await prisma.hosting.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends HostingUpdateManyArgs>(args: SelectSubset<T, HostingUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Hosting.
     * @param {HostingUpsertArgs} args - Arguments to update or create a Hosting.
     * @example
     * // Update or create a Hosting
     * const hosting = await prisma.hosting.upsert({
     *   create: {
     *     // ... data to create a Hosting
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Hosting we want to update
     *   }
     * })
     */
    upsert<T extends HostingUpsertArgs>(args: SelectSubset<T, HostingUpsertArgs<ExtArgs>>): Prisma__HostingClient<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Hostings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HostingCountArgs} args - Arguments to filter Hostings to count.
     * @example
     * // Count the number of Hostings
     * const count = await prisma.hosting.count({
     *   where: {
     *     // ... the filter for the Hostings we want to count
     *   }
     * })
    **/
    count<T extends HostingCountArgs>(
      args?: Subset<T, HostingCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], HostingCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Hosting.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HostingAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends HostingAggregateArgs>(args: Subset<T, HostingAggregateArgs>): Prisma.PrismaPromise<GetHostingAggregateType<T>>

    /**
     * Group by Hosting.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HostingGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends HostingGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: HostingGroupByArgs['orderBy'] }
        : { orderBy?: HostingGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, HostingGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetHostingGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Hosting model
   */
  readonly fields: HostingFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Hosting.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__HostingClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    activities<T extends Hosting$activitiesArgs<ExtArgs> = {}>(args?: Subset<T, Hosting$activitiesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    domains<T extends Hosting$domainsArgs<ExtArgs> = {}>(args?: Subset<T, Hosting$domainsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    websites<T extends Hosting$websitesArgs<ExtArgs> = {}>(args?: Subset<T, Hosting$websitesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Hosting model
   */
  interface HostingFieldRefs {
    readonly id: FieldRef<"Hosting", 'String'>
    readonly name: FieldRef<"Hosting", 'String'>
    readonly provider: FieldRef<"Hosting", 'String'>
    readonly status: FieldRef<"Hosting", 'HostingStatus'>
    readonly planName: FieldRef<"Hosting", 'String'>
    readonly resources: FieldRef<"Hosting", 'Json'>
    readonly cpanelUrl: FieldRef<"Hosting", 'String'>
    readonly username: FieldRef<"Hosting", 'String'>
    readonly password: FieldRef<"Hosting", 'String'>
    readonly expiresAt: FieldRef<"Hosting", 'DateTime'>
    readonly notes: FieldRef<"Hosting", 'String'>
    readonly createdAt: FieldRef<"Hosting", 'DateTime'>
    readonly updatedAt: FieldRef<"Hosting", 'DateTime'>
    readonly createdBy: FieldRef<"Hosting", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Hosting findUnique
   */
  export type HostingFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    /**
     * Filter, which Hosting to fetch.
     */
    where: HostingWhereUniqueInput
  }

  /**
   * Hosting findUniqueOrThrow
   */
  export type HostingFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    /**
     * Filter, which Hosting to fetch.
     */
    where: HostingWhereUniqueInput
  }

  /**
   * Hosting findFirst
   */
  export type HostingFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    /**
     * Filter, which Hosting to fetch.
     */
    where?: HostingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Hostings to fetch.
     */
    orderBy?: HostingOrderByWithRelationInput | HostingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Hostings.
     */
    cursor?: HostingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Hostings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Hostings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Hostings.
     */
    distinct?: HostingScalarFieldEnum | HostingScalarFieldEnum[]
  }

  /**
   * Hosting findFirstOrThrow
   */
  export type HostingFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    /**
     * Filter, which Hosting to fetch.
     */
    where?: HostingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Hostings to fetch.
     */
    orderBy?: HostingOrderByWithRelationInput | HostingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Hostings.
     */
    cursor?: HostingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Hostings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Hostings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Hostings.
     */
    distinct?: HostingScalarFieldEnum | HostingScalarFieldEnum[]
  }

  /**
   * Hosting findMany
   */
  export type HostingFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    /**
     * Filter, which Hostings to fetch.
     */
    where?: HostingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Hostings to fetch.
     */
    orderBy?: HostingOrderByWithRelationInput | HostingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Hostings.
     */
    cursor?: HostingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Hostings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Hostings.
     */
    skip?: number
    distinct?: HostingScalarFieldEnum | HostingScalarFieldEnum[]
  }

  /**
   * Hosting create
   */
  export type HostingCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    /**
     * The data needed to create a Hosting.
     */
    data: XOR<HostingCreateInput, HostingUncheckedCreateInput>
  }

  /**
   * Hosting createMany
   */
  export type HostingCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Hostings.
     */
    data: HostingCreateManyInput | HostingCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Hosting update
   */
  export type HostingUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    /**
     * The data needed to update a Hosting.
     */
    data: XOR<HostingUpdateInput, HostingUncheckedUpdateInput>
    /**
     * Choose, which Hosting to update.
     */
    where: HostingWhereUniqueInput
  }

  /**
   * Hosting updateMany
   */
  export type HostingUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Hostings.
     */
    data: XOR<HostingUpdateManyMutationInput, HostingUncheckedUpdateManyInput>
    /**
     * Filter which Hostings to update
     */
    where?: HostingWhereInput
    /**
     * Limit how many Hostings to update.
     */
    limit?: number
  }

  /**
   * Hosting upsert
   */
  export type HostingUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    /**
     * The filter to search for the Hosting to update in case it exists.
     */
    where: HostingWhereUniqueInput
    /**
     * In case the Hosting found by the `where` argument doesn't exist, create a new Hosting with this data.
     */
    create: XOR<HostingCreateInput, HostingUncheckedCreateInput>
    /**
     * In case the Hosting was found with the provided `where` argument, update it with this data.
     */
    update: XOR<HostingUpdateInput, HostingUncheckedUpdateInput>
  }

  /**
   * Hosting delete
   */
  export type HostingDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    /**
     * Filter which Hosting to delete.
     */
    where: HostingWhereUniqueInput
  }

  /**
   * Hosting deleteMany
   */
  export type HostingDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Hostings to delete
     */
    where?: HostingWhereInput
    /**
     * Limit how many Hostings to delete.
     */
    limit?: number
  }

  /**
   * Hosting.activities
   */
  export type Hosting$activitiesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    where?: ActivityLogWhereInput
    orderBy?: ActivityLogOrderByWithRelationInput | ActivityLogOrderByWithRelationInput[]
    cursor?: ActivityLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ActivityLogScalarFieldEnum | ActivityLogScalarFieldEnum[]
  }

  /**
   * Hosting.domains
   */
  export type Hosting$domainsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    where?: DomainWhereInput
    orderBy?: DomainOrderByWithRelationInput | DomainOrderByWithRelationInput[]
    cursor?: DomainWhereUniqueInput
    take?: number
    skip?: number
    distinct?: DomainScalarFieldEnum | DomainScalarFieldEnum[]
  }

  /**
   * Hosting.websites
   */
  export type Hosting$websitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    where?: WebsiteWhereInput
    orderBy?: WebsiteOrderByWithRelationInput | WebsiteOrderByWithRelationInput[]
    cursor?: WebsiteWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WebsiteScalarFieldEnum | WebsiteScalarFieldEnum[]
  }

  /**
   * Hosting without action
   */
  export type HostingDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
  }


  /**
   * Model VPS
   */

  export type AggregateVPS = {
    _count: VPSCountAggregateOutputType | null
    _avg: VPSAvgAggregateOutputType | null
    _sum: VPSSumAggregateOutputType | null
    _min: VPSMinAggregateOutputType | null
    _max: VPSMaxAggregateOutputType | null
  }

  export type VPSAvgAggregateOutputType = {
    sshPort: number | null
  }

  export type VPSSumAggregateOutputType = {
    sshPort: number | null
  }

  export type VPSMinAggregateOutputType = {
    id: string | null
    name: string | null
    provider: string | null
    status: $Enums.VPSStatus | null
    ipAddress: string | null
    sshPort: number | null
    sshKey: string | null
    username: string | null
    password: string | null
    expiresAt: Date | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
    createdBy: string | null
    cpanelUrl: string | null
  }

  export type VPSMaxAggregateOutputType = {
    id: string | null
    name: string | null
    provider: string | null
    status: $Enums.VPSStatus | null
    ipAddress: string | null
    sshPort: number | null
    sshKey: string | null
    username: string | null
    password: string | null
    expiresAt: Date | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
    createdBy: string | null
    cpanelUrl: string | null
  }

  export type VPSCountAggregateOutputType = {
    id: number
    name: number
    provider: number
    status: number
    ipAddress: number
    specs: number
    sshPort: number
    sshKey: number
    username: number
    password: number
    expiresAt: number
    notes: number
    createdAt: number
    updatedAt: number
    createdBy: number
    cpanelUrl: number
    _all: number
  }


  export type VPSAvgAggregateInputType = {
    sshPort?: true
  }

  export type VPSSumAggregateInputType = {
    sshPort?: true
  }

  export type VPSMinAggregateInputType = {
    id?: true
    name?: true
    provider?: true
    status?: true
    ipAddress?: true
    sshPort?: true
    sshKey?: true
    username?: true
    password?: true
    expiresAt?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
    cpanelUrl?: true
  }

  export type VPSMaxAggregateInputType = {
    id?: true
    name?: true
    provider?: true
    status?: true
    ipAddress?: true
    sshPort?: true
    sshKey?: true
    username?: true
    password?: true
    expiresAt?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
    cpanelUrl?: true
  }

  export type VPSCountAggregateInputType = {
    id?: true
    name?: true
    provider?: true
    status?: true
    ipAddress?: true
    specs?: true
    sshPort?: true
    sshKey?: true
    username?: true
    password?: true
    expiresAt?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
    cpanelUrl?: true
    _all?: true
  }

  export type VPSAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VPS to aggregate.
     */
    where?: VPSWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VPS to fetch.
     */
    orderBy?: VPSOrderByWithRelationInput | VPSOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: VPSWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VPS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VPS.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned VPS
    **/
    _count?: true | VPSCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: VPSAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: VPSSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VPSMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VPSMaxAggregateInputType
  }

  export type GetVPSAggregateType<T extends VPSAggregateArgs> = {
        [P in keyof T & keyof AggregateVPS]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVPS[P]>
      : GetScalarType<T[P], AggregateVPS[P]>
  }




  export type VPSGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VPSWhereInput
    orderBy?: VPSOrderByWithAggregationInput | VPSOrderByWithAggregationInput[]
    by: VPSScalarFieldEnum[] | VPSScalarFieldEnum
    having?: VPSScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VPSCountAggregateInputType | true
    _avg?: VPSAvgAggregateInputType
    _sum?: VPSSumAggregateInputType
    _min?: VPSMinAggregateInputType
    _max?: VPSMaxAggregateInputType
  }

  export type VPSGroupByOutputType = {
    id: string
    name: string
    provider: string
    status: $Enums.VPSStatus
    ipAddress: string | null
    specs: JsonValue | null
    sshPort: number | null
    sshKey: string | null
    username: string | null
    password: string | null
    expiresAt: Date | null
    notes: string | null
    createdAt: Date
    updatedAt: Date
    createdBy: string
    cpanelUrl: string | null
    _count: VPSCountAggregateOutputType | null
    _avg: VPSAvgAggregateOutputType | null
    _sum: VPSSumAggregateOutputType | null
    _min: VPSMinAggregateOutputType | null
    _max: VPSMaxAggregateOutputType | null
  }

  type GetVPSGroupByPayload<T extends VPSGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<VPSGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VPSGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VPSGroupByOutputType[P]>
            : GetScalarType<T[P], VPSGroupByOutputType[P]>
        }
      >
    >


  export type VPSSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    provider?: boolean
    status?: boolean
    ipAddress?: boolean
    specs?: boolean
    sshPort?: boolean
    sshKey?: boolean
    username?: boolean
    password?: boolean
    expiresAt?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    createdBy?: boolean
    cpanelUrl?: boolean
    activities?: boolean | VPS$activitiesArgs<ExtArgs>
    domains?: boolean | VPS$domainsArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    websites?: boolean | VPS$websitesArgs<ExtArgs>
    _count?: boolean | VPSCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["vPS"]>



  export type VPSSelectScalar = {
    id?: boolean
    name?: boolean
    provider?: boolean
    status?: boolean
    ipAddress?: boolean
    specs?: boolean
    sshPort?: boolean
    sshKey?: boolean
    username?: boolean
    password?: boolean
    expiresAt?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    createdBy?: boolean
    cpanelUrl?: boolean
  }

  export type VPSOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "provider" | "status" | "ipAddress" | "specs" | "sshPort" | "sshKey" | "username" | "password" | "expiresAt" | "notes" | "createdAt" | "updatedAt" | "createdBy" | "cpanelUrl", ExtArgs["result"]["vPS"]>
  export type VPSInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    activities?: boolean | VPS$activitiesArgs<ExtArgs>
    domains?: boolean | VPS$domainsArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    websites?: boolean | VPS$websitesArgs<ExtArgs>
    _count?: boolean | VPSCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $VPSPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "VPS"
    objects: {
      activities: Prisma.$ActivityLogPayload<ExtArgs>[]
      domains: Prisma.$DomainPayload<ExtArgs>[]
      user: Prisma.$UserPayload<ExtArgs>
      websites: Prisma.$WebsitePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      provider: string
      status: $Enums.VPSStatus
      ipAddress: string | null
      specs: Prisma.JsonValue | null
      sshPort: number | null
      sshKey: string | null
      username: string | null
      password: string | null
      expiresAt: Date | null
      notes: string | null
      createdAt: Date
      updatedAt: Date
      createdBy: string
      cpanelUrl: string | null
    }, ExtArgs["result"]["vPS"]>
    composites: {}
  }

  type VPSGetPayload<S extends boolean | null | undefined | VPSDefaultArgs> = $Result.GetResult<Prisma.$VPSPayload, S>

  type VPSCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<VPSFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: VPSCountAggregateInputType | true
    }

  export interface VPSDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['VPS'], meta: { name: 'VPS' } }
    /**
     * Find zero or one VPS that matches the filter.
     * @param {VPSFindUniqueArgs} args - Arguments to find a VPS
     * @example
     * // Get one VPS
     * const vPS = await prisma.vPS.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends VPSFindUniqueArgs>(args: SelectSubset<T, VPSFindUniqueArgs<ExtArgs>>): Prisma__VPSClient<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one VPS that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {VPSFindUniqueOrThrowArgs} args - Arguments to find a VPS
     * @example
     * // Get one VPS
     * const vPS = await prisma.vPS.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends VPSFindUniqueOrThrowArgs>(args: SelectSubset<T, VPSFindUniqueOrThrowArgs<ExtArgs>>): Prisma__VPSClient<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VPS that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VPSFindFirstArgs} args - Arguments to find a VPS
     * @example
     * // Get one VPS
     * const vPS = await prisma.vPS.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends VPSFindFirstArgs>(args?: SelectSubset<T, VPSFindFirstArgs<ExtArgs>>): Prisma__VPSClient<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VPS that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VPSFindFirstOrThrowArgs} args - Arguments to find a VPS
     * @example
     * // Get one VPS
     * const vPS = await prisma.vPS.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends VPSFindFirstOrThrowArgs>(args?: SelectSubset<T, VPSFindFirstOrThrowArgs<ExtArgs>>): Prisma__VPSClient<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more VPS that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VPSFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all VPS
     * const vPS = await prisma.vPS.findMany()
     * 
     * // Get first 10 VPS
     * const vPS = await prisma.vPS.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const vPSWithIdOnly = await prisma.vPS.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends VPSFindManyArgs>(args?: SelectSubset<T, VPSFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a VPS.
     * @param {VPSCreateArgs} args - Arguments to create a VPS.
     * @example
     * // Create one VPS
     * const VPS = await prisma.vPS.create({
     *   data: {
     *     // ... data to create a VPS
     *   }
     * })
     * 
     */
    create<T extends VPSCreateArgs>(args: SelectSubset<T, VPSCreateArgs<ExtArgs>>): Prisma__VPSClient<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many VPS.
     * @param {VPSCreateManyArgs} args - Arguments to create many VPS.
     * @example
     * // Create many VPS
     * const vPS = await prisma.vPS.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends VPSCreateManyArgs>(args?: SelectSubset<T, VPSCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a VPS.
     * @param {VPSDeleteArgs} args - Arguments to delete one VPS.
     * @example
     * // Delete one VPS
     * const VPS = await prisma.vPS.delete({
     *   where: {
     *     // ... filter to delete one VPS
     *   }
     * })
     * 
     */
    delete<T extends VPSDeleteArgs>(args: SelectSubset<T, VPSDeleteArgs<ExtArgs>>): Prisma__VPSClient<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one VPS.
     * @param {VPSUpdateArgs} args - Arguments to update one VPS.
     * @example
     * // Update one VPS
     * const vPS = await prisma.vPS.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends VPSUpdateArgs>(args: SelectSubset<T, VPSUpdateArgs<ExtArgs>>): Prisma__VPSClient<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more VPS.
     * @param {VPSDeleteManyArgs} args - Arguments to filter VPS to delete.
     * @example
     * // Delete a few VPS
     * const { count } = await prisma.vPS.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends VPSDeleteManyArgs>(args?: SelectSubset<T, VPSDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more VPS.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VPSUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many VPS
     * const vPS = await prisma.vPS.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends VPSUpdateManyArgs>(args: SelectSubset<T, VPSUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one VPS.
     * @param {VPSUpsertArgs} args - Arguments to update or create a VPS.
     * @example
     * // Update or create a VPS
     * const vPS = await prisma.vPS.upsert({
     *   create: {
     *     // ... data to create a VPS
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the VPS we want to update
     *   }
     * })
     */
    upsert<T extends VPSUpsertArgs>(args: SelectSubset<T, VPSUpsertArgs<ExtArgs>>): Prisma__VPSClient<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of VPS.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VPSCountArgs} args - Arguments to filter VPS to count.
     * @example
     * // Count the number of VPS
     * const count = await prisma.vPS.count({
     *   where: {
     *     // ... the filter for the VPS we want to count
     *   }
     * })
    **/
    count<T extends VPSCountArgs>(
      args?: Subset<T, VPSCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VPSCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a VPS.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VPSAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VPSAggregateArgs>(args: Subset<T, VPSAggregateArgs>): Prisma.PrismaPromise<GetVPSAggregateType<T>>

    /**
     * Group by VPS.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VPSGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VPSGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VPSGroupByArgs['orderBy'] }
        : { orderBy?: VPSGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VPSGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVPSGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the VPS model
   */
  readonly fields: VPSFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for VPS.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__VPSClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    activities<T extends VPS$activitiesArgs<ExtArgs> = {}>(args?: Subset<T, VPS$activitiesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    domains<T extends VPS$domainsArgs<ExtArgs> = {}>(args?: Subset<T, VPS$domainsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    websites<T extends VPS$websitesArgs<ExtArgs> = {}>(args?: Subset<T, VPS$websitesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the VPS model
   */
  interface VPSFieldRefs {
    readonly id: FieldRef<"VPS", 'String'>
    readonly name: FieldRef<"VPS", 'String'>
    readonly provider: FieldRef<"VPS", 'String'>
    readonly status: FieldRef<"VPS", 'VPSStatus'>
    readonly ipAddress: FieldRef<"VPS", 'String'>
    readonly specs: FieldRef<"VPS", 'Json'>
    readonly sshPort: FieldRef<"VPS", 'Int'>
    readonly sshKey: FieldRef<"VPS", 'String'>
    readonly username: FieldRef<"VPS", 'String'>
    readonly password: FieldRef<"VPS", 'String'>
    readonly expiresAt: FieldRef<"VPS", 'DateTime'>
    readonly notes: FieldRef<"VPS", 'String'>
    readonly createdAt: FieldRef<"VPS", 'DateTime'>
    readonly updatedAt: FieldRef<"VPS", 'DateTime'>
    readonly createdBy: FieldRef<"VPS", 'String'>
    readonly cpanelUrl: FieldRef<"VPS", 'String'>
  }
    

  // Custom InputTypes
  /**
   * VPS findUnique
   */
  export type VPSFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    /**
     * Filter, which VPS to fetch.
     */
    where: VPSWhereUniqueInput
  }

  /**
   * VPS findUniqueOrThrow
   */
  export type VPSFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    /**
     * Filter, which VPS to fetch.
     */
    where: VPSWhereUniqueInput
  }

  /**
   * VPS findFirst
   */
  export type VPSFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    /**
     * Filter, which VPS to fetch.
     */
    where?: VPSWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VPS to fetch.
     */
    orderBy?: VPSOrderByWithRelationInput | VPSOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VPS.
     */
    cursor?: VPSWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VPS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VPS.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VPS.
     */
    distinct?: VPSScalarFieldEnum | VPSScalarFieldEnum[]
  }

  /**
   * VPS findFirstOrThrow
   */
  export type VPSFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    /**
     * Filter, which VPS to fetch.
     */
    where?: VPSWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VPS to fetch.
     */
    orderBy?: VPSOrderByWithRelationInput | VPSOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VPS.
     */
    cursor?: VPSWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VPS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VPS.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VPS.
     */
    distinct?: VPSScalarFieldEnum | VPSScalarFieldEnum[]
  }

  /**
   * VPS findMany
   */
  export type VPSFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    /**
     * Filter, which VPS to fetch.
     */
    where?: VPSWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VPS to fetch.
     */
    orderBy?: VPSOrderByWithRelationInput | VPSOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing VPS.
     */
    cursor?: VPSWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VPS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VPS.
     */
    skip?: number
    distinct?: VPSScalarFieldEnum | VPSScalarFieldEnum[]
  }

  /**
   * VPS create
   */
  export type VPSCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    /**
     * The data needed to create a VPS.
     */
    data: XOR<VPSCreateInput, VPSUncheckedCreateInput>
  }

  /**
   * VPS createMany
   */
  export type VPSCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many VPS.
     */
    data: VPSCreateManyInput | VPSCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * VPS update
   */
  export type VPSUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    /**
     * The data needed to update a VPS.
     */
    data: XOR<VPSUpdateInput, VPSUncheckedUpdateInput>
    /**
     * Choose, which VPS to update.
     */
    where: VPSWhereUniqueInput
  }

  /**
   * VPS updateMany
   */
  export type VPSUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update VPS.
     */
    data: XOR<VPSUpdateManyMutationInput, VPSUncheckedUpdateManyInput>
    /**
     * Filter which VPS to update
     */
    where?: VPSWhereInput
    /**
     * Limit how many VPS to update.
     */
    limit?: number
  }

  /**
   * VPS upsert
   */
  export type VPSUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    /**
     * The filter to search for the VPS to update in case it exists.
     */
    where: VPSWhereUniqueInput
    /**
     * In case the VPS found by the `where` argument doesn't exist, create a new VPS with this data.
     */
    create: XOR<VPSCreateInput, VPSUncheckedCreateInput>
    /**
     * In case the VPS was found with the provided `where` argument, update it with this data.
     */
    update: XOR<VPSUpdateInput, VPSUncheckedUpdateInput>
  }

  /**
   * VPS delete
   */
  export type VPSDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    /**
     * Filter which VPS to delete.
     */
    where: VPSWhereUniqueInput
  }

  /**
   * VPS deleteMany
   */
  export type VPSDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VPS to delete
     */
    where?: VPSWhereInput
    /**
     * Limit how many VPS to delete.
     */
    limit?: number
  }

  /**
   * VPS.activities
   */
  export type VPS$activitiesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    where?: ActivityLogWhereInput
    orderBy?: ActivityLogOrderByWithRelationInput | ActivityLogOrderByWithRelationInput[]
    cursor?: ActivityLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ActivityLogScalarFieldEnum | ActivityLogScalarFieldEnum[]
  }

  /**
   * VPS.domains
   */
  export type VPS$domainsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    where?: DomainWhereInput
    orderBy?: DomainOrderByWithRelationInput | DomainOrderByWithRelationInput[]
    cursor?: DomainWhereUniqueInput
    take?: number
    skip?: number
    distinct?: DomainScalarFieldEnum | DomainScalarFieldEnum[]
  }

  /**
   * VPS.websites
   */
  export type VPS$websitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    where?: WebsiteWhereInput
    orderBy?: WebsiteOrderByWithRelationInput | WebsiteOrderByWithRelationInput[]
    cursor?: WebsiteWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WebsiteScalarFieldEnum | WebsiteScalarFieldEnum[]
  }

  /**
   * VPS without action
   */
  export type VPSDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
  }


  /**
   * Model Website
   */

  export type AggregateWebsite = {
    _count: WebsiteCountAggregateOutputType | null
    _min: WebsiteMinAggregateOutputType | null
    _max: WebsiteMaxAggregateOutputType | null
  }

  export type WebsiteMinAggregateOutputType = {
    id: string | null
    name: string | null
    url: string | null
    status: $Enums.WebsiteStatus | null
    cms: string | null
    cmsVersion: string | null
    phpVersion: string | null
    sslStatus: $Enums.SSLStatus | null
    sslExpiry: Date | null
    backupStatus: string | null
    lastBackup: Date | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
    createdBy: string | null
    domainId: string | null
    hostingId: string | null
    vpsId: string | null
    password: string | null
    username: string | null
  }

  export type WebsiteMaxAggregateOutputType = {
    id: string | null
    name: string | null
    url: string | null
    status: $Enums.WebsiteStatus | null
    cms: string | null
    cmsVersion: string | null
    phpVersion: string | null
    sslStatus: $Enums.SSLStatus | null
    sslExpiry: Date | null
    backupStatus: string | null
    lastBackup: Date | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
    createdBy: string | null
    domainId: string | null
    hostingId: string | null
    vpsId: string | null
    password: string | null
    username: string | null
  }

  export type WebsiteCountAggregateOutputType = {
    id: number
    name: number
    url: number
    status: number
    cms: number
    cmsVersion: number
    phpVersion: number
    sslStatus: number
    sslExpiry: number
    backupStatus: number
    lastBackup: number
    notes: number
    createdAt: number
    updatedAt: number
    createdBy: number
    domainId: number
    hostingId: number
    vpsId: number
    password: number
    username: number
    _all: number
  }


  export type WebsiteMinAggregateInputType = {
    id?: true
    name?: true
    url?: true
    status?: true
    cms?: true
    cmsVersion?: true
    phpVersion?: true
    sslStatus?: true
    sslExpiry?: true
    backupStatus?: true
    lastBackup?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
    domainId?: true
    hostingId?: true
    vpsId?: true
    password?: true
    username?: true
  }

  export type WebsiteMaxAggregateInputType = {
    id?: true
    name?: true
    url?: true
    status?: true
    cms?: true
    cmsVersion?: true
    phpVersion?: true
    sslStatus?: true
    sslExpiry?: true
    backupStatus?: true
    lastBackup?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
    domainId?: true
    hostingId?: true
    vpsId?: true
    password?: true
    username?: true
  }

  export type WebsiteCountAggregateInputType = {
    id?: true
    name?: true
    url?: true
    status?: true
    cms?: true
    cmsVersion?: true
    phpVersion?: true
    sslStatus?: true
    sslExpiry?: true
    backupStatus?: true
    lastBackup?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    createdBy?: true
    domainId?: true
    hostingId?: true
    vpsId?: true
    password?: true
    username?: true
    _all?: true
  }

  export type WebsiteAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Website to aggregate.
     */
    where?: WebsiteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Websites to fetch.
     */
    orderBy?: WebsiteOrderByWithRelationInput | WebsiteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: WebsiteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Websites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Websites.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Websites
    **/
    _count?: true | WebsiteCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: WebsiteMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: WebsiteMaxAggregateInputType
  }

  export type GetWebsiteAggregateType<T extends WebsiteAggregateArgs> = {
        [P in keyof T & keyof AggregateWebsite]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateWebsite[P]>
      : GetScalarType<T[P], AggregateWebsite[P]>
  }




  export type WebsiteGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WebsiteWhereInput
    orderBy?: WebsiteOrderByWithAggregationInput | WebsiteOrderByWithAggregationInput[]
    by: WebsiteScalarFieldEnum[] | WebsiteScalarFieldEnum
    having?: WebsiteScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: WebsiteCountAggregateInputType | true
    _min?: WebsiteMinAggregateInputType
    _max?: WebsiteMaxAggregateInputType
  }

  export type WebsiteGroupByOutputType = {
    id: string
    name: string
    url: string | null
    status: $Enums.WebsiteStatus
    cms: string | null
    cmsVersion: string | null
    phpVersion: string | null
    sslStatus: $Enums.SSLStatus
    sslExpiry: Date | null
    backupStatus: string | null
    lastBackup: Date | null
    notes: string | null
    createdAt: Date
    updatedAt: Date
    createdBy: string
    domainId: string | null
    hostingId: string | null
    vpsId: string | null
    password: string | null
    username: string | null
    _count: WebsiteCountAggregateOutputType | null
    _min: WebsiteMinAggregateOutputType | null
    _max: WebsiteMaxAggregateOutputType | null
  }

  type GetWebsiteGroupByPayload<T extends WebsiteGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<WebsiteGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof WebsiteGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], WebsiteGroupByOutputType[P]>
            : GetScalarType<T[P], WebsiteGroupByOutputType[P]>
        }
      >
    >


  export type WebsiteSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    url?: boolean
    status?: boolean
    cms?: boolean
    cmsVersion?: boolean
    phpVersion?: boolean
    sslStatus?: boolean
    sslExpiry?: boolean
    backupStatus?: boolean
    lastBackup?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    createdBy?: boolean
    domainId?: boolean
    hostingId?: boolean
    vpsId?: boolean
    password?: boolean
    username?: boolean
    activities?: boolean | Website$activitiesArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    domain?: boolean | Website$domainArgs<ExtArgs>
    hosting?: boolean | Website$hostingArgs<ExtArgs>
    vps?: boolean | Website$vpsArgs<ExtArgs>
    _count?: boolean | WebsiteCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["website"]>



  export type WebsiteSelectScalar = {
    id?: boolean
    name?: boolean
    url?: boolean
    status?: boolean
    cms?: boolean
    cmsVersion?: boolean
    phpVersion?: boolean
    sslStatus?: boolean
    sslExpiry?: boolean
    backupStatus?: boolean
    lastBackup?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    createdBy?: boolean
    domainId?: boolean
    hostingId?: boolean
    vpsId?: boolean
    password?: boolean
    username?: boolean
  }

  export type WebsiteOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "url" | "status" | "cms" | "cmsVersion" | "phpVersion" | "sslStatus" | "sslExpiry" | "backupStatus" | "lastBackup" | "notes" | "createdAt" | "updatedAt" | "createdBy" | "domainId" | "hostingId" | "vpsId" | "password" | "username", ExtArgs["result"]["website"]>
  export type WebsiteInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    activities?: boolean | Website$activitiesArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    domain?: boolean | Website$domainArgs<ExtArgs>
    hosting?: boolean | Website$hostingArgs<ExtArgs>
    vps?: boolean | Website$vpsArgs<ExtArgs>
    _count?: boolean | WebsiteCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $WebsitePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Website"
    objects: {
      activities: Prisma.$ActivityLogPayload<ExtArgs>[]
      user: Prisma.$UserPayload<ExtArgs>
      domain: Prisma.$DomainPayload<ExtArgs> | null
      hosting: Prisma.$HostingPayload<ExtArgs> | null
      vps: Prisma.$VPSPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      url: string | null
      status: $Enums.WebsiteStatus
      cms: string | null
      cmsVersion: string | null
      phpVersion: string | null
      sslStatus: $Enums.SSLStatus
      sslExpiry: Date | null
      backupStatus: string | null
      lastBackup: Date | null
      notes: string | null
      createdAt: Date
      updatedAt: Date
      createdBy: string
      domainId: string | null
      hostingId: string | null
      vpsId: string | null
      password: string | null
      username: string | null
    }, ExtArgs["result"]["website"]>
    composites: {}
  }

  type WebsiteGetPayload<S extends boolean | null | undefined | WebsiteDefaultArgs> = $Result.GetResult<Prisma.$WebsitePayload, S>

  type WebsiteCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<WebsiteFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: WebsiteCountAggregateInputType | true
    }

  export interface WebsiteDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Website'], meta: { name: 'Website' } }
    /**
     * Find zero or one Website that matches the filter.
     * @param {WebsiteFindUniqueArgs} args - Arguments to find a Website
     * @example
     * // Get one Website
     * const website = await prisma.website.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends WebsiteFindUniqueArgs>(args: SelectSubset<T, WebsiteFindUniqueArgs<ExtArgs>>): Prisma__WebsiteClient<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Website that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {WebsiteFindUniqueOrThrowArgs} args - Arguments to find a Website
     * @example
     * // Get one Website
     * const website = await prisma.website.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends WebsiteFindUniqueOrThrowArgs>(args: SelectSubset<T, WebsiteFindUniqueOrThrowArgs<ExtArgs>>): Prisma__WebsiteClient<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Website that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebsiteFindFirstArgs} args - Arguments to find a Website
     * @example
     * // Get one Website
     * const website = await prisma.website.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends WebsiteFindFirstArgs>(args?: SelectSubset<T, WebsiteFindFirstArgs<ExtArgs>>): Prisma__WebsiteClient<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Website that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebsiteFindFirstOrThrowArgs} args - Arguments to find a Website
     * @example
     * // Get one Website
     * const website = await prisma.website.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends WebsiteFindFirstOrThrowArgs>(args?: SelectSubset<T, WebsiteFindFirstOrThrowArgs<ExtArgs>>): Prisma__WebsiteClient<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Websites that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebsiteFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Websites
     * const websites = await prisma.website.findMany()
     * 
     * // Get first 10 Websites
     * const websites = await prisma.website.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const websiteWithIdOnly = await prisma.website.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends WebsiteFindManyArgs>(args?: SelectSubset<T, WebsiteFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Website.
     * @param {WebsiteCreateArgs} args - Arguments to create a Website.
     * @example
     * // Create one Website
     * const Website = await prisma.website.create({
     *   data: {
     *     // ... data to create a Website
     *   }
     * })
     * 
     */
    create<T extends WebsiteCreateArgs>(args: SelectSubset<T, WebsiteCreateArgs<ExtArgs>>): Prisma__WebsiteClient<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Websites.
     * @param {WebsiteCreateManyArgs} args - Arguments to create many Websites.
     * @example
     * // Create many Websites
     * const website = await prisma.website.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends WebsiteCreateManyArgs>(args?: SelectSubset<T, WebsiteCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Website.
     * @param {WebsiteDeleteArgs} args - Arguments to delete one Website.
     * @example
     * // Delete one Website
     * const Website = await prisma.website.delete({
     *   where: {
     *     // ... filter to delete one Website
     *   }
     * })
     * 
     */
    delete<T extends WebsiteDeleteArgs>(args: SelectSubset<T, WebsiteDeleteArgs<ExtArgs>>): Prisma__WebsiteClient<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Website.
     * @param {WebsiteUpdateArgs} args - Arguments to update one Website.
     * @example
     * // Update one Website
     * const website = await prisma.website.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends WebsiteUpdateArgs>(args: SelectSubset<T, WebsiteUpdateArgs<ExtArgs>>): Prisma__WebsiteClient<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Websites.
     * @param {WebsiteDeleteManyArgs} args - Arguments to filter Websites to delete.
     * @example
     * // Delete a few Websites
     * const { count } = await prisma.website.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends WebsiteDeleteManyArgs>(args?: SelectSubset<T, WebsiteDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Websites.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebsiteUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Websites
     * const website = await prisma.website.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends WebsiteUpdateManyArgs>(args: SelectSubset<T, WebsiteUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Website.
     * @param {WebsiteUpsertArgs} args - Arguments to update or create a Website.
     * @example
     * // Update or create a Website
     * const website = await prisma.website.upsert({
     *   create: {
     *     // ... data to create a Website
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Website we want to update
     *   }
     * })
     */
    upsert<T extends WebsiteUpsertArgs>(args: SelectSubset<T, WebsiteUpsertArgs<ExtArgs>>): Prisma__WebsiteClient<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Websites.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebsiteCountArgs} args - Arguments to filter Websites to count.
     * @example
     * // Count the number of Websites
     * const count = await prisma.website.count({
     *   where: {
     *     // ... the filter for the Websites we want to count
     *   }
     * })
    **/
    count<T extends WebsiteCountArgs>(
      args?: Subset<T, WebsiteCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], WebsiteCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Website.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebsiteAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends WebsiteAggregateArgs>(args: Subset<T, WebsiteAggregateArgs>): Prisma.PrismaPromise<GetWebsiteAggregateType<T>>

    /**
     * Group by Website.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebsiteGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends WebsiteGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: WebsiteGroupByArgs['orderBy'] }
        : { orderBy?: WebsiteGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, WebsiteGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetWebsiteGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Website model
   */
  readonly fields: WebsiteFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Website.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__WebsiteClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    activities<T extends Website$activitiesArgs<ExtArgs> = {}>(args?: Subset<T, Website$activitiesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    domain<T extends Website$domainArgs<ExtArgs> = {}>(args?: Subset<T, Website$domainArgs<ExtArgs>>): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    hosting<T extends Website$hostingArgs<ExtArgs> = {}>(args?: Subset<T, Website$hostingArgs<ExtArgs>>): Prisma__HostingClient<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    vps<T extends Website$vpsArgs<ExtArgs> = {}>(args?: Subset<T, Website$vpsArgs<ExtArgs>>): Prisma__VPSClient<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Website model
   */
  interface WebsiteFieldRefs {
    readonly id: FieldRef<"Website", 'String'>
    readonly name: FieldRef<"Website", 'String'>
    readonly url: FieldRef<"Website", 'String'>
    readonly status: FieldRef<"Website", 'WebsiteStatus'>
    readonly cms: FieldRef<"Website", 'String'>
    readonly cmsVersion: FieldRef<"Website", 'String'>
    readonly phpVersion: FieldRef<"Website", 'String'>
    readonly sslStatus: FieldRef<"Website", 'SSLStatus'>
    readonly sslExpiry: FieldRef<"Website", 'DateTime'>
    readonly backupStatus: FieldRef<"Website", 'String'>
    readonly lastBackup: FieldRef<"Website", 'DateTime'>
    readonly notes: FieldRef<"Website", 'String'>
    readonly createdAt: FieldRef<"Website", 'DateTime'>
    readonly updatedAt: FieldRef<"Website", 'DateTime'>
    readonly createdBy: FieldRef<"Website", 'String'>
    readonly domainId: FieldRef<"Website", 'String'>
    readonly hostingId: FieldRef<"Website", 'String'>
    readonly vpsId: FieldRef<"Website", 'String'>
    readonly password: FieldRef<"Website", 'String'>
    readonly username: FieldRef<"Website", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Website findUnique
   */
  export type WebsiteFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    /**
     * Filter, which Website to fetch.
     */
    where: WebsiteWhereUniqueInput
  }

  /**
   * Website findUniqueOrThrow
   */
  export type WebsiteFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    /**
     * Filter, which Website to fetch.
     */
    where: WebsiteWhereUniqueInput
  }

  /**
   * Website findFirst
   */
  export type WebsiteFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    /**
     * Filter, which Website to fetch.
     */
    where?: WebsiteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Websites to fetch.
     */
    orderBy?: WebsiteOrderByWithRelationInput | WebsiteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Websites.
     */
    cursor?: WebsiteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Websites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Websites.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Websites.
     */
    distinct?: WebsiteScalarFieldEnum | WebsiteScalarFieldEnum[]
  }

  /**
   * Website findFirstOrThrow
   */
  export type WebsiteFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    /**
     * Filter, which Website to fetch.
     */
    where?: WebsiteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Websites to fetch.
     */
    orderBy?: WebsiteOrderByWithRelationInput | WebsiteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Websites.
     */
    cursor?: WebsiteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Websites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Websites.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Websites.
     */
    distinct?: WebsiteScalarFieldEnum | WebsiteScalarFieldEnum[]
  }

  /**
   * Website findMany
   */
  export type WebsiteFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    /**
     * Filter, which Websites to fetch.
     */
    where?: WebsiteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Websites to fetch.
     */
    orderBy?: WebsiteOrderByWithRelationInput | WebsiteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Websites.
     */
    cursor?: WebsiteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Websites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Websites.
     */
    skip?: number
    distinct?: WebsiteScalarFieldEnum | WebsiteScalarFieldEnum[]
  }

  /**
   * Website create
   */
  export type WebsiteCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    /**
     * The data needed to create a Website.
     */
    data: XOR<WebsiteCreateInput, WebsiteUncheckedCreateInput>
  }

  /**
   * Website createMany
   */
  export type WebsiteCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Websites.
     */
    data: WebsiteCreateManyInput | WebsiteCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Website update
   */
  export type WebsiteUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    /**
     * The data needed to update a Website.
     */
    data: XOR<WebsiteUpdateInput, WebsiteUncheckedUpdateInput>
    /**
     * Choose, which Website to update.
     */
    where: WebsiteWhereUniqueInput
  }

  /**
   * Website updateMany
   */
  export type WebsiteUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Websites.
     */
    data: XOR<WebsiteUpdateManyMutationInput, WebsiteUncheckedUpdateManyInput>
    /**
     * Filter which Websites to update
     */
    where?: WebsiteWhereInput
    /**
     * Limit how many Websites to update.
     */
    limit?: number
  }

  /**
   * Website upsert
   */
  export type WebsiteUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    /**
     * The filter to search for the Website to update in case it exists.
     */
    where: WebsiteWhereUniqueInput
    /**
     * In case the Website found by the `where` argument doesn't exist, create a new Website with this data.
     */
    create: XOR<WebsiteCreateInput, WebsiteUncheckedCreateInput>
    /**
     * In case the Website was found with the provided `where` argument, update it with this data.
     */
    update: XOR<WebsiteUpdateInput, WebsiteUncheckedUpdateInput>
  }

  /**
   * Website delete
   */
  export type WebsiteDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    /**
     * Filter which Website to delete.
     */
    where: WebsiteWhereUniqueInput
  }

  /**
   * Website deleteMany
   */
  export type WebsiteDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Websites to delete
     */
    where?: WebsiteWhereInput
    /**
     * Limit how many Websites to delete.
     */
    limit?: number
  }

  /**
   * Website.activities
   */
  export type Website$activitiesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    where?: ActivityLogWhereInput
    orderBy?: ActivityLogOrderByWithRelationInput | ActivityLogOrderByWithRelationInput[]
    cursor?: ActivityLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ActivityLogScalarFieldEnum | ActivityLogScalarFieldEnum[]
  }

  /**
   * Website.domain
   */
  export type Website$domainArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    where?: DomainWhereInput
  }

  /**
   * Website.hosting
   */
  export type Website$hostingArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    where?: HostingWhereInput
  }

  /**
   * Website.vps
   */
  export type Website$vpsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    where?: VPSWhereInput
  }

  /**
   * Website without action
   */
  export type WebsiteDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
  }


  /**
   * Model ActivityLog
   */

  export type AggregateActivityLog = {
    _count: ActivityLogCountAggregateOutputType | null
    _min: ActivityLogMinAggregateOutputType | null
    _max: ActivityLogMaxAggregateOutputType | null
  }

  export type ActivityLogMinAggregateOutputType = {
    id: string | null
    action: $Enums.ActivityType | null
    entity: $Enums.EntityType | null
    entityId: string | null
    description: string | null
    ipAddress: string | null
    userAgent: string | null
    createdAt: Date | null
    userId: string | null
    domainId: string | null
    hostingId: string | null
    vpsId: string | null
    websiteId: string | null
  }

  export type ActivityLogMaxAggregateOutputType = {
    id: string | null
    action: $Enums.ActivityType | null
    entity: $Enums.EntityType | null
    entityId: string | null
    description: string | null
    ipAddress: string | null
    userAgent: string | null
    createdAt: Date | null
    userId: string | null
    domainId: string | null
    hostingId: string | null
    vpsId: string | null
    websiteId: string | null
  }

  export type ActivityLogCountAggregateOutputType = {
    id: number
    action: number
    entity: number
    entityId: number
    description: number
    metadata: number
    ipAddress: number
    userAgent: number
    createdAt: number
    userId: number
    domainId: number
    hostingId: number
    vpsId: number
    websiteId: number
    _all: number
  }


  export type ActivityLogMinAggregateInputType = {
    id?: true
    action?: true
    entity?: true
    entityId?: true
    description?: true
    ipAddress?: true
    userAgent?: true
    createdAt?: true
    userId?: true
    domainId?: true
    hostingId?: true
    vpsId?: true
    websiteId?: true
  }

  export type ActivityLogMaxAggregateInputType = {
    id?: true
    action?: true
    entity?: true
    entityId?: true
    description?: true
    ipAddress?: true
    userAgent?: true
    createdAt?: true
    userId?: true
    domainId?: true
    hostingId?: true
    vpsId?: true
    websiteId?: true
  }

  export type ActivityLogCountAggregateInputType = {
    id?: true
    action?: true
    entity?: true
    entityId?: true
    description?: true
    metadata?: true
    ipAddress?: true
    userAgent?: true
    createdAt?: true
    userId?: true
    domainId?: true
    hostingId?: true
    vpsId?: true
    websiteId?: true
    _all?: true
  }

  export type ActivityLogAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ActivityLog to aggregate.
     */
    where?: ActivityLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ActivityLogs to fetch.
     */
    orderBy?: ActivityLogOrderByWithRelationInput | ActivityLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ActivityLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ActivityLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ActivityLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ActivityLogs
    **/
    _count?: true | ActivityLogCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ActivityLogMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ActivityLogMaxAggregateInputType
  }

  export type GetActivityLogAggregateType<T extends ActivityLogAggregateArgs> = {
        [P in keyof T & keyof AggregateActivityLog]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateActivityLog[P]>
      : GetScalarType<T[P], AggregateActivityLog[P]>
  }




  export type ActivityLogGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ActivityLogWhereInput
    orderBy?: ActivityLogOrderByWithAggregationInput | ActivityLogOrderByWithAggregationInput[]
    by: ActivityLogScalarFieldEnum[] | ActivityLogScalarFieldEnum
    having?: ActivityLogScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ActivityLogCountAggregateInputType | true
    _min?: ActivityLogMinAggregateInputType
    _max?: ActivityLogMaxAggregateInputType
  }

  export type ActivityLogGroupByOutputType = {
    id: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata: JsonValue | null
    ipAddress: string | null
    userAgent: string | null
    createdAt: Date
    userId: string
    domainId: string | null
    hostingId: string | null
    vpsId: string | null
    websiteId: string | null
    _count: ActivityLogCountAggregateOutputType | null
    _min: ActivityLogMinAggregateOutputType | null
    _max: ActivityLogMaxAggregateOutputType | null
  }

  type GetActivityLogGroupByPayload<T extends ActivityLogGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ActivityLogGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ActivityLogGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ActivityLogGroupByOutputType[P]>
            : GetScalarType<T[P], ActivityLogGroupByOutputType[P]>
        }
      >
    >


  export type ActivityLogSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    action?: boolean
    entity?: boolean
    entityId?: boolean
    description?: boolean
    metadata?: boolean
    ipAddress?: boolean
    userAgent?: boolean
    createdAt?: boolean
    userId?: boolean
    domainId?: boolean
    hostingId?: boolean
    vpsId?: boolean
    websiteId?: boolean
    domain?: boolean | ActivityLog$domainArgs<ExtArgs>
    hosting?: boolean | ActivityLog$hostingArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    vps?: boolean | ActivityLog$vpsArgs<ExtArgs>
    website?: boolean | ActivityLog$websiteArgs<ExtArgs>
  }, ExtArgs["result"]["activityLog"]>



  export type ActivityLogSelectScalar = {
    id?: boolean
    action?: boolean
    entity?: boolean
    entityId?: boolean
    description?: boolean
    metadata?: boolean
    ipAddress?: boolean
    userAgent?: boolean
    createdAt?: boolean
    userId?: boolean
    domainId?: boolean
    hostingId?: boolean
    vpsId?: boolean
    websiteId?: boolean
  }

  export type ActivityLogOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "action" | "entity" | "entityId" | "description" | "metadata" | "ipAddress" | "userAgent" | "createdAt" | "userId" | "domainId" | "hostingId" | "vpsId" | "websiteId", ExtArgs["result"]["activityLog"]>
  export type ActivityLogInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    domain?: boolean | ActivityLog$domainArgs<ExtArgs>
    hosting?: boolean | ActivityLog$hostingArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    vps?: boolean | ActivityLog$vpsArgs<ExtArgs>
    website?: boolean | ActivityLog$websiteArgs<ExtArgs>
  }

  export type $ActivityLogPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ActivityLog"
    objects: {
      domain: Prisma.$DomainPayload<ExtArgs> | null
      hosting: Prisma.$HostingPayload<ExtArgs> | null
      user: Prisma.$UserPayload<ExtArgs>
      vps: Prisma.$VPSPayload<ExtArgs> | null
      website: Prisma.$WebsitePayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      action: $Enums.ActivityType
      entity: $Enums.EntityType
      entityId: string
      description: string
      metadata: Prisma.JsonValue | null
      ipAddress: string | null
      userAgent: string | null
      createdAt: Date
      userId: string
      domainId: string | null
      hostingId: string | null
      vpsId: string | null
      websiteId: string | null
    }, ExtArgs["result"]["activityLog"]>
    composites: {}
  }

  type ActivityLogGetPayload<S extends boolean | null | undefined | ActivityLogDefaultArgs> = $Result.GetResult<Prisma.$ActivityLogPayload, S>

  type ActivityLogCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ActivityLogFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ActivityLogCountAggregateInputType | true
    }

  export interface ActivityLogDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ActivityLog'], meta: { name: 'ActivityLog' } }
    /**
     * Find zero or one ActivityLog that matches the filter.
     * @param {ActivityLogFindUniqueArgs} args - Arguments to find a ActivityLog
     * @example
     * // Get one ActivityLog
     * const activityLog = await prisma.activityLog.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ActivityLogFindUniqueArgs>(args: SelectSubset<T, ActivityLogFindUniqueArgs<ExtArgs>>): Prisma__ActivityLogClient<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one ActivityLog that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ActivityLogFindUniqueOrThrowArgs} args - Arguments to find a ActivityLog
     * @example
     * // Get one ActivityLog
     * const activityLog = await prisma.activityLog.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ActivityLogFindUniqueOrThrowArgs>(args: SelectSubset<T, ActivityLogFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ActivityLogClient<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ActivityLog that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActivityLogFindFirstArgs} args - Arguments to find a ActivityLog
     * @example
     * // Get one ActivityLog
     * const activityLog = await prisma.activityLog.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ActivityLogFindFirstArgs>(args?: SelectSubset<T, ActivityLogFindFirstArgs<ExtArgs>>): Prisma__ActivityLogClient<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ActivityLog that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActivityLogFindFirstOrThrowArgs} args - Arguments to find a ActivityLog
     * @example
     * // Get one ActivityLog
     * const activityLog = await prisma.activityLog.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ActivityLogFindFirstOrThrowArgs>(args?: SelectSubset<T, ActivityLogFindFirstOrThrowArgs<ExtArgs>>): Prisma__ActivityLogClient<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more ActivityLogs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActivityLogFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ActivityLogs
     * const activityLogs = await prisma.activityLog.findMany()
     * 
     * // Get first 10 ActivityLogs
     * const activityLogs = await prisma.activityLog.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const activityLogWithIdOnly = await prisma.activityLog.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ActivityLogFindManyArgs>(args?: SelectSubset<T, ActivityLogFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a ActivityLog.
     * @param {ActivityLogCreateArgs} args - Arguments to create a ActivityLog.
     * @example
     * // Create one ActivityLog
     * const ActivityLog = await prisma.activityLog.create({
     *   data: {
     *     // ... data to create a ActivityLog
     *   }
     * })
     * 
     */
    create<T extends ActivityLogCreateArgs>(args: SelectSubset<T, ActivityLogCreateArgs<ExtArgs>>): Prisma__ActivityLogClient<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many ActivityLogs.
     * @param {ActivityLogCreateManyArgs} args - Arguments to create many ActivityLogs.
     * @example
     * // Create many ActivityLogs
     * const activityLog = await prisma.activityLog.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ActivityLogCreateManyArgs>(args?: SelectSubset<T, ActivityLogCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a ActivityLog.
     * @param {ActivityLogDeleteArgs} args - Arguments to delete one ActivityLog.
     * @example
     * // Delete one ActivityLog
     * const ActivityLog = await prisma.activityLog.delete({
     *   where: {
     *     // ... filter to delete one ActivityLog
     *   }
     * })
     * 
     */
    delete<T extends ActivityLogDeleteArgs>(args: SelectSubset<T, ActivityLogDeleteArgs<ExtArgs>>): Prisma__ActivityLogClient<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one ActivityLog.
     * @param {ActivityLogUpdateArgs} args - Arguments to update one ActivityLog.
     * @example
     * // Update one ActivityLog
     * const activityLog = await prisma.activityLog.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ActivityLogUpdateArgs>(args: SelectSubset<T, ActivityLogUpdateArgs<ExtArgs>>): Prisma__ActivityLogClient<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more ActivityLogs.
     * @param {ActivityLogDeleteManyArgs} args - Arguments to filter ActivityLogs to delete.
     * @example
     * // Delete a few ActivityLogs
     * const { count } = await prisma.activityLog.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ActivityLogDeleteManyArgs>(args?: SelectSubset<T, ActivityLogDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ActivityLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActivityLogUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ActivityLogs
     * const activityLog = await prisma.activityLog.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ActivityLogUpdateManyArgs>(args: SelectSubset<T, ActivityLogUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one ActivityLog.
     * @param {ActivityLogUpsertArgs} args - Arguments to update or create a ActivityLog.
     * @example
     * // Update or create a ActivityLog
     * const activityLog = await prisma.activityLog.upsert({
     *   create: {
     *     // ... data to create a ActivityLog
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ActivityLog we want to update
     *   }
     * })
     */
    upsert<T extends ActivityLogUpsertArgs>(args: SelectSubset<T, ActivityLogUpsertArgs<ExtArgs>>): Prisma__ActivityLogClient<$Result.GetResult<Prisma.$ActivityLogPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of ActivityLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActivityLogCountArgs} args - Arguments to filter ActivityLogs to count.
     * @example
     * // Count the number of ActivityLogs
     * const count = await prisma.activityLog.count({
     *   where: {
     *     // ... the filter for the ActivityLogs we want to count
     *   }
     * })
    **/
    count<T extends ActivityLogCountArgs>(
      args?: Subset<T, ActivityLogCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ActivityLogCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ActivityLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActivityLogAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ActivityLogAggregateArgs>(args: Subset<T, ActivityLogAggregateArgs>): Prisma.PrismaPromise<GetActivityLogAggregateType<T>>

    /**
     * Group by ActivityLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActivityLogGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ActivityLogGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ActivityLogGroupByArgs['orderBy'] }
        : { orderBy?: ActivityLogGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ActivityLogGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetActivityLogGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ActivityLog model
   */
  readonly fields: ActivityLogFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ActivityLog.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ActivityLogClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    domain<T extends ActivityLog$domainArgs<ExtArgs> = {}>(args?: Subset<T, ActivityLog$domainArgs<ExtArgs>>): Prisma__DomainClient<$Result.GetResult<Prisma.$DomainPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    hosting<T extends ActivityLog$hostingArgs<ExtArgs> = {}>(args?: Subset<T, ActivityLog$hostingArgs<ExtArgs>>): Prisma__HostingClient<$Result.GetResult<Prisma.$HostingPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    vps<T extends ActivityLog$vpsArgs<ExtArgs> = {}>(args?: Subset<T, ActivityLog$vpsArgs<ExtArgs>>): Prisma__VPSClient<$Result.GetResult<Prisma.$VPSPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    website<T extends ActivityLog$websiteArgs<ExtArgs> = {}>(args?: Subset<T, ActivityLog$websiteArgs<ExtArgs>>): Prisma__WebsiteClient<$Result.GetResult<Prisma.$WebsitePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ActivityLog model
   */
  interface ActivityLogFieldRefs {
    readonly id: FieldRef<"ActivityLog", 'String'>
    readonly action: FieldRef<"ActivityLog", 'ActivityType'>
    readonly entity: FieldRef<"ActivityLog", 'EntityType'>
    readonly entityId: FieldRef<"ActivityLog", 'String'>
    readonly description: FieldRef<"ActivityLog", 'String'>
    readonly metadata: FieldRef<"ActivityLog", 'Json'>
    readonly ipAddress: FieldRef<"ActivityLog", 'String'>
    readonly userAgent: FieldRef<"ActivityLog", 'String'>
    readonly createdAt: FieldRef<"ActivityLog", 'DateTime'>
    readonly userId: FieldRef<"ActivityLog", 'String'>
    readonly domainId: FieldRef<"ActivityLog", 'String'>
    readonly hostingId: FieldRef<"ActivityLog", 'String'>
    readonly vpsId: FieldRef<"ActivityLog", 'String'>
    readonly websiteId: FieldRef<"ActivityLog", 'String'>
  }
    

  // Custom InputTypes
  /**
   * ActivityLog findUnique
   */
  export type ActivityLogFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    /**
     * Filter, which ActivityLog to fetch.
     */
    where: ActivityLogWhereUniqueInput
  }

  /**
   * ActivityLog findUniqueOrThrow
   */
  export type ActivityLogFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    /**
     * Filter, which ActivityLog to fetch.
     */
    where: ActivityLogWhereUniqueInput
  }

  /**
   * ActivityLog findFirst
   */
  export type ActivityLogFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    /**
     * Filter, which ActivityLog to fetch.
     */
    where?: ActivityLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ActivityLogs to fetch.
     */
    orderBy?: ActivityLogOrderByWithRelationInput | ActivityLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ActivityLogs.
     */
    cursor?: ActivityLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ActivityLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ActivityLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ActivityLogs.
     */
    distinct?: ActivityLogScalarFieldEnum | ActivityLogScalarFieldEnum[]
  }

  /**
   * ActivityLog findFirstOrThrow
   */
  export type ActivityLogFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    /**
     * Filter, which ActivityLog to fetch.
     */
    where?: ActivityLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ActivityLogs to fetch.
     */
    orderBy?: ActivityLogOrderByWithRelationInput | ActivityLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ActivityLogs.
     */
    cursor?: ActivityLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ActivityLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ActivityLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ActivityLogs.
     */
    distinct?: ActivityLogScalarFieldEnum | ActivityLogScalarFieldEnum[]
  }

  /**
   * ActivityLog findMany
   */
  export type ActivityLogFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    /**
     * Filter, which ActivityLogs to fetch.
     */
    where?: ActivityLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ActivityLogs to fetch.
     */
    orderBy?: ActivityLogOrderByWithRelationInput | ActivityLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ActivityLogs.
     */
    cursor?: ActivityLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ActivityLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ActivityLogs.
     */
    skip?: number
    distinct?: ActivityLogScalarFieldEnum | ActivityLogScalarFieldEnum[]
  }

  /**
   * ActivityLog create
   */
  export type ActivityLogCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    /**
     * The data needed to create a ActivityLog.
     */
    data: XOR<ActivityLogCreateInput, ActivityLogUncheckedCreateInput>
  }

  /**
   * ActivityLog createMany
   */
  export type ActivityLogCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ActivityLogs.
     */
    data: ActivityLogCreateManyInput | ActivityLogCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * ActivityLog update
   */
  export type ActivityLogUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    /**
     * The data needed to update a ActivityLog.
     */
    data: XOR<ActivityLogUpdateInput, ActivityLogUncheckedUpdateInput>
    /**
     * Choose, which ActivityLog to update.
     */
    where: ActivityLogWhereUniqueInput
  }

  /**
   * ActivityLog updateMany
   */
  export type ActivityLogUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ActivityLogs.
     */
    data: XOR<ActivityLogUpdateManyMutationInput, ActivityLogUncheckedUpdateManyInput>
    /**
     * Filter which ActivityLogs to update
     */
    where?: ActivityLogWhereInput
    /**
     * Limit how many ActivityLogs to update.
     */
    limit?: number
  }

  /**
   * ActivityLog upsert
   */
  export type ActivityLogUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    /**
     * The filter to search for the ActivityLog to update in case it exists.
     */
    where: ActivityLogWhereUniqueInput
    /**
     * In case the ActivityLog found by the `where` argument doesn't exist, create a new ActivityLog with this data.
     */
    create: XOR<ActivityLogCreateInput, ActivityLogUncheckedCreateInput>
    /**
     * In case the ActivityLog was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ActivityLogUpdateInput, ActivityLogUncheckedUpdateInput>
  }

  /**
   * ActivityLog delete
   */
  export type ActivityLogDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
    /**
     * Filter which ActivityLog to delete.
     */
    where: ActivityLogWhereUniqueInput
  }

  /**
   * ActivityLog deleteMany
   */
  export type ActivityLogDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ActivityLogs to delete
     */
    where?: ActivityLogWhereInput
    /**
     * Limit how many ActivityLogs to delete.
     */
    limit?: number
  }

  /**
   * ActivityLog.domain
   */
  export type ActivityLog$domainArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Domain
     */
    select?: DomainSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Domain
     */
    omit?: DomainOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DomainInclude<ExtArgs> | null
    where?: DomainWhereInput
  }

  /**
   * ActivityLog.hosting
   */
  export type ActivityLog$hostingArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Hosting
     */
    select?: HostingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Hosting
     */
    omit?: HostingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HostingInclude<ExtArgs> | null
    where?: HostingWhereInput
  }

  /**
   * ActivityLog.vps
   */
  export type ActivityLog$vpsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VPS
     */
    select?: VPSSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VPS
     */
    omit?: VPSOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VPSInclude<ExtArgs> | null
    where?: VPSWhereInput
  }

  /**
   * ActivityLog.website
   */
  export type ActivityLog$websiteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Website
     */
    select?: WebsiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Website
     */
    omit?: WebsiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WebsiteInclude<ExtArgs> | null
    where?: WebsiteWhereInput
  }

  /**
   * ActivityLog without action
   */
  export type ActivityLogDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ActivityLog
     */
    select?: ActivityLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ActivityLog
     */
    omit?: ActivityLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActivityLogInclude<ExtArgs> | null
  }


  /**
   * Model Setting
   */

  export type AggregateSetting = {
    _count: SettingCountAggregateOutputType | null
    _min: SettingMinAggregateOutputType | null
    _max: SettingMaxAggregateOutputType | null
  }

  export type SettingMinAggregateOutputType = {
    id: string | null
    key: string | null
    value: string | null
    type: string | null
    category: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SettingMaxAggregateOutputType = {
    id: string | null
    key: string | null
    value: string | null
    type: string | null
    category: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SettingCountAggregateOutputType = {
    id: number
    key: number
    value: number
    type: number
    category: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SettingMinAggregateInputType = {
    id?: true
    key?: true
    value?: true
    type?: true
    category?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SettingMaxAggregateInputType = {
    id?: true
    key?: true
    value?: true
    type?: true
    category?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SettingCountAggregateInputType = {
    id?: true
    key?: true
    value?: true
    type?: true
    category?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SettingAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Setting to aggregate.
     */
    where?: SettingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingOrderByWithRelationInput | SettingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SettingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Settings
    **/
    _count?: true | SettingCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SettingMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SettingMaxAggregateInputType
  }

  export type GetSettingAggregateType<T extends SettingAggregateArgs> = {
        [P in keyof T & keyof AggregateSetting]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSetting[P]>
      : GetScalarType<T[P], AggregateSetting[P]>
  }




  export type SettingGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SettingWhereInput
    orderBy?: SettingOrderByWithAggregationInput | SettingOrderByWithAggregationInput[]
    by: SettingScalarFieldEnum[] | SettingScalarFieldEnum
    having?: SettingScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SettingCountAggregateInputType | true
    _min?: SettingMinAggregateInputType
    _max?: SettingMaxAggregateInputType
  }

  export type SettingGroupByOutputType = {
    id: string
    key: string
    value: string
    type: string
    category: string
    createdAt: Date
    updatedAt: Date
    _count: SettingCountAggregateOutputType | null
    _min: SettingMinAggregateOutputType | null
    _max: SettingMaxAggregateOutputType | null
  }

  type GetSettingGroupByPayload<T extends SettingGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SettingGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SettingGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SettingGroupByOutputType[P]>
            : GetScalarType<T[P], SettingGroupByOutputType[P]>
        }
      >
    >


  export type SettingSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    key?: boolean
    value?: boolean
    type?: boolean
    category?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["setting"]>



  export type SettingSelectScalar = {
    id?: boolean
    key?: boolean
    value?: boolean
    type?: boolean
    category?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SettingOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "key" | "value" | "type" | "category" | "createdAt" | "updatedAt", ExtArgs["result"]["setting"]>

  export type $SettingPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Setting"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      key: string
      value: string
      type: string
      category: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["setting"]>
    composites: {}
  }

  type SettingGetPayload<S extends boolean | null | undefined | SettingDefaultArgs> = $Result.GetResult<Prisma.$SettingPayload, S>

  type SettingCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SettingFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SettingCountAggregateInputType | true
    }

  export interface SettingDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Setting'], meta: { name: 'Setting' } }
    /**
     * Find zero or one Setting that matches the filter.
     * @param {SettingFindUniqueArgs} args - Arguments to find a Setting
     * @example
     * // Get one Setting
     * const setting = await prisma.setting.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SettingFindUniqueArgs>(args: SelectSubset<T, SettingFindUniqueArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Setting that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SettingFindUniqueOrThrowArgs} args - Arguments to find a Setting
     * @example
     * // Get one Setting
     * const setting = await prisma.setting.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SettingFindUniqueOrThrowArgs>(args: SelectSubset<T, SettingFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Setting that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingFindFirstArgs} args - Arguments to find a Setting
     * @example
     * // Get one Setting
     * const setting = await prisma.setting.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SettingFindFirstArgs>(args?: SelectSubset<T, SettingFindFirstArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Setting that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingFindFirstOrThrowArgs} args - Arguments to find a Setting
     * @example
     * // Get one Setting
     * const setting = await prisma.setting.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SettingFindFirstOrThrowArgs>(args?: SelectSubset<T, SettingFindFirstOrThrowArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Settings that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Settings
     * const settings = await prisma.setting.findMany()
     * 
     * // Get first 10 Settings
     * const settings = await prisma.setting.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const settingWithIdOnly = await prisma.setting.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SettingFindManyArgs>(args?: SelectSubset<T, SettingFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Setting.
     * @param {SettingCreateArgs} args - Arguments to create a Setting.
     * @example
     * // Create one Setting
     * const Setting = await prisma.setting.create({
     *   data: {
     *     // ... data to create a Setting
     *   }
     * })
     * 
     */
    create<T extends SettingCreateArgs>(args: SelectSubset<T, SettingCreateArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Settings.
     * @param {SettingCreateManyArgs} args - Arguments to create many Settings.
     * @example
     * // Create many Settings
     * const setting = await prisma.setting.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SettingCreateManyArgs>(args?: SelectSubset<T, SettingCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Setting.
     * @param {SettingDeleteArgs} args - Arguments to delete one Setting.
     * @example
     * // Delete one Setting
     * const Setting = await prisma.setting.delete({
     *   where: {
     *     // ... filter to delete one Setting
     *   }
     * })
     * 
     */
    delete<T extends SettingDeleteArgs>(args: SelectSubset<T, SettingDeleteArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Setting.
     * @param {SettingUpdateArgs} args - Arguments to update one Setting.
     * @example
     * // Update one Setting
     * const setting = await prisma.setting.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SettingUpdateArgs>(args: SelectSubset<T, SettingUpdateArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Settings.
     * @param {SettingDeleteManyArgs} args - Arguments to filter Settings to delete.
     * @example
     * // Delete a few Settings
     * const { count } = await prisma.setting.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SettingDeleteManyArgs>(args?: SelectSubset<T, SettingDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Settings
     * const setting = await prisma.setting.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SettingUpdateManyArgs>(args: SelectSubset<T, SettingUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Setting.
     * @param {SettingUpsertArgs} args - Arguments to update or create a Setting.
     * @example
     * // Update or create a Setting
     * const setting = await prisma.setting.upsert({
     *   create: {
     *     // ... data to create a Setting
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Setting we want to update
     *   }
     * })
     */
    upsert<T extends SettingUpsertArgs>(args: SelectSubset<T, SettingUpsertArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingCountArgs} args - Arguments to filter Settings to count.
     * @example
     * // Count the number of Settings
     * const count = await prisma.setting.count({
     *   where: {
     *     // ... the filter for the Settings we want to count
     *   }
     * })
    **/
    count<T extends SettingCountArgs>(
      args?: Subset<T, SettingCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SettingCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Setting.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SettingAggregateArgs>(args: Subset<T, SettingAggregateArgs>): Prisma.PrismaPromise<GetSettingAggregateType<T>>

    /**
     * Group by Setting.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SettingGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SettingGroupByArgs['orderBy'] }
        : { orderBy?: SettingGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SettingGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSettingGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Setting model
   */
  readonly fields: SettingFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Setting.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SettingClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Setting model
   */
  interface SettingFieldRefs {
    readonly id: FieldRef<"Setting", 'String'>
    readonly key: FieldRef<"Setting", 'String'>
    readonly value: FieldRef<"Setting", 'String'>
    readonly type: FieldRef<"Setting", 'String'>
    readonly category: FieldRef<"Setting", 'String'>
    readonly createdAt: FieldRef<"Setting", 'DateTime'>
    readonly updatedAt: FieldRef<"Setting", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Setting findUnique
   */
  export type SettingFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Filter, which Setting to fetch.
     */
    where: SettingWhereUniqueInput
  }

  /**
   * Setting findUniqueOrThrow
   */
  export type SettingFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Filter, which Setting to fetch.
     */
    where: SettingWhereUniqueInput
  }

  /**
   * Setting findFirst
   */
  export type SettingFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Filter, which Setting to fetch.
     */
    where?: SettingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingOrderByWithRelationInput | SettingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Settings.
     */
    cursor?: SettingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Settings.
     */
    distinct?: SettingScalarFieldEnum | SettingScalarFieldEnum[]
  }

  /**
   * Setting findFirstOrThrow
   */
  export type SettingFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Filter, which Setting to fetch.
     */
    where?: SettingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingOrderByWithRelationInput | SettingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Settings.
     */
    cursor?: SettingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Settings.
     */
    distinct?: SettingScalarFieldEnum | SettingScalarFieldEnum[]
  }

  /**
   * Setting findMany
   */
  export type SettingFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Filter, which Settings to fetch.
     */
    where?: SettingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingOrderByWithRelationInput | SettingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Settings.
     */
    cursor?: SettingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    distinct?: SettingScalarFieldEnum | SettingScalarFieldEnum[]
  }

  /**
   * Setting create
   */
  export type SettingCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * The data needed to create a Setting.
     */
    data: XOR<SettingCreateInput, SettingUncheckedCreateInput>
  }

  /**
   * Setting createMany
   */
  export type SettingCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Settings.
     */
    data: SettingCreateManyInput | SettingCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Setting update
   */
  export type SettingUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * The data needed to update a Setting.
     */
    data: XOR<SettingUpdateInput, SettingUncheckedUpdateInput>
    /**
     * Choose, which Setting to update.
     */
    where: SettingWhereUniqueInput
  }

  /**
   * Setting updateMany
   */
  export type SettingUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Settings.
     */
    data: XOR<SettingUpdateManyMutationInput, SettingUncheckedUpdateManyInput>
    /**
     * Filter which Settings to update
     */
    where?: SettingWhereInput
    /**
     * Limit how many Settings to update.
     */
    limit?: number
  }

  /**
   * Setting upsert
   */
  export type SettingUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * The filter to search for the Setting to update in case it exists.
     */
    where: SettingWhereUniqueInput
    /**
     * In case the Setting found by the `where` argument doesn't exist, create a new Setting with this data.
     */
    create: XOR<SettingCreateInput, SettingUncheckedCreateInput>
    /**
     * In case the Setting was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SettingUpdateInput, SettingUncheckedUpdateInput>
  }

  /**
   * Setting delete
   */
  export type SettingDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Filter which Setting to delete.
     */
    where: SettingWhereUniqueInput
  }

  /**
   * Setting deleteMany
   */
  export type SettingDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Settings to delete
     */
    where?: SettingWhereInput
    /**
     * Limit how many Settings to delete.
     */
    limit?: number
  }

  /**
   * Setting without action
   */
  export type SettingDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    id: 'id',
    email: 'email',
    password: 'password',
    name: 'name',
    role: 'role',
    isActive: 'isActive',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const SessionScalarFieldEnum: {
    id: 'id',
    sessionToken: 'sessionToken',
    userId: 'userId',
    expires: 'expires',
    createdAt: 'createdAt'
  };

  export type SessionScalarFieldEnum = (typeof SessionScalarFieldEnum)[keyof typeof SessionScalarFieldEnum]


  export const DomainScalarFieldEnum: {
    id: 'id',
    name: 'name',
    registrar: 'registrar',
    status: 'status',
    registeredAt: 'registeredAt',
    expiresAt: 'expiresAt',
    nameservers: 'nameservers',
    whoisData: 'whoisData',
    notes: 'notes',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    createdBy: 'createdBy',
    hostingId: 'hostingId',
    vpsId: 'vpsId',
    isMainDomain: 'isMainDomain',
    domainHosting: 'domainHosting'
  };

  export type DomainScalarFieldEnum = (typeof DomainScalarFieldEnum)[keyof typeof DomainScalarFieldEnum]


  export const HostingScalarFieldEnum: {
    id: 'id',
    name: 'name',
    provider: 'provider',
    status: 'status',
    planName: 'planName',
    resources: 'resources',
    cpanelUrl: 'cpanelUrl',
    username: 'username',
    password: 'password',
    expiresAt: 'expiresAt',
    notes: 'notes',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    createdBy: 'createdBy'
  };

  export type HostingScalarFieldEnum = (typeof HostingScalarFieldEnum)[keyof typeof HostingScalarFieldEnum]


  export const VPSScalarFieldEnum: {
    id: 'id',
    name: 'name',
    provider: 'provider',
    status: 'status',
    ipAddress: 'ipAddress',
    specs: 'specs',
    sshPort: 'sshPort',
    sshKey: 'sshKey',
    username: 'username',
    password: 'password',
    expiresAt: 'expiresAt',
    notes: 'notes',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    createdBy: 'createdBy',
    cpanelUrl: 'cpanelUrl'
  };

  export type VPSScalarFieldEnum = (typeof VPSScalarFieldEnum)[keyof typeof VPSScalarFieldEnum]


  export const WebsiteScalarFieldEnum: {
    id: 'id',
    name: 'name',
    url: 'url',
    status: 'status',
    cms: 'cms',
    cmsVersion: 'cmsVersion',
    phpVersion: 'phpVersion',
    sslStatus: 'sslStatus',
    sslExpiry: 'sslExpiry',
    backupStatus: 'backupStatus',
    lastBackup: 'lastBackup',
    notes: 'notes',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    createdBy: 'createdBy',
    domainId: 'domainId',
    hostingId: 'hostingId',
    vpsId: 'vpsId',
    password: 'password',
    username: 'username'
  };

  export type WebsiteScalarFieldEnum = (typeof WebsiteScalarFieldEnum)[keyof typeof WebsiteScalarFieldEnum]


  export const ActivityLogScalarFieldEnum: {
    id: 'id',
    action: 'action',
    entity: 'entity',
    entityId: 'entityId',
    description: 'description',
    metadata: 'metadata',
    ipAddress: 'ipAddress',
    userAgent: 'userAgent',
    createdAt: 'createdAt',
    userId: 'userId',
    domainId: 'domainId',
    hostingId: 'hostingId',
    vpsId: 'vpsId',
    websiteId: 'websiteId'
  };

  export type ActivityLogScalarFieldEnum = (typeof ActivityLogScalarFieldEnum)[keyof typeof ActivityLogScalarFieldEnum]


  export const SettingScalarFieldEnum: {
    id: 'id',
    key: 'key',
    value: 'value',
    type: 'type',
    category: 'category',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SettingScalarFieldEnum = (typeof SettingScalarFieldEnum)[keyof typeof SettingScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullableJsonNullValueInput: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull
  };

  export type NullableJsonNullValueInput = (typeof NullableJsonNullValueInput)[keyof typeof NullableJsonNullValueInput]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const UserOrderByRelevanceFieldEnum: {
    id: 'id',
    email: 'email',
    password: 'password',
    name: 'name'
  };

  export type UserOrderByRelevanceFieldEnum = (typeof UserOrderByRelevanceFieldEnum)[keyof typeof UserOrderByRelevanceFieldEnum]


  export const SessionOrderByRelevanceFieldEnum: {
    id: 'id',
    sessionToken: 'sessionToken',
    userId: 'userId'
  };

  export type SessionOrderByRelevanceFieldEnum = (typeof SessionOrderByRelevanceFieldEnum)[keyof typeof SessionOrderByRelevanceFieldEnum]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const DomainOrderByRelevanceFieldEnum: {
    id: 'id',
    name: 'name',
    registrar: 'registrar',
    notes: 'notes',
    createdBy: 'createdBy',
    hostingId: 'hostingId',
    vpsId: 'vpsId',
    domainHosting: 'domainHosting'
  };

  export type DomainOrderByRelevanceFieldEnum = (typeof DomainOrderByRelevanceFieldEnum)[keyof typeof DomainOrderByRelevanceFieldEnum]


  export const HostingOrderByRelevanceFieldEnum: {
    id: 'id',
    name: 'name',
    provider: 'provider',
    planName: 'planName',
    cpanelUrl: 'cpanelUrl',
    username: 'username',
    password: 'password',
    notes: 'notes',
    createdBy: 'createdBy'
  };

  export type HostingOrderByRelevanceFieldEnum = (typeof HostingOrderByRelevanceFieldEnum)[keyof typeof HostingOrderByRelevanceFieldEnum]


  export const VPSOrderByRelevanceFieldEnum: {
    id: 'id',
    name: 'name',
    provider: 'provider',
    ipAddress: 'ipAddress',
    sshKey: 'sshKey',
    username: 'username',
    password: 'password',
    notes: 'notes',
    createdBy: 'createdBy',
    cpanelUrl: 'cpanelUrl'
  };

  export type VPSOrderByRelevanceFieldEnum = (typeof VPSOrderByRelevanceFieldEnum)[keyof typeof VPSOrderByRelevanceFieldEnum]


  export const WebsiteOrderByRelevanceFieldEnum: {
    id: 'id',
    name: 'name',
    url: 'url',
    cms: 'cms',
    cmsVersion: 'cmsVersion',
    phpVersion: 'phpVersion',
    backupStatus: 'backupStatus',
    notes: 'notes',
    createdBy: 'createdBy',
    domainId: 'domainId',
    hostingId: 'hostingId',
    vpsId: 'vpsId',
    password: 'password',
    username: 'username'
  };

  export type WebsiteOrderByRelevanceFieldEnum = (typeof WebsiteOrderByRelevanceFieldEnum)[keyof typeof WebsiteOrderByRelevanceFieldEnum]


  export const ActivityLogOrderByRelevanceFieldEnum: {
    id: 'id',
    entityId: 'entityId',
    description: 'description',
    ipAddress: 'ipAddress',
    userAgent: 'userAgent',
    userId: 'userId',
    domainId: 'domainId',
    hostingId: 'hostingId',
    vpsId: 'vpsId',
    websiteId: 'websiteId'
  };

  export type ActivityLogOrderByRelevanceFieldEnum = (typeof ActivityLogOrderByRelevanceFieldEnum)[keyof typeof ActivityLogOrderByRelevanceFieldEnum]


  export const SettingOrderByRelevanceFieldEnum: {
    id: 'id',
    key: 'key',
    value: 'value',
    type: 'type',
    category: 'category'
  };

  export type SettingOrderByRelevanceFieldEnum = (typeof SettingOrderByRelevanceFieldEnum)[keyof typeof SettingOrderByRelevanceFieldEnum]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'UserRole'
   */
  export type EnumUserRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'UserRole'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DomainStatus'
   */
  export type EnumDomainStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DomainStatus'>
    


  /**
   * Reference to a field of type 'Json'
   */
  export type JsonFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Json'>
    


  /**
   * Reference to a field of type 'QueryMode'
   */
  export type EnumQueryModeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'QueryMode'>
    


  /**
   * Reference to a field of type 'HostingStatus'
   */
  export type EnumHostingStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'HostingStatus'>
    


  /**
   * Reference to a field of type 'VPSStatus'
   */
  export type EnumVPSStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'VPSStatus'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'WebsiteStatus'
   */
  export type EnumWebsiteStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'WebsiteStatus'>
    


  /**
   * Reference to a field of type 'SSLStatus'
   */
  export type EnumSSLStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'SSLStatus'>
    


  /**
   * Reference to a field of type 'ActivityType'
   */
  export type EnumActivityTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'ActivityType'>
    


  /**
   * Reference to a field of type 'EntityType'
   */
  export type EnumEntityTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'EntityType'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: StringFilter<"User"> | string
    email?: StringFilter<"User"> | string
    password?: StringFilter<"User"> | string
    name?: StringNullableFilter<"User"> | string | null
    role?: EnumUserRoleFilter<"User"> | $Enums.UserRole
    isActive?: BoolFilter<"User"> | boolean
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    activities?: ActivityLogListRelationFilter
    domains?: DomainListRelationFilter
    hosting?: HostingListRelationFilter
    sessions?: SessionListRelationFilter
    vps?: VPSListRelationFilter
    websites?: WebsiteListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    email?: SortOrder
    password?: SortOrder
    name?: SortOrderInput | SortOrder
    role?: SortOrder
    isActive?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    activities?: ActivityLogOrderByRelationAggregateInput
    domains?: DomainOrderByRelationAggregateInput
    hosting?: HostingOrderByRelationAggregateInput
    sessions?: SessionOrderByRelationAggregateInput
    vps?: VPSOrderByRelationAggregateInput
    websites?: WebsiteOrderByRelationAggregateInput
    _relevance?: UserOrderByRelevanceInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    email?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    password?: StringFilter<"User"> | string
    name?: StringNullableFilter<"User"> | string | null
    role?: EnumUserRoleFilter<"User"> | $Enums.UserRole
    isActive?: BoolFilter<"User"> | boolean
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    activities?: ActivityLogListRelationFilter
    domains?: DomainListRelationFilter
    hosting?: HostingListRelationFilter
    sessions?: SessionListRelationFilter
    vps?: VPSListRelationFilter
    websites?: WebsiteListRelationFilter
  }, "id" | "email">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    email?: SortOrder
    password?: SortOrder
    name?: SortOrderInput | SortOrder
    role?: SortOrder
    isActive?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"User"> | string
    email?: StringWithAggregatesFilter<"User"> | string
    password?: StringWithAggregatesFilter<"User"> | string
    name?: StringNullableWithAggregatesFilter<"User"> | string | null
    role?: EnumUserRoleWithAggregatesFilter<"User"> | $Enums.UserRole
    isActive?: BoolWithAggregatesFilter<"User"> | boolean
    createdAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
  }

  export type SessionWhereInput = {
    AND?: SessionWhereInput | SessionWhereInput[]
    OR?: SessionWhereInput[]
    NOT?: SessionWhereInput | SessionWhereInput[]
    id?: StringFilter<"Session"> | string
    sessionToken?: StringFilter<"Session"> | string
    userId?: StringFilter<"Session"> | string
    expires?: DateTimeFilter<"Session"> | Date | string
    createdAt?: DateTimeFilter<"Session"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type SessionOrderByWithRelationInput = {
    id?: SortOrder
    sessionToken?: SortOrder
    userId?: SortOrder
    expires?: SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
    _relevance?: SessionOrderByRelevanceInput
  }

  export type SessionWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    sessionToken?: string
    AND?: SessionWhereInput | SessionWhereInput[]
    OR?: SessionWhereInput[]
    NOT?: SessionWhereInput | SessionWhereInput[]
    userId?: StringFilter<"Session"> | string
    expires?: DateTimeFilter<"Session"> | Date | string
    createdAt?: DateTimeFilter<"Session"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id" | "sessionToken">

  export type SessionOrderByWithAggregationInput = {
    id?: SortOrder
    sessionToken?: SortOrder
    userId?: SortOrder
    expires?: SortOrder
    createdAt?: SortOrder
    _count?: SessionCountOrderByAggregateInput
    _max?: SessionMaxOrderByAggregateInput
    _min?: SessionMinOrderByAggregateInput
  }

  export type SessionScalarWhereWithAggregatesInput = {
    AND?: SessionScalarWhereWithAggregatesInput | SessionScalarWhereWithAggregatesInput[]
    OR?: SessionScalarWhereWithAggregatesInput[]
    NOT?: SessionScalarWhereWithAggregatesInput | SessionScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Session"> | string
    sessionToken?: StringWithAggregatesFilter<"Session"> | string
    userId?: StringWithAggregatesFilter<"Session"> | string
    expires?: DateTimeWithAggregatesFilter<"Session"> | Date | string
    createdAt?: DateTimeWithAggregatesFilter<"Session"> | Date | string
  }

  export type DomainWhereInput = {
    AND?: DomainWhereInput | DomainWhereInput[]
    OR?: DomainWhereInput[]
    NOT?: DomainWhereInput | DomainWhereInput[]
    id?: StringFilter<"Domain"> | string
    name?: StringFilter<"Domain"> | string
    registrar?: StringNullableFilter<"Domain"> | string | null
    status?: EnumDomainStatusFilter<"Domain"> | $Enums.DomainStatus
    registeredAt?: DateTimeNullableFilter<"Domain"> | Date | string | null
    expiresAt?: DateTimeNullableFilter<"Domain"> | Date | string | null
    nameservers?: JsonNullableFilter<"Domain">
    whoisData?: JsonNullableFilter<"Domain">
    notes?: StringNullableFilter<"Domain"> | string | null
    createdAt?: DateTimeFilter<"Domain"> | Date | string
    updatedAt?: DateTimeFilter<"Domain"> | Date | string
    createdBy?: StringFilter<"Domain"> | string
    hostingId?: StringNullableFilter<"Domain"> | string | null
    vpsId?: StringNullableFilter<"Domain"> | string | null
    isMainDomain?: BoolFilter<"Domain"> | boolean
    domainHosting?: StringNullableFilter<"Domain"> | string | null
    activities?: ActivityLogListRelationFilter
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    hosting?: XOR<HostingNullableScalarRelationFilter, HostingWhereInput> | null
    vps?: XOR<VPSNullableScalarRelationFilter, VPSWhereInput> | null
    websites?: WebsiteListRelationFilter
  }

  export type DomainOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    registrar?: SortOrderInput | SortOrder
    status?: SortOrder
    registeredAt?: SortOrderInput | SortOrder
    expiresAt?: SortOrderInput | SortOrder
    nameservers?: SortOrderInput | SortOrder
    whoisData?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    hostingId?: SortOrderInput | SortOrder
    vpsId?: SortOrderInput | SortOrder
    isMainDomain?: SortOrder
    domainHosting?: SortOrderInput | SortOrder
    activities?: ActivityLogOrderByRelationAggregateInput
    user?: UserOrderByWithRelationInput
    hosting?: HostingOrderByWithRelationInput
    vps?: VPSOrderByWithRelationInput
    websites?: WebsiteOrderByRelationAggregateInput
    _relevance?: DomainOrderByRelevanceInput
  }

  export type DomainWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    name?: string
    AND?: DomainWhereInput | DomainWhereInput[]
    OR?: DomainWhereInput[]
    NOT?: DomainWhereInput | DomainWhereInput[]
    registrar?: StringNullableFilter<"Domain"> | string | null
    status?: EnumDomainStatusFilter<"Domain"> | $Enums.DomainStatus
    registeredAt?: DateTimeNullableFilter<"Domain"> | Date | string | null
    expiresAt?: DateTimeNullableFilter<"Domain"> | Date | string | null
    nameservers?: JsonNullableFilter<"Domain">
    whoisData?: JsonNullableFilter<"Domain">
    notes?: StringNullableFilter<"Domain"> | string | null
    createdAt?: DateTimeFilter<"Domain"> | Date | string
    updatedAt?: DateTimeFilter<"Domain"> | Date | string
    createdBy?: StringFilter<"Domain"> | string
    hostingId?: StringNullableFilter<"Domain"> | string | null
    vpsId?: StringNullableFilter<"Domain"> | string | null
    isMainDomain?: BoolFilter<"Domain"> | boolean
    domainHosting?: StringNullableFilter<"Domain"> | string | null
    activities?: ActivityLogListRelationFilter
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    hosting?: XOR<HostingNullableScalarRelationFilter, HostingWhereInput> | null
    vps?: XOR<VPSNullableScalarRelationFilter, VPSWhereInput> | null
    websites?: WebsiteListRelationFilter
  }, "id" | "name">

  export type DomainOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    registrar?: SortOrderInput | SortOrder
    status?: SortOrder
    registeredAt?: SortOrderInput | SortOrder
    expiresAt?: SortOrderInput | SortOrder
    nameservers?: SortOrderInput | SortOrder
    whoisData?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    hostingId?: SortOrderInput | SortOrder
    vpsId?: SortOrderInput | SortOrder
    isMainDomain?: SortOrder
    domainHosting?: SortOrderInput | SortOrder
    _count?: DomainCountOrderByAggregateInput
    _max?: DomainMaxOrderByAggregateInput
    _min?: DomainMinOrderByAggregateInput
  }

  export type DomainScalarWhereWithAggregatesInput = {
    AND?: DomainScalarWhereWithAggregatesInput | DomainScalarWhereWithAggregatesInput[]
    OR?: DomainScalarWhereWithAggregatesInput[]
    NOT?: DomainScalarWhereWithAggregatesInput | DomainScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Domain"> | string
    name?: StringWithAggregatesFilter<"Domain"> | string
    registrar?: StringNullableWithAggregatesFilter<"Domain"> | string | null
    status?: EnumDomainStatusWithAggregatesFilter<"Domain"> | $Enums.DomainStatus
    registeredAt?: DateTimeNullableWithAggregatesFilter<"Domain"> | Date | string | null
    expiresAt?: DateTimeNullableWithAggregatesFilter<"Domain"> | Date | string | null
    nameservers?: JsonNullableWithAggregatesFilter<"Domain">
    whoisData?: JsonNullableWithAggregatesFilter<"Domain">
    notes?: StringNullableWithAggregatesFilter<"Domain"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Domain"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Domain"> | Date | string
    createdBy?: StringWithAggregatesFilter<"Domain"> | string
    hostingId?: StringNullableWithAggregatesFilter<"Domain"> | string | null
    vpsId?: StringNullableWithAggregatesFilter<"Domain"> | string | null
    isMainDomain?: BoolWithAggregatesFilter<"Domain"> | boolean
    domainHosting?: StringNullableWithAggregatesFilter<"Domain"> | string | null
  }

  export type HostingWhereInput = {
    AND?: HostingWhereInput | HostingWhereInput[]
    OR?: HostingWhereInput[]
    NOT?: HostingWhereInput | HostingWhereInput[]
    id?: StringFilter<"Hosting"> | string
    name?: StringFilter<"Hosting"> | string
    provider?: StringFilter<"Hosting"> | string
    status?: EnumHostingStatusFilter<"Hosting"> | $Enums.HostingStatus
    planName?: StringNullableFilter<"Hosting"> | string | null
    resources?: JsonNullableFilter<"Hosting">
    cpanelUrl?: StringNullableFilter<"Hosting"> | string | null
    username?: StringNullableFilter<"Hosting"> | string | null
    password?: StringNullableFilter<"Hosting"> | string | null
    expiresAt?: DateTimeNullableFilter<"Hosting"> | Date | string | null
    notes?: StringNullableFilter<"Hosting"> | string | null
    createdAt?: DateTimeFilter<"Hosting"> | Date | string
    updatedAt?: DateTimeFilter<"Hosting"> | Date | string
    createdBy?: StringFilter<"Hosting"> | string
    activities?: ActivityLogListRelationFilter
    domains?: DomainListRelationFilter
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    websites?: WebsiteListRelationFilter
  }

  export type HostingOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    planName?: SortOrderInput | SortOrder
    resources?: SortOrderInput | SortOrder
    cpanelUrl?: SortOrderInput | SortOrder
    username?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    expiresAt?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    activities?: ActivityLogOrderByRelationAggregateInput
    domains?: DomainOrderByRelationAggregateInput
    user?: UserOrderByWithRelationInput
    websites?: WebsiteOrderByRelationAggregateInput
    _relevance?: HostingOrderByRelevanceInput
  }

  export type HostingWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: HostingWhereInput | HostingWhereInput[]
    OR?: HostingWhereInput[]
    NOT?: HostingWhereInput | HostingWhereInput[]
    name?: StringFilter<"Hosting"> | string
    provider?: StringFilter<"Hosting"> | string
    status?: EnumHostingStatusFilter<"Hosting"> | $Enums.HostingStatus
    planName?: StringNullableFilter<"Hosting"> | string | null
    resources?: JsonNullableFilter<"Hosting">
    cpanelUrl?: StringNullableFilter<"Hosting"> | string | null
    username?: StringNullableFilter<"Hosting"> | string | null
    password?: StringNullableFilter<"Hosting"> | string | null
    expiresAt?: DateTimeNullableFilter<"Hosting"> | Date | string | null
    notes?: StringNullableFilter<"Hosting"> | string | null
    createdAt?: DateTimeFilter<"Hosting"> | Date | string
    updatedAt?: DateTimeFilter<"Hosting"> | Date | string
    createdBy?: StringFilter<"Hosting"> | string
    activities?: ActivityLogListRelationFilter
    domains?: DomainListRelationFilter
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    websites?: WebsiteListRelationFilter
  }, "id">

  export type HostingOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    planName?: SortOrderInput | SortOrder
    resources?: SortOrderInput | SortOrder
    cpanelUrl?: SortOrderInput | SortOrder
    username?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    expiresAt?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    _count?: HostingCountOrderByAggregateInput
    _max?: HostingMaxOrderByAggregateInput
    _min?: HostingMinOrderByAggregateInput
  }

  export type HostingScalarWhereWithAggregatesInput = {
    AND?: HostingScalarWhereWithAggregatesInput | HostingScalarWhereWithAggregatesInput[]
    OR?: HostingScalarWhereWithAggregatesInput[]
    NOT?: HostingScalarWhereWithAggregatesInput | HostingScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Hosting"> | string
    name?: StringWithAggregatesFilter<"Hosting"> | string
    provider?: StringWithAggregatesFilter<"Hosting"> | string
    status?: EnumHostingStatusWithAggregatesFilter<"Hosting"> | $Enums.HostingStatus
    planName?: StringNullableWithAggregatesFilter<"Hosting"> | string | null
    resources?: JsonNullableWithAggregatesFilter<"Hosting">
    cpanelUrl?: StringNullableWithAggregatesFilter<"Hosting"> | string | null
    username?: StringNullableWithAggregatesFilter<"Hosting"> | string | null
    password?: StringNullableWithAggregatesFilter<"Hosting"> | string | null
    expiresAt?: DateTimeNullableWithAggregatesFilter<"Hosting"> | Date | string | null
    notes?: StringNullableWithAggregatesFilter<"Hosting"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Hosting"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Hosting"> | Date | string
    createdBy?: StringWithAggregatesFilter<"Hosting"> | string
  }

  export type VPSWhereInput = {
    AND?: VPSWhereInput | VPSWhereInput[]
    OR?: VPSWhereInput[]
    NOT?: VPSWhereInput | VPSWhereInput[]
    id?: StringFilter<"VPS"> | string
    name?: StringFilter<"VPS"> | string
    provider?: StringFilter<"VPS"> | string
    status?: EnumVPSStatusFilter<"VPS"> | $Enums.VPSStatus
    ipAddress?: StringNullableFilter<"VPS"> | string | null
    specs?: JsonNullableFilter<"VPS">
    sshPort?: IntNullableFilter<"VPS"> | number | null
    sshKey?: StringNullableFilter<"VPS"> | string | null
    username?: StringNullableFilter<"VPS"> | string | null
    password?: StringNullableFilter<"VPS"> | string | null
    expiresAt?: DateTimeNullableFilter<"VPS"> | Date | string | null
    notes?: StringNullableFilter<"VPS"> | string | null
    createdAt?: DateTimeFilter<"VPS"> | Date | string
    updatedAt?: DateTimeFilter<"VPS"> | Date | string
    createdBy?: StringFilter<"VPS"> | string
    cpanelUrl?: StringNullableFilter<"VPS"> | string | null
    activities?: ActivityLogListRelationFilter
    domains?: DomainListRelationFilter
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    websites?: WebsiteListRelationFilter
  }

  export type VPSOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    ipAddress?: SortOrderInput | SortOrder
    specs?: SortOrderInput | SortOrder
    sshPort?: SortOrderInput | SortOrder
    sshKey?: SortOrderInput | SortOrder
    username?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    expiresAt?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    cpanelUrl?: SortOrderInput | SortOrder
    activities?: ActivityLogOrderByRelationAggregateInput
    domains?: DomainOrderByRelationAggregateInput
    user?: UserOrderByWithRelationInput
    websites?: WebsiteOrderByRelationAggregateInput
    _relevance?: VPSOrderByRelevanceInput
  }

  export type VPSWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: VPSWhereInput | VPSWhereInput[]
    OR?: VPSWhereInput[]
    NOT?: VPSWhereInput | VPSWhereInput[]
    name?: StringFilter<"VPS"> | string
    provider?: StringFilter<"VPS"> | string
    status?: EnumVPSStatusFilter<"VPS"> | $Enums.VPSStatus
    ipAddress?: StringNullableFilter<"VPS"> | string | null
    specs?: JsonNullableFilter<"VPS">
    sshPort?: IntNullableFilter<"VPS"> | number | null
    sshKey?: StringNullableFilter<"VPS"> | string | null
    username?: StringNullableFilter<"VPS"> | string | null
    password?: StringNullableFilter<"VPS"> | string | null
    expiresAt?: DateTimeNullableFilter<"VPS"> | Date | string | null
    notes?: StringNullableFilter<"VPS"> | string | null
    createdAt?: DateTimeFilter<"VPS"> | Date | string
    updatedAt?: DateTimeFilter<"VPS"> | Date | string
    createdBy?: StringFilter<"VPS"> | string
    cpanelUrl?: StringNullableFilter<"VPS"> | string | null
    activities?: ActivityLogListRelationFilter
    domains?: DomainListRelationFilter
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    websites?: WebsiteListRelationFilter
  }, "id">

  export type VPSOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    ipAddress?: SortOrderInput | SortOrder
    specs?: SortOrderInput | SortOrder
    sshPort?: SortOrderInput | SortOrder
    sshKey?: SortOrderInput | SortOrder
    username?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    expiresAt?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    cpanelUrl?: SortOrderInput | SortOrder
    _count?: VPSCountOrderByAggregateInput
    _avg?: VPSAvgOrderByAggregateInput
    _max?: VPSMaxOrderByAggregateInput
    _min?: VPSMinOrderByAggregateInput
    _sum?: VPSSumOrderByAggregateInput
  }

  export type VPSScalarWhereWithAggregatesInput = {
    AND?: VPSScalarWhereWithAggregatesInput | VPSScalarWhereWithAggregatesInput[]
    OR?: VPSScalarWhereWithAggregatesInput[]
    NOT?: VPSScalarWhereWithAggregatesInput | VPSScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"VPS"> | string
    name?: StringWithAggregatesFilter<"VPS"> | string
    provider?: StringWithAggregatesFilter<"VPS"> | string
    status?: EnumVPSStatusWithAggregatesFilter<"VPS"> | $Enums.VPSStatus
    ipAddress?: StringNullableWithAggregatesFilter<"VPS"> | string | null
    specs?: JsonNullableWithAggregatesFilter<"VPS">
    sshPort?: IntNullableWithAggregatesFilter<"VPS"> | number | null
    sshKey?: StringNullableWithAggregatesFilter<"VPS"> | string | null
    username?: StringNullableWithAggregatesFilter<"VPS"> | string | null
    password?: StringNullableWithAggregatesFilter<"VPS"> | string | null
    expiresAt?: DateTimeNullableWithAggregatesFilter<"VPS"> | Date | string | null
    notes?: StringNullableWithAggregatesFilter<"VPS"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"VPS"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"VPS"> | Date | string
    createdBy?: StringWithAggregatesFilter<"VPS"> | string
    cpanelUrl?: StringNullableWithAggregatesFilter<"VPS"> | string | null
  }

  export type WebsiteWhereInput = {
    AND?: WebsiteWhereInput | WebsiteWhereInput[]
    OR?: WebsiteWhereInput[]
    NOT?: WebsiteWhereInput | WebsiteWhereInput[]
    id?: StringFilter<"Website"> | string
    name?: StringFilter<"Website"> | string
    url?: StringNullableFilter<"Website"> | string | null
    status?: EnumWebsiteStatusFilter<"Website"> | $Enums.WebsiteStatus
    cms?: StringNullableFilter<"Website"> | string | null
    cmsVersion?: StringNullableFilter<"Website"> | string | null
    phpVersion?: StringNullableFilter<"Website"> | string | null
    sslStatus?: EnumSSLStatusFilter<"Website"> | $Enums.SSLStatus
    sslExpiry?: DateTimeNullableFilter<"Website"> | Date | string | null
    backupStatus?: StringNullableFilter<"Website"> | string | null
    lastBackup?: DateTimeNullableFilter<"Website"> | Date | string | null
    notes?: StringNullableFilter<"Website"> | string | null
    createdAt?: DateTimeFilter<"Website"> | Date | string
    updatedAt?: DateTimeFilter<"Website"> | Date | string
    createdBy?: StringFilter<"Website"> | string
    domainId?: StringNullableFilter<"Website"> | string | null
    hostingId?: StringNullableFilter<"Website"> | string | null
    vpsId?: StringNullableFilter<"Website"> | string | null
    password?: StringNullableFilter<"Website"> | string | null
    username?: StringNullableFilter<"Website"> | string | null
    activities?: ActivityLogListRelationFilter
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    domain?: XOR<DomainNullableScalarRelationFilter, DomainWhereInput> | null
    hosting?: XOR<HostingNullableScalarRelationFilter, HostingWhereInput> | null
    vps?: XOR<VPSNullableScalarRelationFilter, VPSWhereInput> | null
  }

  export type WebsiteOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    url?: SortOrderInput | SortOrder
    status?: SortOrder
    cms?: SortOrderInput | SortOrder
    cmsVersion?: SortOrderInput | SortOrder
    phpVersion?: SortOrderInput | SortOrder
    sslStatus?: SortOrder
    sslExpiry?: SortOrderInput | SortOrder
    backupStatus?: SortOrderInput | SortOrder
    lastBackup?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    domainId?: SortOrderInput | SortOrder
    hostingId?: SortOrderInput | SortOrder
    vpsId?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    username?: SortOrderInput | SortOrder
    activities?: ActivityLogOrderByRelationAggregateInput
    user?: UserOrderByWithRelationInput
    domain?: DomainOrderByWithRelationInput
    hosting?: HostingOrderByWithRelationInput
    vps?: VPSOrderByWithRelationInput
    _relevance?: WebsiteOrderByRelevanceInput
  }

  export type WebsiteWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: WebsiteWhereInput | WebsiteWhereInput[]
    OR?: WebsiteWhereInput[]
    NOT?: WebsiteWhereInput | WebsiteWhereInput[]
    name?: StringFilter<"Website"> | string
    url?: StringNullableFilter<"Website"> | string | null
    status?: EnumWebsiteStatusFilter<"Website"> | $Enums.WebsiteStatus
    cms?: StringNullableFilter<"Website"> | string | null
    cmsVersion?: StringNullableFilter<"Website"> | string | null
    phpVersion?: StringNullableFilter<"Website"> | string | null
    sslStatus?: EnumSSLStatusFilter<"Website"> | $Enums.SSLStatus
    sslExpiry?: DateTimeNullableFilter<"Website"> | Date | string | null
    backupStatus?: StringNullableFilter<"Website"> | string | null
    lastBackup?: DateTimeNullableFilter<"Website"> | Date | string | null
    notes?: StringNullableFilter<"Website"> | string | null
    createdAt?: DateTimeFilter<"Website"> | Date | string
    updatedAt?: DateTimeFilter<"Website"> | Date | string
    createdBy?: StringFilter<"Website"> | string
    domainId?: StringNullableFilter<"Website"> | string | null
    hostingId?: StringNullableFilter<"Website"> | string | null
    vpsId?: StringNullableFilter<"Website"> | string | null
    password?: StringNullableFilter<"Website"> | string | null
    username?: StringNullableFilter<"Website"> | string | null
    activities?: ActivityLogListRelationFilter
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    domain?: XOR<DomainNullableScalarRelationFilter, DomainWhereInput> | null
    hosting?: XOR<HostingNullableScalarRelationFilter, HostingWhereInput> | null
    vps?: XOR<VPSNullableScalarRelationFilter, VPSWhereInput> | null
  }, "id">

  export type WebsiteOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    url?: SortOrderInput | SortOrder
    status?: SortOrder
    cms?: SortOrderInput | SortOrder
    cmsVersion?: SortOrderInput | SortOrder
    phpVersion?: SortOrderInput | SortOrder
    sslStatus?: SortOrder
    sslExpiry?: SortOrderInput | SortOrder
    backupStatus?: SortOrderInput | SortOrder
    lastBackup?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    domainId?: SortOrderInput | SortOrder
    hostingId?: SortOrderInput | SortOrder
    vpsId?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    username?: SortOrderInput | SortOrder
    _count?: WebsiteCountOrderByAggregateInput
    _max?: WebsiteMaxOrderByAggregateInput
    _min?: WebsiteMinOrderByAggregateInput
  }

  export type WebsiteScalarWhereWithAggregatesInput = {
    AND?: WebsiteScalarWhereWithAggregatesInput | WebsiteScalarWhereWithAggregatesInput[]
    OR?: WebsiteScalarWhereWithAggregatesInput[]
    NOT?: WebsiteScalarWhereWithAggregatesInput | WebsiteScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Website"> | string
    name?: StringWithAggregatesFilter<"Website"> | string
    url?: StringNullableWithAggregatesFilter<"Website"> | string | null
    status?: EnumWebsiteStatusWithAggregatesFilter<"Website"> | $Enums.WebsiteStatus
    cms?: StringNullableWithAggregatesFilter<"Website"> | string | null
    cmsVersion?: StringNullableWithAggregatesFilter<"Website"> | string | null
    phpVersion?: StringNullableWithAggregatesFilter<"Website"> | string | null
    sslStatus?: EnumSSLStatusWithAggregatesFilter<"Website"> | $Enums.SSLStatus
    sslExpiry?: DateTimeNullableWithAggregatesFilter<"Website"> | Date | string | null
    backupStatus?: StringNullableWithAggregatesFilter<"Website"> | string | null
    lastBackup?: DateTimeNullableWithAggregatesFilter<"Website"> | Date | string | null
    notes?: StringNullableWithAggregatesFilter<"Website"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Website"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Website"> | Date | string
    createdBy?: StringWithAggregatesFilter<"Website"> | string
    domainId?: StringNullableWithAggregatesFilter<"Website"> | string | null
    hostingId?: StringNullableWithAggregatesFilter<"Website"> | string | null
    vpsId?: StringNullableWithAggregatesFilter<"Website"> | string | null
    password?: StringNullableWithAggregatesFilter<"Website"> | string | null
    username?: StringNullableWithAggregatesFilter<"Website"> | string | null
  }

  export type ActivityLogWhereInput = {
    AND?: ActivityLogWhereInput | ActivityLogWhereInput[]
    OR?: ActivityLogWhereInput[]
    NOT?: ActivityLogWhereInput | ActivityLogWhereInput[]
    id?: StringFilter<"ActivityLog"> | string
    action?: EnumActivityTypeFilter<"ActivityLog"> | $Enums.ActivityType
    entity?: EnumEntityTypeFilter<"ActivityLog"> | $Enums.EntityType
    entityId?: StringFilter<"ActivityLog"> | string
    description?: StringFilter<"ActivityLog"> | string
    metadata?: JsonNullableFilter<"ActivityLog">
    ipAddress?: StringNullableFilter<"ActivityLog"> | string | null
    userAgent?: StringNullableFilter<"ActivityLog"> | string | null
    createdAt?: DateTimeFilter<"ActivityLog"> | Date | string
    userId?: StringFilter<"ActivityLog"> | string
    domainId?: StringNullableFilter<"ActivityLog"> | string | null
    hostingId?: StringNullableFilter<"ActivityLog"> | string | null
    vpsId?: StringNullableFilter<"ActivityLog"> | string | null
    websiteId?: StringNullableFilter<"ActivityLog"> | string | null
    domain?: XOR<DomainNullableScalarRelationFilter, DomainWhereInput> | null
    hosting?: XOR<HostingNullableScalarRelationFilter, HostingWhereInput> | null
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    vps?: XOR<VPSNullableScalarRelationFilter, VPSWhereInput> | null
    website?: XOR<WebsiteNullableScalarRelationFilter, WebsiteWhereInput> | null
  }

  export type ActivityLogOrderByWithRelationInput = {
    id?: SortOrder
    action?: SortOrder
    entity?: SortOrder
    entityId?: SortOrder
    description?: SortOrder
    metadata?: SortOrderInput | SortOrder
    ipAddress?: SortOrderInput | SortOrder
    userAgent?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    userId?: SortOrder
    domainId?: SortOrderInput | SortOrder
    hostingId?: SortOrderInput | SortOrder
    vpsId?: SortOrderInput | SortOrder
    websiteId?: SortOrderInput | SortOrder
    domain?: DomainOrderByWithRelationInput
    hosting?: HostingOrderByWithRelationInput
    user?: UserOrderByWithRelationInput
    vps?: VPSOrderByWithRelationInput
    website?: WebsiteOrderByWithRelationInput
    _relevance?: ActivityLogOrderByRelevanceInput
  }

  export type ActivityLogWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ActivityLogWhereInput | ActivityLogWhereInput[]
    OR?: ActivityLogWhereInput[]
    NOT?: ActivityLogWhereInput | ActivityLogWhereInput[]
    action?: EnumActivityTypeFilter<"ActivityLog"> | $Enums.ActivityType
    entity?: EnumEntityTypeFilter<"ActivityLog"> | $Enums.EntityType
    entityId?: StringFilter<"ActivityLog"> | string
    description?: StringFilter<"ActivityLog"> | string
    metadata?: JsonNullableFilter<"ActivityLog">
    ipAddress?: StringNullableFilter<"ActivityLog"> | string | null
    userAgent?: StringNullableFilter<"ActivityLog"> | string | null
    createdAt?: DateTimeFilter<"ActivityLog"> | Date | string
    userId?: StringFilter<"ActivityLog"> | string
    domainId?: StringNullableFilter<"ActivityLog"> | string | null
    hostingId?: StringNullableFilter<"ActivityLog"> | string | null
    vpsId?: StringNullableFilter<"ActivityLog"> | string | null
    websiteId?: StringNullableFilter<"ActivityLog"> | string | null
    domain?: XOR<DomainNullableScalarRelationFilter, DomainWhereInput> | null
    hosting?: XOR<HostingNullableScalarRelationFilter, HostingWhereInput> | null
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    vps?: XOR<VPSNullableScalarRelationFilter, VPSWhereInput> | null
    website?: XOR<WebsiteNullableScalarRelationFilter, WebsiteWhereInput> | null
  }, "id">

  export type ActivityLogOrderByWithAggregationInput = {
    id?: SortOrder
    action?: SortOrder
    entity?: SortOrder
    entityId?: SortOrder
    description?: SortOrder
    metadata?: SortOrderInput | SortOrder
    ipAddress?: SortOrderInput | SortOrder
    userAgent?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    userId?: SortOrder
    domainId?: SortOrderInput | SortOrder
    hostingId?: SortOrderInput | SortOrder
    vpsId?: SortOrderInput | SortOrder
    websiteId?: SortOrderInput | SortOrder
    _count?: ActivityLogCountOrderByAggregateInput
    _max?: ActivityLogMaxOrderByAggregateInput
    _min?: ActivityLogMinOrderByAggregateInput
  }

  export type ActivityLogScalarWhereWithAggregatesInput = {
    AND?: ActivityLogScalarWhereWithAggregatesInput | ActivityLogScalarWhereWithAggregatesInput[]
    OR?: ActivityLogScalarWhereWithAggregatesInput[]
    NOT?: ActivityLogScalarWhereWithAggregatesInput | ActivityLogScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"ActivityLog"> | string
    action?: EnumActivityTypeWithAggregatesFilter<"ActivityLog"> | $Enums.ActivityType
    entity?: EnumEntityTypeWithAggregatesFilter<"ActivityLog"> | $Enums.EntityType
    entityId?: StringWithAggregatesFilter<"ActivityLog"> | string
    description?: StringWithAggregatesFilter<"ActivityLog"> | string
    metadata?: JsonNullableWithAggregatesFilter<"ActivityLog">
    ipAddress?: StringNullableWithAggregatesFilter<"ActivityLog"> | string | null
    userAgent?: StringNullableWithAggregatesFilter<"ActivityLog"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"ActivityLog"> | Date | string
    userId?: StringWithAggregatesFilter<"ActivityLog"> | string
    domainId?: StringNullableWithAggregatesFilter<"ActivityLog"> | string | null
    hostingId?: StringNullableWithAggregatesFilter<"ActivityLog"> | string | null
    vpsId?: StringNullableWithAggregatesFilter<"ActivityLog"> | string | null
    websiteId?: StringNullableWithAggregatesFilter<"ActivityLog"> | string | null
  }

  export type SettingWhereInput = {
    AND?: SettingWhereInput | SettingWhereInput[]
    OR?: SettingWhereInput[]
    NOT?: SettingWhereInput | SettingWhereInput[]
    id?: StringFilter<"Setting"> | string
    key?: StringFilter<"Setting"> | string
    value?: StringFilter<"Setting"> | string
    type?: StringFilter<"Setting"> | string
    category?: StringFilter<"Setting"> | string
    createdAt?: DateTimeFilter<"Setting"> | Date | string
    updatedAt?: DateTimeFilter<"Setting"> | Date | string
  }

  export type SettingOrderByWithRelationInput = {
    id?: SortOrder
    key?: SortOrder
    value?: SortOrder
    type?: SortOrder
    category?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _relevance?: SettingOrderByRelevanceInput
  }

  export type SettingWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    key?: string
    AND?: SettingWhereInput | SettingWhereInput[]
    OR?: SettingWhereInput[]
    NOT?: SettingWhereInput | SettingWhereInput[]
    value?: StringFilter<"Setting"> | string
    type?: StringFilter<"Setting"> | string
    category?: StringFilter<"Setting"> | string
    createdAt?: DateTimeFilter<"Setting"> | Date | string
    updatedAt?: DateTimeFilter<"Setting"> | Date | string
  }, "id" | "key">

  export type SettingOrderByWithAggregationInput = {
    id?: SortOrder
    key?: SortOrder
    value?: SortOrder
    type?: SortOrder
    category?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: SettingCountOrderByAggregateInput
    _max?: SettingMaxOrderByAggregateInput
    _min?: SettingMinOrderByAggregateInput
  }

  export type SettingScalarWhereWithAggregatesInput = {
    AND?: SettingScalarWhereWithAggregatesInput | SettingScalarWhereWithAggregatesInput[]
    OR?: SettingScalarWhereWithAggregatesInput[]
    NOT?: SettingScalarWhereWithAggregatesInput | SettingScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Setting"> | string
    key?: StringWithAggregatesFilter<"Setting"> | string
    value?: StringWithAggregatesFilter<"Setting"> | string
    type?: StringWithAggregatesFilter<"Setting"> | string
    category?: StringWithAggregatesFilter<"Setting"> | string
    createdAt?: DateTimeWithAggregatesFilter<"Setting"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Setting"> | Date | string
  }

  export type UserCreateInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogCreateNestedManyWithoutUserInput
    domains?: DomainCreateNestedManyWithoutUserInput
    hosting?: HostingCreateNestedManyWithoutUserInput
    sessions?: SessionCreateNestedManyWithoutUserInput
    vps?: VPSCreateNestedManyWithoutUserInput
    websites?: WebsiteCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogUncheckedCreateNestedManyWithoutUserInput
    domains?: DomainUncheckedCreateNestedManyWithoutUserInput
    hosting?: HostingUncheckedCreateNestedManyWithoutUserInput
    sessions?: SessionUncheckedCreateNestedManyWithoutUserInput
    vps?: VPSUncheckedCreateNestedManyWithoutUserInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUpdateManyWithoutUserNestedInput
    domains?: DomainUpdateManyWithoutUserNestedInput
    hosting?: HostingUpdateManyWithoutUserNestedInput
    sessions?: SessionUpdateManyWithoutUserNestedInput
    vps?: VPSUpdateManyWithoutUserNestedInput
    websites?: WebsiteUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUncheckedUpdateManyWithoutUserNestedInput
    domains?: DomainUncheckedUpdateManyWithoutUserNestedInput
    hosting?: HostingUncheckedUpdateManyWithoutUserNestedInput
    sessions?: SessionUncheckedUpdateManyWithoutUserNestedInput
    vps?: VPSUncheckedUpdateManyWithoutUserNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateManyInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SessionCreateInput = {
    id?: string
    sessionToken: string
    expires: Date | string
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutSessionsInput
  }

  export type SessionUncheckedCreateInput = {
    id?: string
    sessionToken: string
    userId: string
    expires: Date | string
    createdAt?: Date | string
  }

  export type SessionUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutSessionsNestedInput
  }

  export type SessionUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SessionCreateManyInput = {
    id?: string
    sessionToken: string
    userId: string
    expires: Date | string
    createdAt?: Date | string
  }

  export type SessionUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SessionUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type DomainCreateInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    isMainDomain?: boolean
    domainHosting?: string | null
    activities?: ActivityLogCreateNestedManyWithoutDomainInput
    user: UserCreateNestedOneWithoutDomainsInput
    hosting?: HostingCreateNestedOneWithoutDomainsInput
    vps?: VPSCreateNestedOneWithoutDomainsInput
    websites?: WebsiteCreateNestedManyWithoutDomainInput
  }

  export type DomainUncheckedCreateInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    hostingId?: string | null
    vpsId?: string | null
    isMainDomain?: boolean
    domainHosting?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutDomainInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutDomainInput
  }

  export type DomainUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutDomainNestedInput
    user?: UserUpdateOneRequiredWithoutDomainsNestedInput
    hosting?: HostingUpdateOneWithoutDomainsNestedInput
    vps?: VPSUpdateOneWithoutDomainsNestedInput
    websites?: WebsiteUpdateManyWithoutDomainNestedInput
  }

  export type DomainUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutDomainNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutDomainNestedInput
  }

  export type DomainCreateManyInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    hostingId?: string | null
    vpsId?: string | null
    isMainDomain?: boolean
    domainHosting?: string | null
  }

  export type DomainUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type DomainUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type HostingCreateInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogCreateNestedManyWithoutHostingInput
    domains?: DomainCreateNestedManyWithoutHostingInput
    user: UserCreateNestedOneWithoutHostingInput
    websites?: WebsiteCreateNestedManyWithoutHostingInput
  }

  export type HostingUncheckedCreateInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    activities?: ActivityLogUncheckedCreateNestedManyWithoutHostingInput
    domains?: DomainUncheckedCreateNestedManyWithoutHostingInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutHostingInput
  }

  export type HostingUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUpdateManyWithoutHostingNestedInput
    domains?: DomainUpdateManyWithoutHostingNestedInput
    user?: UserUpdateOneRequiredWithoutHostingNestedInput
    websites?: WebsiteUpdateManyWithoutHostingNestedInput
  }

  export type HostingUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    activities?: ActivityLogUncheckedUpdateManyWithoutHostingNestedInput
    domains?: DomainUncheckedUpdateManyWithoutHostingNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutHostingNestedInput
  }

  export type HostingCreateManyInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
  }

  export type HostingUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HostingUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
  }

  export type VPSCreateInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    cpanelUrl?: string | null
    activities?: ActivityLogCreateNestedManyWithoutVpsInput
    domains?: DomainCreateNestedManyWithoutVpsInput
    user: UserCreateNestedOneWithoutVpsInput
    websites?: WebsiteCreateNestedManyWithoutVpsInput
  }

  export type VPSUncheckedCreateInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    cpanelUrl?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutVpsInput
    domains?: DomainUncheckedCreateNestedManyWithoutVpsInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutVpsInput
  }

  export type VPSUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutVpsNestedInput
    domains?: DomainUpdateManyWithoutVpsNestedInput
    user?: UserUpdateOneRequiredWithoutVpsNestedInput
    websites?: WebsiteUpdateManyWithoutVpsNestedInput
  }

  export type VPSUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutVpsNestedInput
    domains?: DomainUncheckedUpdateManyWithoutVpsNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutVpsNestedInput
  }

  export type VPSCreateManyInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    cpanelUrl?: string | null
  }

  export type VPSUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type VPSUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type WebsiteCreateInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    password?: string | null
    username?: string | null
    activities?: ActivityLogCreateNestedManyWithoutWebsiteInput
    user: UserCreateNestedOneWithoutWebsitesInput
    domain?: DomainCreateNestedOneWithoutWebsitesInput
    hosting?: HostingCreateNestedOneWithoutWebsitesInput
    vps?: VPSCreateNestedOneWithoutWebsitesInput
  }

  export type WebsiteUncheckedCreateInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    domainId?: string | null
    hostingId?: string | null
    vpsId?: string | null
    password?: string | null
    username?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutWebsiteInput
  }

  export type WebsiteUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutWebsiteNestedInput
    user?: UserUpdateOneRequiredWithoutWebsitesNestedInput
    domain?: DomainUpdateOneWithoutWebsitesNestedInput
    hosting?: HostingUpdateOneWithoutWebsitesNestedInput
    vps?: VPSUpdateOneWithoutWebsitesNestedInput
  }

  export type WebsiteUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutWebsiteNestedInput
  }

  export type WebsiteCreateManyInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    domainId?: string | null
    hostingId?: string | null
    vpsId?: string | null
    password?: string | null
    username?: string | null
  }

  export type WebsiteUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type WebsiteUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogCreateInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    domain?: DomainCreateNestedOneWithoutActivitiesInput
    hosting?: HostingCreateNestedOneWithoutActivitiesInput
    user: UserCreateNestedOneWithoutActivitiesInput
    vps?: VPSCreateNestedOneWithoutActivitiesInput
    website?: WebsiteCreateNestedOneWithoutActivitiesInput
  }

  export type ActivityLogUncheckedCreateInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    userId: string
    domainId?: string | null
    hostingId?: string | null
    vpsId?: string | null
    websiteId?: string | null
  }

  export type ActivityLogUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domain?: DomainUpdateOneWithoutActivitiesNestedInput
    hosting?: HostingUpdateOneWithoutActivitiesNestedInput
    user?: UserUpdateOneRequiredWithoutActivitiesNestedInput
    vps?: VPSUpdateOneWithoutActivitiesNestedInput
    website?: WebsiteUpdateOneWithoutActivitiesNestedInput
  }

  export type ActivityLogUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    websiteId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogCreateManyInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    userId: string
    domainId?: string | null
    hostingId?: string | null
    vpsId?: string | null
    websiteId?: string | null
  }

  export type ActivityLogUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ActivityLogUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    websiteId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type SettingCreateInput = {
    id?: string
    key: string
    value: string
    type?: string
    category?: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SettingUncheckedCreateInput = {
    id?: string
    key: string
    value: string
    type?: string
    category?: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SettingUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    key?: StringFieldUpdateOperationsInput | string
    value?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SettingUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    key?: StringFieldUpdateOperationsInput | string
    value?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SettingCreateManyInput = {
    id?: string
    key: string
    value: string
    type?: string
    category?: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SettingUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    key?: StringFieldUpdateOperationsInput | string
    value?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SettingUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    key?: StringFieldUpdateOperationsInput | string
    value?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type EnumUserRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.UserRole | EnumUserRoleFieldRefInput<$PrismaModel>
    in?: $Enums.UserRole[]
    notIn?: $Enums.UserRole[]
    not?: NestedEnumUserRoleFilter<$PrismaModel> | $Enums.UserRole
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type ActivityLogListRelationFilter = {
    every?: ActivityLogWhereInput
    some?: ActivityLogWhereInput
    none?: ActivityLogWhereInput
  }

  export type DomainListRelationFilter = {
    every?: DomainWhereInput
    some?: DomainWhereInput
    none?: DomainWhereInput
  }

  export type HostingListRelationFilter = {
    every?: HostingWhereInput
    some?: HostingWhereInput
    none?: HostingWhereInput
  }

  export type SessionListRelationFilter = {
    every?: SessionWhereInput
    some?: SessionWhereInput
    none?: SessionWhereInput
  }

  export type VPSListRelationFilter = {
    every?: VPSWhereInput
    some?: VPSWhereInput
    none?: VPSWhereInput
  }

  export type WebsiteListRelationFilter = {
    every?: WebsiteWhereInput
    some?: WebsiteWhereInput
    none?: WebsiteWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type ActivityLogOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type DomainOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type HostingOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type SessionOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type VPSOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type WebsiteOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserOrderByRelevanceInput = {
    fields: UserOrderByRelevanceFieldEnum | UserOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    password?: SortOrder
    name?: SortOrder
    role?: SortOrder
    isActive?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    password?: SortOrder
    name?: SortOrder
    role?: SortOrder
    isActive?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    password?: SortOrder
    name?: SortOrder
    role?: SortOrder
    isActive?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type EnumUserRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.UserRole | EnumUserRoleFieldRefInput<$PrismaModel>
    in?: $Enums.UserRole[]
    notIn?: $Enums.UserRole[]
    not?: NestedEnumUserRoleWithAggregatesFilter<$PrismaModel> | $Enums.UserRole
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumUserRoleFilter<$PrismaModel>
    _max?: NestedEnumUserRoleFilter<$PrismaModel>
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type UserScalarRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type SessionOrderByRelevanceInput = {
    fields: SessionOrderByRelevanceFieldEnum | SessionOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SessionCountOrderByAggregateInput = {
    id?: SortOrder
    sessionToken?: SortOrder
    userId?: SortOrder
    expires?: SortOrder
    createdAt?: SortOrder
  }

  export type SessionMaxOrderByAggregateInput = {
    id?: SortOrder
    sessionToken?: SortOrder
    userId?: SortOrder
    expires?: SortOrder
    createdAt?: SortOrder
  }

  export type SessionMinOrderByAggregateInput = {
    id?: SortOrder
    sessionToken?: SortOrder
    userId?: SortOrder
    expires?: SortOrder
    createdAt?: SortOrder
  }

  export type EnumDomainStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.DomainStatus | EnumDomainStatusFieldRefInput<$PrismaModel>
    in?: $Enums.DomainStatus[]
    notIn?: $Enums.DomainStatus[]
    not?: NestedEnumDomainStatusFilter<$PrismaModel> | $Enums.DomainStatus
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }
  export type JsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type HostingNullableScalarRelationFilter = {
    is?: HostingWhereInput | null
    isNot?: HostingWhereInput | null
  }

  export type VPSNullableScalarRelationFilter = {
    is?: VPSWhereInput | null
    isNot?: VPSWhereInput | null
  }

  export type DomainOrderByRelevanceInput = {
    fields: DomainOrderByRelevanceFieldEnum | DomainOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type DomainCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    registrar?: SortOrder
    status?: SortOrder
    registeredAt?: SortOrder
    expiresAt?: SortOrder
    nameservers?: SortOrder
    whoisData?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    hostingId?: SortOrder
    vpsId?: SortOrder
    isMainDomain?: SortOrder
    domainHosting?: SortOrder
  }

  export type DomainMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    registrar?: SortOrder
    status?: SortOrder
    registeredAt?: SortOrder
    expiresAt?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    hostingId?: SortOrder
    vpsId?: SortOrder
    isMainDomain?: SortOrder
    domainHosting?: SortOrder
  }

  export type DomainMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    registrar?: SortOrder
    status?: SortOrder
    registeredAt?: SortOrder
    expiresAt?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    hostingId?: SortOrder
    vpsId?: SortOrder
    isMainDomain?: SortOrder
    domainHosting?: SortOrder
  }

  export type EnumDomainStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.DomainStatus | EnumDomainStatusFieldRefInput<$PrismaModel>
    in?: $Enums.DomainStatus[]
    notIn?: $Enums.DomainStatus[]
    not?: NestedEnumDomainStatusWithAggregatesFilter<$PrismaModel> | $Enums.DomainStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumDomainStatusFilter<$PrismaModel>
    _max?: NestedEnumDomainStatusFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }
  export type JsonNullableWithAggregatesFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedJsonNullableFilter<$PrismaModel>
    _max?: NestedJsonNullableFilter<$PrismaModel>
  }

  export type EnumHostingStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.HostingStatus | EnumHostingStatusFieldRefInput<$PrismaModel>
    in?: $Enums.HostingStatus[]
    notIn?: $Enums.HostingStatus[]
    not?: NestedEnumHostingStatusFilter<$PrismaModel> | $Enums.HostingStatus
  }

  export type HostingOrderByRelevanceInput = {
    fields: HostingOrderByRelevanceFieldEnum | HostingOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type HostingCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    planName?: SortOrder
    resources?: SortOrder
    cpanelUrl?: SortOrder
    username?: SortOrder
    password?: SortOrder
    expiresAt?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
  }

  export type HostingMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    planName?: SortOrder
    cpanelUrl?: SortOrder
    username?: SortOrder
    password?: SortOrder
    expiresAt?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
  }

  export type HostingMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    planName?: SortOrder
    cpanelUrl?: SortOrder
    username?: SortOrder
    password?: SortOrder
    expiresAt?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
  }

  export type EnumHostingStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.HostingStatus | EnumHostingStatusFieldRefInput<$PrismaModel>
    in?: $Enums.HostingStatus[]
    notIn?: $Enums.HostingStatus[]
    not?: NestedEnumHostingStatusWithAggregatesFilter<$PrismaModel> | $Enums.HostingStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumHostingStatusFilter<$PrismaModel>
    _max?: NestedEnumHostingStatusFilter<$PrismaModel>
  }

  export type EnumVPSStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.VPSStatus | EnumVPSStatusFieldRefInput<$PrismaModel>
    in?: $Enums.VPSStatus[]
    notIn?: $Enums.VPSStatus[]
    not?: NestedEnumVPSStatusFilter<$PrismaModel> | $Enums.VPSStatus
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type VPSOrderByRelevanceInput = {
    fields: VPSOrderByRelevanceFieldEnum | VPSOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type VPSCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    ipAddress?: SortOrder
    specs?: SortOrder
    sshPort?: SortOrder
    sshKey?: SortOrder
    username?: SortOrder
    password?: SortOrder
    expiresAt?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    cpanelUrl?: SortOrder
  }

  export type VPSAvgOrderByAggregateInput = {
    sshPort?: SortOrder
  }

  export type VPSMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    ipAddress?: SortOrder
    sshPort?: SortOrder
    sshKey?: SortOrder
    username?: SortOrder
    password?: SortOrder
    expiresAt?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    cpanelUrl?: SortOrder
  }

  export type VPSMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    provider?: SortOrder
    status?: SortOrder
    ipAddress?: SortOrder
    sshPort?: SortOrder
    sshKey?: SortOrder
    username?: SortOrder
    password?: SortOrder
    expiresAt?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    cpanelUrl?: SortOrder
  }

  export type VPSSumOrderByAggregateInput = {
    sshPort?: SortOrder
  }

  export type EnumVPSStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.VPSStatus | EnumVPSStatusFieldRefInput<$PrismaModel>
    in?: $Enums.VPSStatus[]
    notIn?: $Enums.VPSStatus[]
    not?: NestedEnumVPSStatusWithAggregatesFilter<$PrismaModel> | $Enums.VPSStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumVPSStatusFilter<$PrismaModel>
    _max?: NestedEnumVPSStatusFilter<$PrismaModel>
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type EnumWebsiteStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.WebsiteStatus | EnumWebsiteStatusFieldRefInput<$PrismaModel>
    in?: $Enums.WebsiteStatus[]
    notIn?: $Enums.WebsiteStatus[]
    not?: NestedEnumWebsiteStatusFilter<$PrismaModel> | $Enums.WebsiteStatus
  }

  export type EnumSSLStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.SSLStatus | EnumSSLStatusFieldRefInput<$PrismaModel>
    in?: $Enums.SSLStatus[]
    notIn?: $Enums.SSLStatus[]
    not?: NestedEnumSSLStatusFilter<$PrismaModel> | $Enums.SSLStatus
  }

  export type DomainNullableScalarRelationFilter = {
    is?: DomainWhereInput | null
    isNot?: DomainWhereInput | null
  }

  export type WebsiteOrderByRelevanceInput = {
    fields: WebsiteOrderByRelevanceFieldEnum | WebsiteOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type WebsiteCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    url?: SortOrder
    status?: SortOrder
    cms?: SortOrder
    cmsVersion?: SortOrder
    phpVersion?: SortOrder
    sslStatus?: SortOrder
    sslExpiry?: SortOrder
    backupStatus?: SortOrder
    lastBackup?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    domainId?: SortOrder
    hostingId?: SortOrder
    vpsId?: SortOrder
    password?: SortOrder
    username?: SortOrder
  }

  export type WebsiteMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    url?: SortOrder
    status?: SortOrder
    cms?: SortOrder
    cmsVersion?: SortOrder
    phpVersion?: SortOrder
    sslStatus?: SortOrder
    sslExpiry?: SortOrder
    backupStatus?: SortOrder
    lastBackup?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    domainId?: SortOrder
    hostingId?: SortOrder
    vpsId?: SortOrder
    password?: SortOrder
    username?: SortOrder
  }

  export type WebsiteMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    url?: SortOrder
    status?: SortOrder
    cms?: SortOrder
    cmsVersion?: SortOrder
    phpVersion?: SortOrder
    sslStatus?: SortOrder
    sslExpiry?: SortOrder
    backupStatus?: SortOrder
    lastBackup?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    createdBy?: SortOrder
    domainId?: SortOrder
    hostingId?: SortOrder
    vpsId?: SortOrder
    password?: SortOrder
    username?: SortOrder
  }

  export type EnumWebsiteStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.WebsiteStatus | EnumWebsiteStatusFieldRefInput<$PrismaModel>
    in?: $Enums.WebsiteStatus[]
    notIn?: $Enums.WebsiteStatus[]
    not?: NestedEnumWebsiteStatusWithAggregatesFilter<$PrismaModel> | $Enums.WebsiteStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumWebsiteStatusFilter<$PrismaModel>
    _max?: NestedEnumWebsiteStatusFilter<$PrismaModel>
  }

  export type EnumSSLStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.SSLStatus | EnumSSLStatusFieldRefInput<$PrismaModel>
    in?: $Enums.SSLStatus[]
    notIn?: $Enums.SSLStatus[]
    not?: NestedEnumSSLStatusWithAggregatesFilter<$PrismaModel> | $Enums.SSLStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumSSLStatusFilter<$PrismaModel>
    _max?: NestedEnumSSLStatusFilter<$PrismaModel>
  }

  export type EnumActivityTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.ActivityType | EnumActivityTypeFieldRefInput<$PrismaModel>
    in?: $Enums.ActivityType[]
    notIn?: $Enums.ActivityType[]
    not?: NestedEnumActivityTypeFilter<$PrismaModel> | $Enums.ActivityType
  }

  export type EnumEntityTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.EntityType | EnumEntityTypeFieldRefInput<$PrismaModel>
    in?: $Enums.EntityType[]
    notIn?: $Enums.EntityType[]
    not?: NestedEnumEntityTypeFilter<$PrismaModel> | $Enums.EntityType
  }

  export type WebsiteNullableScalarRelationFilter = {
    is?: WebsiteWhereInput | null
    isNot?: WebsiteWhereInput | null
  }

  export type ActivityLogOrderByRelevanceInput = {
    fields: ActivityLogOrderByRelevanceFieldEnum | ActivityLogOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type ActivityLogCountOrderByAggregateInput = {
    id?: SortOrder
    action?: SortOrder
    entity?: SortOrder
    entityId?: SortOrder
    description?: SortOrder
    metadata?: SortOrder
    ipAddress?: SortOrder
    userAgent?: SortOrder
    createdAt?: SortOrder
    userId?: SortOrder
    domainId?: SortOrder
    hostingId?: SortOrder
    vpsId?: SortOrder
    websiteId?: SortOrder
  }

  export type ActivityLogMaxOrderByAggregateInput = {
    id?: SortOrder
    action?: SortOrder
    entity?: SortOrder
    entityId?: SortOrder
    description?: SortOrder
    ipAddress?: SortOrder
    userAgent?: SortOrder
    createdAt?: SortOrder
    userId?: SortOrder
    domainId?: SortOrder
    hostingId?: SortOrder
    vpsId?: SortOrder
    websiteId?: SortOrder
  }

  export type ActivityLogMinOrderByAggregateInput = {
    id?: SortOrder
    action?: SortOrder
    entity?: SortOrder
    entityId?: SortOrder
    description?: SortOrder
    ipAddress?: SortOrder
    userAgent?: SortOrder
    createdAt?: SortOrder
    userId?: SortOrder
    domainId?: SortOrder
    hostingId?: SortOrder
    vpsId?: SortOrder
    websiteId?: SortOrder
  }

  export type EnumActivityTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.ActivityType | EnumActivityTypeFieldRefInput<$PrismaModel>
    in?: $Enums.ActivityType[]
    notIn?: $Enums.ActivityType[]
    not?: NestedEnumActivityTypeWithAggregatesFilter<$PrismaModel> | $Enums.ActivityType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumActivityTypeFilter<$PrismaModel>
    _max?: NestedEnumActivityTypeFilter<$PrismaModel>
  }

  export type EnumEntityTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.EntityType | EnumEntityTypeFieldRefInput<$PrismaModel>
    in?: $Enums.EntityType[]
    notIn?: $Enums.EntityType[]
    not?: NestedEnumEntityTypeWithAggregatesFilter<$PrismaModel> | $Enums.EntityType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEntityTypeFilter<$PrismaModel>
    _max?: NestedEnumEntityTypeFilter<$PrismaModel>
  }

  export type SettingOrderByRelevanceInput = {
    fields: SettingOrderByRelevanceFieldEnum | SettingOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SettingCountOrderByAggregateInput = {
    id?: SortOrder
    key?: SortOrder
    value?: SortOrder
    type?: SortOrder
    category?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SettingMaxOrderByAggregateInput = {
    id?: SortOrder
    key?: SortOrder
    value?: SortOrder
    type?: SortOrder
    category?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SettingMinOrderByAggregateInput = {
    id?: SortOrder
    key?: SortOrder
    value?: SortOrder
    type?: SortOrder
    category?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ActivityLogCreateNestedManyWithoutUserInput = {
    create?: XOR<ActivityLogCreateWithoutUserInput, ActivityLogUncheckedCreateWithoutUserInput> | ActivityLogCreateWithoutUserInput[] | ActivityLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutUserInput | ActivityLogCreateOrConnectWithoutUserInput[]
    createMany?: ActivityLogCreateManyUserInputEnvelope
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
  }

  export type DomainCreateNestedManyWithoutUserInput = {
    create?: XOR<DomainCreateWithoutUserInput, DomainUncheckedCreateWithoutUserInput> | DomainCreateWithoutUserInput[] | DomainUncheckedCreateWithoutUserInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutUserInput | DomainCreateOrConnectWithoutUserInput[]
    createMany?: DomainCreateManyUserInputEnvelope
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
  }

  export type HostingCreateNestedManyWithoutUserInput = {
    create?: XOR<HostingCreateWithoutUserInput, HostingUncheckedCreateWithoutUserInput> | HostingCreateWithoutUserInput[] | HostingUncheckedCreateWithoutUserInput[]
    connectOrCreate?: HostingCreateOrConnectWithoutUserInput | HostingCreateOrConnectWithoutUserInput[]
    createMany?: HostingCreateManyUserInputEnvelope
    connect?: HostingWhereUniqueInput | HostingWhereUniqueInput[]
  }

  export type SessionCreateNestedManyWithoutUserInput = {
    create?: XOR<SessionCreateWithoutUserInput, SessionUncheckedCreateWithoutUserInput> | SessionCreateWithoutUserInput[] | SessionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutUserInput | SessionCreateOrConnectWithoutUserInput[]
    createMany?: SessionCreateManyUserInputEnvelope
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
  }

  export type VPSCreateNestedManyWithoutUserInput = {
    create?: XOR<VPSCreateWithoutUserInput, VPSUncheckedCreateWithoutUserInput> | VPSCreateWithoutUserInput[] | VPSUncheckedCreateWithoutUserInput[]
    connectOrCreate?: VPSCreateOrConnectWithoutUserInput | VPSCreateOrConnectWithoutUserInput[]
    createMany?: VPSCreateManyUserInputEnvelope
    connect?: VPSWhereUniqueInput | VPSWhereUniqueInput[]
  }

  export type WebsiteCreateNestedManyWithoutUserInput = {
    create?: XOR<WebsiteCreateWithoutUserInput, WebsiteUncheckedCreateWithoutUserInput> | WebsiteCreateWithoutUserInput[] | WebsiteUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutUserInput | WebsiteCreateOrConnectWithoutUserInput[]
    createMany?: WebsiteCreateManyUserInputEnvelope
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
  }

  export type ActivityLogUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<ActivityLogCreateWithoutUserInput, ActivityLogUncheckedCreateWithoutUserInput> | ActivityLogCreateWithoutUserInput[] | ActivityLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutUserInput | ActivityLogCreateOrConnectWithoutUserInput[]
    createMany?: ActivityLogCreateManyUserInputEnvelope
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
  }

  export type DomainUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<DomainCreateWithoutUserInput, DomainUncheckedCreateWithoutUserInput> | DomainCreateWithoutUserInput[] | DomainUncheckedCreateWithoutUserInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutUserInput | DomainCreateOrConnectWithoutUserInput[]
    createMany?: DomainCreateManyUserInputEnvelope
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
  }

  export type HostingUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<HostingCreateWithoutUserInput, HostingUncheckedCreateWithoutUserInput> | HostingCreateWithoutUserInput[] | HostingUncheckedCreateWithoutUserInput[]
    connectOrCreate?: HostingCreateOrConnectWithoutUserInput | HostingCreateOrConnectWithoutUserInput[]
    createMany?: HostingCreateManyUserInputEnvelope
    connect?: HostingWhereUniqueInput | HostingWhereUniqueInput[]
  }

  export type SessionUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<SessionCreateWithoutUserInput, SessionUncheckedCreateWithoutUserInput> | SessionCreateWithoutUserInput[] | SessionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutUserInput | SessionCreateOrConnectWithoutUserInput[]
    createMany?: SessionCreateManyUserInputEnvelope
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
  }

  export type VPSUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<VPSCreateWithoutUserInput, VPSUncheckedCreateWithoutUserInput> | VPSCreateWithoutUserInput[] | VPSUncheckedCreateWithoutUserInput[]
    connectOrCreate?: VPSCreateOrConnectWithoutUserInput | VPSCreateOrConnectWithoutUserInput[]
    createMany?: VPSCreateManyUserInputEnvelope
    connect?: VPSWhereUniqueInput | VPSWhereUniqueInput[]
  }

  export type WebsiteUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<WebsiteCreateWithoutUserInput, WebsiteUncheckedCreateWithoutUserInput> | WebsiteCreateWithoutUserInput[] | WebsiteUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutUserInput | WebsiteCreateOrConnectWithoutUserInput[]
    createMany?: WebsiteCreateManyUserInputEnvelope
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type EnumUserRoleFieldUpdateOperationsInput = {
    set?: $Enums.UserRole
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type ActivityLogUpdateManyWithoutUserNestedInput = {
    create?: XOR<ActivityLogCreateWithoutUserInput, ActivityLogUncheckedCreateWithoutUserInput> | ActivityLogCreateWithoutUserInput[] | ActivityLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutUserInput | ActivityLogCreateOrConnectWithoutUserInput[]
    upsert?: ActivityLogUpsertWithWhereUniqueWithoutUserInput | ActivityLogUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ActivityLogCreateManyUserInputEnvelope
    set?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    disconnect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    delete?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    update?: ActivityLogUpdateWithWhereUniqueWithoutUserInput | ActivityLogUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ActivityLogUpdateManyWithWhereWithoutUserInput | ActivityLogUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
  }

  export type DomainUpdateManyWithoutUserNestedInput = {
    create?: XOR<DomainCreateWithoutUserInput, DomainUncheckedCreateWithoutUserInput> | DomainCreateWithoutUserInput[] | DomainUncheckedCreateWithoutUserInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutUserInput | DomainCreateOrConnectWithoutUserInput[]
    upsert?: DomainUpsertWithWhereUniqueWithoutUserInput | DomainUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: DomainCreateManyUserInputEnvelope
    set?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    disconnect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    delete?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    update?: DomainUpdateWithWhereUniqueWithoutUserInput | DomainUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: DomainUpdateManyWithWhereWithoutUserInput | DomainUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: DomainScalarWhereInput | DomainScalarWhereInput[]
  }

  export type HostingUpdateManyWithoutUserNestedInput = {
    create?: XOR<HostingCreateWithoutUserInput, HostingUncheckedCreateWithoutUserInput> | HostingCreateWithoutUserInput[] | HostingUncheckedCreateWithoutUserInput[]
    connectOrCreate?: HostingCreateOrConnectWithoutUserInput | HostingCreateOrConnectWithoutUserInput[]
    upsert?: HostingUpsertWithWhereUniqueWithoutUserInput | HostingUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: HostingCreateManyUserInputEnvelope
    set?: HostingWhereUniqueInput | HostingWhereUniqueInput[]
    disconnect?: HostingWhereUniqueInput | HostingWhereUniqueInput[]
    delete?: HostingWhereUniqueInput | HostingWhereUniqueInput[]
    connect?: HostingWhereUniqueInput | HostingWhereUniqueInput[]
    update?: HostingUpdateWithWhereUniqueWithoutUserInput | HostingUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: HostingUpdateManyWithWhereWithoutUserInput | HostingUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: HostingScalarWhereInput | HostingScalarWhereInput[]
  }

  export type SessionUpdateManyWithoutUserNestedInput = {
    create?: XOR<SessionCreateWithoutUserInput, SessionUncheckedCreateWithoutUserInput> | SessionCreateWithoutUserInput[] | SessionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutUserInput | SessionCreateOrConnectWithoutUserInput[]
    upsert?: SessionUpsertWithWhereUniqueWithoutUserInput | SessionUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: SessionCreateManyUserInputEnvelope
    set?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    disconnect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    delete?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    update?: SessionUpdateWithWhereUniqueWithoutUserInput | SessionUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: SessionUpdateManyWithWhereWithoutUserInput | SessionUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: SessionScalarWhereInput | SessionScalarWhereInput[]
  }

  export type VPSUpdateManyWithoutUserNestedInput = {
    create?: XOR<VPSCreateWithoutUserInput, VPSUncheckedCreateWithoutUserInput> | VPSCreateWithoutUserInput[] | VPSUncheckedCreateWithoutUserInput[]
    connectOrCreate?: VPSCreateOrConnectWithoutUserInput | VPSCreateOrConnectWithoutUserInput[]
    upsert?: VPSUpsertWithWhereUniqueWithoutUserInput | VPSUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: VPSCreateManyUserInputEnvelope
    set?: VPSWhereUniqueInput | VPSWhereUniqueInput[]
    disconnect?: VPSWhereUniqueInput | VPSWhereUniqueInput[]
    delete?: VPSWhereUniqueInput | VPSWhereUniqueInput[]
    connect?: VPSWhereUniqueInput | VPSWhereUniqueInput[]
    update?: VPSUpdateWithWhereUniqueWithoutUserInput | VPSUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: VPSUpdateManyWithWhereWithoutUserInput | VPSUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: VPSScalarWhereInput | VPSScalarWhereInput[]
  }

  export type WebsiteUpdateManyWithoutUserNestedInput = {
    create?: XOR<WebsiteCreateWithoutUserInput, WebsiteUncheckedCreateWithoutUserInput> | WebsiteCreateWithoutUserInput[] | WebsiteUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutUserInput | WebsiteCreateOrConnectWithoutUserInput[]
    upsert?: WebsiteUpsertWithWhereUniqueWithoutUserInput | WebsiteUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: WebsiteCreateManyUserInputEnvelope
    set?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    disconnect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    delete?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    update?: WebsiteUpdateWithWhereUniqueWithoutUserInput | WebsiteUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: WebsiteUpdateManyWithWhereWithoutUserInput | WebsiteUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: WebsiteScalarWhereInput | WebsiteScalarWhereInput[]
  }

  export type ActivityLogUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<ActivityLogCreateWithoutUserInput, ActivityLogUncheckedCreateWithoutUserInput> | ActivityLogCreateWithoutUserInput[] | ActivityLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutUserInput | ActivityLogCreateOrConnectWithoutUserInput[]
    upsert?: ActivityLogUpsertWithWhereUniqueWithoutUserInput | ActivityLogUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ActivityLogCreateManyUserInputEnvelope
    set?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    disconnect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    delete?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    update?: ActivityLogUpdateWithWhereUniqueWithoutUserInput | ActivityLogUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ActivityLogUpdateManyWithWhereWithoutUserInput | ActivityLogUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
  }

  export type DomainUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<DomainCreateWithoutUserInput, DomainUncheckedCreateWithoutUserInput> | DomainCreateWithoutUserInput[] | DomainUncheckedCreateWithoutUserInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutUserInput | DomainCreateOrConnectWithoutUserInput[]
    upsert?: DomainUpsertWithWhereUniqueWithoutUserInput | DomainUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: DomainCreateManyUserInputEnvelope
    set?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    disconnect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    delete?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    update?: DomainUpdateWithWhereUniqueWithoutUserInput | DomainUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: DomainUpdateManyWithWhereWithoutUserInput | DomainUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: DomainScalarWhereInput | DomainScalarWhereInput[]
  }

  export type HostingUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<HostingCreateWithoutUserInput, HostingUncheckedCreateWithoutUserInput> | HostingCreateWithoutUserInput[] | HostingUncheckedCreateWithoutUserInput[]
    connectOrCreate?: HostingCreateOrConnectWithoutUserInput | HostingCreateOrConnectWithoutUserInput[]
    upsert?: HostingUpsertWithWhereUniqueWithoutUserInput | HostingUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: HostingCreateManyUserInputEnvelope
    set?: HostingWhereUniqueInput | HostingWhereUniqueInput[]
    disconnect?: HostingWhereUniqueInput | HostingWhereUniqueInput[]
    delete?: HostingWhereUniqueInput | HostingWhereUniqueInput[]
    connect?: HostingWhereUniqueInput | HostingWhereUniqueInput[]
    update?: HostingUpdateWithWhereUniqueWithoutUserInput | HostingUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: HostingUpdateManyWithWhereWithoutUserInput | HostingUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: HostingScalarWhereInput | HostingScalarWhereInput[]
  }

  export type SessionUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<SessionCreateWithoutUserInput, SessionUncheckedCreateWithoutUserInput> | SessionCreateWithoutUserInput[] | SessionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: SessionCreateOrConnectWithoutUserInput | SessionCreateOrConnectWithoutUserInput[]
    upsert?: SessionUpsertWithWhereUniqueWithoutUserInput | SessionUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: SessionCreateManyUserInputEnvelope
    set?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    disconnect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    delete?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    connect?: SessionWhereUniqueInput | SessionWhereUniqueInput[]
    update?: SessionUpdateWithWhereUniqueWithoutUserInput | SessionUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: SessionUpdateManyWithWhereWithoutUserInput | SessionUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: SessionScalarWhereInput | SessionScalarWhereInput[]
  }

  export type VPSUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<VPSCreateWithoutUserInput, VPSUncheckedCreateWithoutUserInput> | VPSCreateWithoutUserInput[] | VPSUncheckedCreateWithoutUserInput[]
    connectOrCreate?: VPSCreateOrConnectWithoutUserInput | VPSCreateOrConnectWithoutUserInput[]
    upsert?: VPSUpsertWithWhereUniqueWithoutUserInput | VPSUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: VPSCreateManyUserInputEnvelope
    set?: VPSWhereUniqueInput | VPSWhereUniqueInput[]
    disconnect?: VPSWhereUniqueInput | VPSWhereUniqueInput[]
    delete?: VPSWhereUniqueInput | VPSWhereUniqueInput[]
    connect?: VPSWhereUniqueInput | VPSWhereUniqueInput[]
    update?: VPSUpdateWithWhereUniqueWithoutUserInput | VPSUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: VPSUpdateManyWithWhereWithoutUserInput | VPSUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: VPSScalarWhereInput | VPSScalarWhereInput[]
  }

  export type WebsiteUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<WebsiteCreateWithoutUserInput, WebsiteUncheckedCreateWithoutUserInput> | WebsiteCreateWithoutUserInput[] | WebsiteUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutUserInput | WebsiteCreateOrConnectWithoutUserInput[]
    upsert?: WebsiteUpsertWithWhereUniqueWithoutUserInput | WebsiteUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: WebsiteCreateManyUserInputEnvelope
    set?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    disconnect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    delete?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    update?: WebsiteUpdateWithWhereUniqueWithoutUserInput | WebsiteUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: WebsiteUpdateManyWithWhereWithoutUserInput | WebsiteUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: WebsiteScalarWhereInput | WebsiteScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutSessionsInput = {
    create?: XOR<UserCreateWithoutSessionsInput, UserUncheckedCreateWithoutSessionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutSessionsInput
    connect?: UserWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutSessionsNestedInput = {
    create?: XOR<UserCreateWithoutSessionsInput, UserUncheckedCreateWithoutSessionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutSessionsInput
    upsert?: UserUpsertWithoutSessionsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutSessionsInput, UserUpdateWithoutSessionsInput>, UserUncheckedUpdateWithoutSessionsInput>
  }

  export type ActivityLogCreateNestedManyWithoutDomainInput = {
    create?: XOR<ActivityLogCreateWithoutDomainInput, ActivityLogUncheckedCreateWithoutDomainInput> | ActivityLogCreateWithoutDomainInput[] | ActivityLogUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutDomainInput | ActivityLogCreateOrConnectWithoutDomainInput[]
    createMany?: ActivityLogCreateManyDomainInputEnvelope
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
  }

  export type UserCreateNestedOneWithoutDomainsInput = {
    create?: XOR<UserCreateWithoutDomainsInput, UserUncheckedCreateWithoutDomainsInput>
    connectOrCreate?: UserCreateOrConnectWithoutDomainsInput
    connect?: UserWhereUniqueInput
  }

  export type HostingCreateNestedOneWithoutDomainsInput = {
    create?: XOR<HostingCreateWithoutDomainsInput, HostingUncheckedCreateWithoutDomainsInput>
    connectOrCreate?: HostingCreateOrConnectWithoutDomainsInput
    connect?: HostingWhereUniqueInput
  }

  export type VPSCreateNestedOneWithoutDomainsInput = {
    create?: XOR<VPSCreateWithoutDomainsInput, VPSUncheckedCreateWithoutDomainsInput>
    connectOrCreate?: VPSCreateOrConnectWithoutDomainsInput
    connect?: VPSWhereUniqueInput
  }

  export type WebsiteCreateNestedManyWithoutDomainInput = {
    create?: XOR<WebsiteCreateWithoutDomainInput, WebsiteUncheckedCreateWithoutDomainInput> | WebsiteCreateWithoutDomainInput[] | WebsiteUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutDomainInput | WebsiteCreateOrConnectWithoutDomainInput[]
    createMany?: WebsiteCreateManyDomainInputEnvelope
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
  }

  export type ActivityLogUncheckedCreateNestedManyWithoutDomainInput = {
    create?: XOR<ActivityLogCreateWithoutDomainInput, ActivityLogUncheckedCreateWithoutDomainInput> | ActivityLogCreateWithoutDomainInput[] | ActivityLogUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutDomainInput | ActivityLogCreateOrConnectWithoutDomainInput[]
    createMany?: ActivityLogCreateManyDomainInputEnvelope
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
  }

  export type WebsiteUncheckedCreateNestedManyWithoutDomainInput = {
    create?: XOR<WebsiteCreateWithoutDomainInput, WebsiteUncheckedCreateWithoutDomainInput> | WebsiteCreateWithoutDomainInput[] | WebsiteUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutDomainInput | WebsiteCreateOrConnectWithoutDomainInput[]
    createMany?: WebsiteCreateManyDomainInputEnvelope
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
  }

  export type EnumDomainStatusFieldUpdateOperationsInput = {
    set?: $Enums.DomainStatus
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type ActivityLogUpdateManyWithoutDomainNestedInput = {
    create?: XOR<ActivityLogCreateWithoutDomainInput, ActivityLogUncheckedCreateWithoutDomainInput> | ActivityLogCreateWithoutDomainInput[] | ActivityLogUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutDomainInput | ActivityLogCreateOrConnectWithoutDomainInput[]
    upsert?: ActivityLogUpsertWithWhereUniqueWithoutDomainInput | ActivityLogUpsertWithWhereUniqueWithoutDomainInput[]
    createMany?: ActivityLogCreateManyDomainInputEnvelope
    set?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    disconnect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    delete?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    update?: ActivityLogUpdateWithWhereUniqueWithoutDomainInput | ActivityLogUpdateWithWhereUniqueWithoutDomainInput[]
    updateMany?: ActivityLogUpdateManyWithWhereWithoutDomainInput | ActivityLogUpdateManyWithWhereWithoutDomainInput[]
    deleteMany?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
  }

  export type UserUpdateOneRequiredWithoutDomainsNestedInput = {
    create?: XOR<UserCreateWithoutDomainsInput, UserUncheckedCreateWithoutDomainsInput>
    connectOrCreate?: UserCreateOrConnectWithoutDomainsInput
    upsert?: UserUpsertWithoutDomainsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutDomainsInput, UserUpdateWithoutDomainsInput>, UserUncheckedUpdateWithoutDomainsInput>
  }

  export type HostingUpdateOneWithoutDomainsNestedInput = {
    create?: XOR<HostingCreateWithoutDomainsInput, HostingUncheckedCreateWithoutDomainsInput>
    connectOrCreate?: HostingCreateOrConnectWithoutDomainsInput
    upsert?: HostingUpsertWithoutDomainsInput
    disconnect?: HostingWhereInput | boolean
    delete?: HostingWhereInput | boolean
    connect?: HostingWhereUniqueInput
    update?: XOR<XOR<HostingUpdateToOneWithWhereWithoutDomainsInput, HostingUpdateWithoutDomainsInput>, HostingUncheckedUpdateWithoutDomainsInput>
  }

  export type VPSUpdateOneWithoutDomainsNestedInput = {
    create?: XOR<VPSCreateWithoutDomainsInput, VPSUncheckedCreateWithoutDomainsInput>
    connectOrCreate?: VPSCreateOrConnectWithoutDomainsInput
    upsert?: VPSUpsertWithoutDomainsInput
    disconnect?: VPSWhereInput | boolean
    delete?: VPSWhereInput | boolean
    connect?: VPSWhereUniqueInput
    update?: XOR<XOR<VPSUpdateToOneWithWhereWithoutDomainsInput, VPSUpdateWithoutDomainsInput>, VPSUncheckedUpdateWithoutDomainsInput>
  }

  export type WebsiteUpdateManyWithoutDomainNestedInput = {
    create?: XOR<WebsiteCreateWithoutDomainInput, WebsiteUncheckedCreateWithoutDomainInput> | WebsiteCreateWithoutDomainInput[] | WebsiteUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutDomainInput | WebsiteCreateOrConnectWithoutDomainInput[]
    upsert?: WebsiteUpsertWithWhereUniqueWithoutDomainInput | WebsiteUpsertWithWhereUniqueWithoutDomainInput[]
    createMany?: WebsiteCreateManyDomainInputEnvelope
    set?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    disconnect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    delete?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    update?: WebsiteUpdateWithWhereUniqueWithoutDomainInput | WebsiteUpdateWithWhereUniqueWithoutDomainInput[]
    updateMany?: WebsiteUpdateManyWithWhereWithoutDomainInput | WebsiteUpdateManyWithWhereWithoutDomainInput[]
    deleteMany?: WebsiteScalarWhereInput | WebsiteScalarWhereInput[]
  }

  export type ActivityLogUncheckedUpdateManyWithoutDomainNestedInput = {
    create?: XOR<ActivityLogCreateWithoutDomainInput, ActivityLogUncheckedCreateWithoutDomainInput> | ActivityLogCreateWithoutDomainInput[] | ActivityLogUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutDomainInput | ActivityLogCreateOrConnectWithoutDomainInput[]
    upsert?: ActivityLogUpsertWithWhereUniqueWithoutDomainInput | ActivityLogUpsertWithWhereUniqueWithoutDomainInput[]
    createMany?: ActivityLogCreateManyDomainInputEnvelope
    set?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    disconnect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    delete?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    update?: ActivityLogUpdateWithWhereUniqueWithoutDomainInput | ActivityLogUpdateWithWhereUniqueWithoutDomainInput[]
    updateMany?: ActivityLogUpdateManyWithWhereWithoutDomainInput | ActivityLogUpdateManyWithWhereWithoutDomainInput[]
    deleteMany?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
  }

  export type WebsiteUncheckedUpdateManyWithoutDomainNestedInput = {
    create?: XOR<WebsiteCreateWithoutDomainInput, WebsiteUncheckedCreateWithoutDomainInput> | WebsiteCreateWithoutDomainInput[] | WebsiteUncheckedCreateWithoutDomainInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutDomainInput | WebsiteCreateOrConnectWithoutDomainInput[]
    upsert?: WebsiteUpsertWithWhereUniqueWithoutDomainInput | WebsiteUpsertWithWhereUniqueWithoutDomainInput[]
    createMany?: WebsiteCreateManyDomainInputEnvelope
    set?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    disconnect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    delete?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    update?: WebsiteUpdateWithWhereUniqueWithoutDomainInput | WebsiteUpdateWithWhereUniqueWithoutDomainInput[]
    updateMany?: WebsiteUpdateManyWithWhereWithoutDomainInput | WebsiteUpdateManyWithWhereWithoutDomainInput[]
    deleteMany?: WebsiteScalarWhereInput | WebsiteScalarWhereInput[]
  }

  export type ActivityLogCreateNestedManyWithoutHostingInput = {
    create?: XOR<ActivityLogCreateWithoutHostingInput, ActivityLogUncheckedCreateWithoutHostingInput> | ActivityLogCreateWithoutHostingInput[] | ActivityLogUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutHostingInput | ActivityLogCreateOrConnectWithoutHostingInput[]
    createMany?: ActivityLogCreateManyHostingInputEnvelope
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
  }

  export type DomainCreateNestedManyWithoutHostingInput = {
    create?: XOR<DomainCreateWithoutHostingInput, DomainUncheckedCreateWithoutHostingInput> | DomainCreateWithoutHostingInput[] | DomainUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutHostingInput | DomainCreateOrConnectWithoutHostingInput[]
    createMany?: DomainCreateManyHostingInputEnvelope
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
  }

  export type UserCreateNestedOneWithoutHostingInput = {
    create?: XOR<UserCreateWithoutHostingInput, UserUncheckedCreateWithoutHostingInput>
    connectOrCreate?: UserCreateOrConnectWithoutHostingInput
    connect?: UserWhereUniqueInput
  }

  export type WebsiteCreateNestedManyWithoutHostingInput = {
    create?: XOR<WebsiteCreateWithoutHostingInput, WebsiteUncheckedCreateWithoutHostingInput> | WebsiteCreateWithoutHostingInput[] | WebsiteUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutHostingInput | WebsiteCreateOrConnectWithoutHostingInput[]
    createMany?: WebsiteCreateManyHostingInputEnvelope
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
  }

  export type ActivityLogUncheckedCreateNestedManyWithoutHostingInput = {
    create?: XOR<ActivityLogCreateWithoutHostingInput, ActivityLogUncheckedCreateWithoutHostingInput> | ActivityLogCreateWithoutHostingInput[] | ActivityLogUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutHostingInput | ActivityLogCreateOrConnectWithoutHostingInput[]
    createMany?: ActivityLogCreateManyHostingInputEnvelope
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
  }

  export type DomainUncheckedCreateNestedManyWithoutHostingInput = {
    create?: XOR<DomainCreateWithoutHostingInput, DomainUncheckedCreateWithoutHostingInput> | DomainCreateWithoutHostingInput[] | DomainUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutHostingInput | DomainCreateOrConnectWithoutHostingInput[]
    createMany?: DomainCreateManyHostingInputEnvelope
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
  }

  export type WebsiteUncheckedCreateNestedManyWithoutHostingInput = {
    create?: XOR<WebsiteCreateWithoutHostingInput, WebsiteUncheckedCreateWithoutHostingInput> | WebsiteCreateWithoutHostingInput[] | WebsiteUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutHostingInput | WebsiteCreateOrConnectWithoutHostingInput[]
    createMany?: WebsiteCreateManyHostingInputEnvelope
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
  }

  export type EnumHostingStatusFieldUpdateOperationsInput = {
    set?: $Enums.HostingStatus
  }

  export type ActivityLogUpdateManyWithoutHostingNestedInput = {
    create?: XOR<ActivityLogCreateWithoutHostingInput, ActivityLogUncheckedCreateWithoutHostingInput> | ActivityLogCreateWithoutHostingInput[] | ActivityLogUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutHostingInput | ActivityLogCreateOrConnectWithoutHostingInput[]
    upsert?: ActivityLogUpsertWithWhereUniqueWithoutHostingInput | ActivityLogUpsertWithWhereUniqueWithoutHostingInput[]
    createMany?: ActivityLogCreateManyHostingInputEnvelope
    set?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    disconnect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    delete?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    update?: ActivityLogUpdateWithWhereUniqueWithoutHostingInput | ActivityLogUpdateWithWhereUniqueWithoutHostingInput[]
    updateMany?: ActivityLogUpdateManyWithWhereWithoutHostingInput | ActivityLogUpdateManyWithWhereWithoutHostingInput[]
    deleteMany?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
  }

  export type DomainUpdateManyWithoutHostingNestedInput = {
    create?: XOR<DomainCreateWithoutHostingInput, DomainUncheckedCreateWithoutHostingInput> | DomainCreateWithoutHostingInput[] | DomainUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutHostingInput | DomainCreateOrConnectWithoutHostingInput[]
    upsert?: DomainUpsertWithWhereUniqueWithoutHostingInput | DomainUpsertWithWhereUniqueWithoutHostingInput[]
    createMany?: DomainCreateManyHostingInputEnvelope
    set?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    disconnect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    delete?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    update?: DomainUpdateWithWhereUniqueWithoutHostingInput | DomainUpdateWithWhereUniqueWithoutHostingInput[]
    updateMany?: DomainUpdateManyWithWhereWithoutHostingInput | DomainUpdateManyWithWhereWithoutHostingInput[]
    deleteMany?: DomainScalarWhereInput | DomainScalarWhereInput[]
  }

  export type UserUpdateOneRequiredWithoutHostingNestedInput = {
    create?: XOR<UserCreateWithoutHostingInput, UserUncheckedCreateWithoutHostingInput>
    connectOrCreate?: UserCreateOrConnectWithoutHostingInput
    upsert?: UserUpsertWithoutHostingInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutHostingInput, UserUpdateWithoutHostingInput>, UserUncheckedUpdateWithoutHostingInput>
  }

  export type WebsiteUpdateManyWithoutHostingNestedInput = {
    create?: XOR<WebsiteCreateWithoutHostingInput, WebsiteUncheckedCreateWithoutHostingInput> | WebsiteCreateWithoutHostingInput[] | WebsiteUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutHostingInput | WebsiteCreateOrConnectWithoutHostingInput[]
    upsert?: WebsiteUpsertWithWhereUniqueWithoutHostingInput | WebsiteUpsertWithWhereUniqueWithoutHostingInput[]
    createMany?: WebsiteCreateManyHostingInputEnvelope
    set?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    disconnect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    delete?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    update?: WebsiteUpdateWithWhereUniqueWithoutHostingInput | WebsiteUpdateWithWhereUniqueWithoutHostingInput[]
    updateMany?: WebsiteUpdateManyWithWhereWithoutHostingInput | WebsiteUpdateManyWithWhereWithoutHostingInput[]
    deleteMany?: WebsiteScalarWhereInput | WebsiteScalarWhereInput[]
  }

  export type ActivityLogUncheckedUpdateManyWithoutHostingNestedInput = {
    create?: XOR<ActivityLogCreateWithoutHostingInput, ActivityLogUncheckedCreateWithoutHostingInput> | ActivityLogCreateWithoutHostingInput[] | ActivityLogUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutHostingInput | ActivityLogCreateOrConnectWithoutHostingInput[]
    upsert?: ActivityLogUpsertWithWhereUniqueWithoutHostingInput | ActivityLogUpsertWithWhereUniqueWithoutHostingInput[]
    createMany?: ActivityLogCreateManyHostingInputEnvelope
    set?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    disconnect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    delete?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    update?: ActivityLogUpdateWithWhereUniqueWithoutHostingInput | ActivityLogUpdateWithWhereUniqueWithoutHostingInput[]
    updateMany?: ActivityLogUpdateManyWithWhereWithoutHostingInput | ActivityLogUpdateManyWithWhereWithoutHostingInput[]
    deleteMany?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
  }

  export type DomainUncheckedUpdateManyWithoutHostingNestedInput = {
    create?: XOR<DomainCreateWithoutHostingInput, DomainUncheckedCreateWithoutHostingInput> | DomainCreateWithoutHostingInput[] | DomainUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutHostingInput | DomainCreateOrConnectWithoutHostingInput[]
    upsert?: DomainUpsertWithWhereUniqueWithoutHostingInput | DomainUpsertWithWhereUniqueWithoutHostingInput[]
    createMany?: DomainCreateManyHostingInputEnvelope
    set?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    disconnect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    delete?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    update?: DomainUpdateWithWhereUniqueWithoutHostingInput | DomainUpdateWithWhereUniqueWithoutHostingInput[]
    updateMany?: DomainUpdateManyWithWhereWithoutHostingInput | DomainUpdateManyWithWhereWithoutHostingInput[]
    deleteMany?: DomainScalarWhereInput | DomainScalarWhereInput[]
  }

  export type WebsiteUncheckedUpdateManyWithoutHostingNestedInput = {
    create?: XOR<WebsiteCreateWithoutHostingInput, WebsiteUncheckedCreateWithoutHostingInput> | WebsiteCreateWithoutHostingInput[] | WebsiteUncheckedCreateWithoutHostingInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutHostingInput | WebsiteCreateOrConnectWithoutHostingInput[]
    upsert?: WebsiteUpsertWithWhereUniqueWithoutHostingInput | WebsiteUpsertWithWhereUniqueWithoutHostingInput[]
    createMany?: WebsiteCreateManyHostingInputEnvelope
    set?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    disconnect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    delete?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    update?: WebsiteUpdateWithWhereUniqueWithoutHostingInput | WebsiteUpdateWithWhereUniqueWithoutHostingInput[]
    updateMany?: WebsiteUpdateManyWithWhereWithoutHostingInput | WebsiteUpdateManyWithWhereWithoutHostingInput[]
    deleteMany?: WebsiteScalarWhereInput | WebsiteScalarWhereInput[]
  }

  export type ActivityLogCreateNestedManyWithoutVpsInput = {
    create?: XOR<ActivityLogCreateWithoutVpsInput, ActivityLogUncheckedCreateWithoutVpsInput> | ActivityLogCreateWithoutVpsInput[] | ActivityLogUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutVpsInput | ActivityLogCreateOrConnectWithoutVpsInput[]
    createMany?: ActivityLogCreateManyVpsInputEnvelope
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
  }

  export type DomainCreateNestedManyWithoutVpsInput = {
    create?: XOR<DomainCreateWithoutVpsInput, DomainUncheckedCreateWithoutVpsInput> | DomainCreateWithoutVpsInput[] | DomainUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutVpsInput | DomainCreateOrConnectWithoutVpsInput[]
    createMany?: DomainCreateManyVpsInputEnvelope
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
  }

  export type UserCreateNestedOneWithoutVpsInput = {
    create?: XOR<UserCreateWithoutVpsInput, UserUncheckedCreateWithoutVpsInput>
    connectOrCreate?: UserCreateOrConnectWithoutVpsInput
    connect?: UserWhereUniqueInput
  }

  export type WebsiteCreateNestedManyWithoutVpsInput = {
    create?: XOR<WebsiteCreateWithoutVpsInput, WebsiteUncheckedCreateWithoutVpsInput> | WebsiteCreateWithoutVpsInput[] | WebsiteUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutVpsInput | WebsiteCreateOrConnectWithoutVpsInput[]
    createMany?: WebsiteCreateManyVpsInputEnvelope
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
  }

  export type ActivityLogUncheckedCreateNestedManyWithoutVpsInput = {
    create?: XOR<ActivityLogCreateWithoutVpsInput, ActivityLogUncheckedCreateWithoutVpsInput> | ActivityLogCreateWithoutVpsInput[] | ActivityLogUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutVpsInput | ActivityLogCreateOrConnectWithoutVpsInput[]
    createMany?: ActivityLogCreateManyVpsInputEnvelope
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
  }

  export type DomainUncheckedCreateNestedManyWithoutVpsInput = {
    create?: XOR<DomainCreateWithoutVpsInput, DomainUncheckedCreateWithoutVpsInput> | DomainCreateWithoutVpsInput[] | DomainUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutVpsInput | DomainCreateOrConnectWithoutVpsInput[]
    createMany?: DomainCreateManyVpsInputEnvelope
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
  }

  export type WebsiteUncheckedCreateNestedManyWithoutVpsInput = {
    create?: XOR<WebsiteCreateWithoutVpsInput, WebsiteUncheckedCreateWithoutVpsInput> | WebsiteCreateWithoutVpsInput[] | WebsiteUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutVpsInput | WebsiteCreateOrConnectWithoutVpsInput[]
    createMany?: WebsiteCreateManyVpsInputEnvelope
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
  }

  export type EnumVPSStatusFieldUpdateOperationsInput = {
    set?: $Enums.VPSStatus
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type ActivityLogUpdateManyWithoutVpsNestedInput = {
    create?: XOR<ActivityLogCreateWithoutVpsInput, ActivityLogUncheckedCreateWithoutVpsInput> | ActivityLogCreateWithoutVpsInput[] | ActivityLogUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutVpsInput | ActivityLogCreateOrConnectWithoutVpsInput[]
    upsert?: ActivityLogUpsertWithWhereUniqueWithoutVpsInput | ActivityLogUpsertWithWhereUniqueWithoutVpsInput[]
    createMany?: ActivityLogCreateManyVpsInputEnvelope
    set?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    disconnect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    delete?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    update?: ActivityLogUpdateWithWhereUniqueWithoutVpsInput | ActivityLogUpdateWithWhereUniqueWithoutVpsInput[]
    updateMany?: ActivityLogUpdateManyWithWhereWithoutVpsInput | ActivityLogUpdateManyWithWhereWithoutVpsInput[]
    deleteMany?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
  }

  export type DomainUpdateManyWithoutVpsNestedInput = {
    create?: XOR<DomainCreateWithoutVpsInput, DomainUncheckedCreateWithoutVpsInput> | DomainCreateWithoutVpsInput[] | DomainUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutVpsInput | DomainCreateOrConnectWithoutVpsInput[]
    upsert?: DomainUpsertWithWhereUniqueWithoutVpsInput | DomainUpsertWithWhereUniqueWithoutVpsInput[]
    createMany?: DomainCreateManyVpsInputEnvelope
    set?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    disconnect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    delete?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    update?: DomainUpdateWithWhereUniqueWithoutVpsInput | DomainUpdateWithWhereUniqueWithoutVpsInput[]
    updateMany?: DomainUpdateManyWithWhereWithoutVpsInput | DomainUpdateManyWithWhereWithoutVpsInput[]
    deleteMany?: DomainScalarWhereInput | DomainScalarWhereInput[]
  }

  export type UserUpdateOneRequiredWithoutVpsNestedInput = {
    create?: XOR<UserCreateWithoutVpsInput, UserUncheckedCreateWithoutVpsInput>
    connectOrCreate?: UserCreateOrConnectWithoutVpsInput
    upsert?: UserUpsertWithoutVpsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutVpsInput, UserUpdateWithoutVpsInput>, UserUncheckedUpdateWithoutVpsInput>
  }

  export type WebsiteUpdateManyWithoutVpsNestedInput = {
    create?: XOR<WebsiteCreateWithoutVpsInput, WebsiteUncheckedCreateWithoutVpsInput> | WebsiteCreateWithoutVpsInput[] | WebsiteUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutVpsInput | WebsiteCreateOrConnectWithoutVpsInput[]
    upsert?: WebsiteUpsertWithWhereUniqueWithoutVpsInput | WebsiteUpsertWithWhereUniqueWithoutVpsInput[]
    createMany?: WebsiteCreateManyVpsInputEnvelope
    set?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    disconnect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    delete?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    update?: WebsiteUpdateWithWhereUniqueWithoutVpsInput | WebsiteUpdateWithWhereUniqueWithoutVpsInput[]
    updateMany?: WebsiteUpdateManyWithWhereWithoutVpsInput | WebsiteUpdateManyWithWhereWithoutVpsInput[]
    deleteMany?: WebsiteScalarWhereInput | WebsiteScalarWhereInput[]
  }

  export type ActivityLogUncheckedUpdateManyWithoutVpsNestedInput = {
    create?: XOR<ActivityLogCreateWithoutVpsInput, ActivityLogUncheckedCreateWithoutVpsInput> | ActivityLogCreateWithoutVpsInput[] | ActivityLogUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutVpsInput | ActivityLogCreateOrConnectWithoutVpsInput[]
    upsert?: ActivityLogUpsertWithWhereUniqueWithoutVpsInput | ActivityLogUpsertWithWhereUniqueWithoutVpsInput[]
    createMany?: ActivityLogCreateManyVpsInputEnvelope
    set?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    disconnect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    delete?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    update?: ActivityLogUpdateWithWhereUniqueWithoutVpsInput | ActivityLogUpdateWithWhereUniqueWithoutVpsInput[]
    updateMany?: ActivityLogUpdateManyWithWhereWithoutVpsInput | ActivityLogUpdateManyWithWhereWithoutVpsInput[]
    deleteMany?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
  }

  export type DomainUncheckedUpdateManyWithoutVpsNestedInput = {
    create?: XOR<DomainCreateWithoutVpsInput, DomainUncheckedCreateWithoutVpsInput> | DomainCreateWithoutVpsInput[] | DomainUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: DomainCreateOrConnectWithoutVpsInput | DomainCreateOrConnectWithoutVpsInput[]
    upsert?: DomainUpsertWithWhereUniqueWithoutVpsInput | DomainUpsertWithWhereUniqueWithoutVpsInput[]
    createMany?: DomainCreateManyVpsInputEnvelope
    set?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    disconnect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    delete?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    connect?: DomainWhereUniqueInput | DomainWhereUniqueInput[]
    update?: DomainUpdateWithWhereUniqueWithoutVpsInput | DomainUpdateWithWhereUniqueWithoutVpsInput[]
    updateMany?: DomainUpdateManyWithWhereWithoutVpsInput | DomainUpdateManyWithWhereWithoutVpsInput[]
    deleteMany?: DomainScalarWhereInput | DomainScalarWhereInput[]
  }

  export type WebsiteUncheckedUpdateManyWithoutVpsNestedInput = {
    create?: XOR<WebsiteCreateWithoutVpsInput, WebsiteUncheckedCreateWithoutVpsInput> | WebsiteCreateWithoutVpsInput[] | WebsiteUncheckedCreateWithoutVpsInput[]
    connectOrCreate?: WebsiteCreateOrConnectWithoutVpsInput | WebsiteCreateOrConnectWithoutVpsInput[]
    upsert?: WebsiteUpsertWithWhereUniqueWithoutVpsInput | WebsiteUpsertWithWhereUniqueWithoutVpsInput[]
    createMany?: WebsiteCreateManyVpsInputEnvelope
    set?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    disconnect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    delete?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    connect?: WebsiteWhereUniqueInput | WebsiteWhereUniqueInput[]
    update?: WebsiteUpdateWithWhereUniqueWithoutVpsInput | WebsiteUpdateWithWhereUniqueWithoutVpsInput[]
    updateMany?: WebsiteUpdateManyWithWhereWithoutVpsInput | WebsiteUpdateManyWithWhereWithoutVpsInput[]
    deleteMany?: WebsiteScalarWhereInput | WebsiteScalarWhereInput[]
  }

  export type ActivityLogCreateNestedManyWithoutWebsiteInput = {
    create?: XOR<ActivityLogCreateWithoutWebsiteInput, ActivityLogUncheckedCreateWithoutWebsiteInput> | ActivityLogCreateWithoutWebsiteInput[] | ActivityLogUncheckedCreateWithoutWebsiteInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutWebsiteInput | ActivityLogCreateOrConnectWithoutWebsiteInput[]
    createMany?: ActivityLogCreateManyWebsiteInputEnvelope
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
  }

  export type UserCreateNestedOneWithoutWebsitesInput = {
    create?: XOR<UserCreateWithoutWebsitesInput, UserUncheckedCreateWithoutWebsitesInput>
    connectOrCreate?: UserCreateOrConnectWithoutWebsitesInput
    connect?: UserWhereUniqueInput
  }

  export type DomainCreateNestedOneWithoutWebsitesInput = {
    create?: XOR<DomainCreateWithoutWebsitesInput, DomainUncheckedCreateWithoutWebsitesInput>
    connectOrCreate?: DomainCreateOrConnectWithoutWebsitesInput
    connect?: DomainWhereUniqueInput
  }

  export type HostingCreateNestedOneWithoutWebsitesInput = {
    create?: XOR<HostingCreateWithoutWebsitesInput, HostingUncheckedCreateWithoutWebsitesInput>
    connectOrCreate?: HostingCreateOrConnectWithoutWebsitesInput
    connect?: HostingWhereUniqueInput
  }

  export type VPSCreateNestedOneWithoutWebsitesInput = {
    create?: XOR<VPSCreateWithoutWebsitesInput, VPSUncheckedCreateWithoutWebsitesInput>
    connectOrCreate?: VPSCreateOrConnectWithoutWebsitesInput
    connect?: VPSWhereUniqueInput
  }

  export type ActivityLogUncheckedCreateNestedManyWithoutWebsiteInput = {
    create?: XOR<ActivityLogCreateWithoutWebsiteInput, ActivityLogUncheckedCreateWithoutWebsiteInput> | ActivityLogCreateWithoutWebsiteInput[] | ActivityLogUncheckedCreateWithoutWebsiteInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutWebsiteInput | ActivityLogCreateOrConnectWithoutWebsiteInput[]
    createMany?: ActivityLogCreateManyWebsiteInputEnvelope
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
  }

  export type EnumWebsiteStatusFieldUpdateOperationsInput = {
    set?: $Enums.WebsiteStatus
  }

  export type EnumSSLStatusFieldUpdateOperationsInput = {
    set?: $Enums.SSLStatus
  }

  export type ActivityLogUpdateManyWithoutWebsiteNestedInput = {
    create?: XOR<ActivityLogCreateWithoutWebsiteInput, ActivityLogUncheckedCreateWithoutWebsiteInput> | ActivityLogCreateWithoutWebsiteInput[] | ActivityLogUncheckedCreateWithoutWebsiteInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutWebsiteInput | ActivityLogCreateOrConnectWithoutWebsiteInput[]
    upsert?: ActivityLogUpsertWithWhereUniqueWithoutWebsiteInput | ActivityLogUpsertWithWhereUniqueWithoutWebsiteInput[]
    createMany?: ActivityLogCreateManyWebsiteInputEnvelope
    set?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    disconnect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    delete?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    update?: ActivityLogUpdateWithWhereUniqueWithoutWebsiteInput | ActivityLogUpdateWithWhereUniqueWithoutWebsiteInput[]
    updateMany?: ActivityLogUpdateManyWithWhereWithoutWebsiteInput | ActivityLogUpdateManyWithWhereWithoutWebsiteInput[]
    deleteMany?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
  }

  export type UserUpdateOneRequiredWithoutWebsitesNestedInput = {
    create?: XOR<UserCreateWithoutWebsitesInput, UserUncheckedCreateWithoutWebsitesInput>
    connectOrCreate?: UserCreateOrConnectWithoutWebsitesInput
    upsert?: UserUpsertWithoutWebsitesInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutWebsitesInput, UserUpdateWithoutWebsitesInput>, UserUncheckedUpdateWithoutWebsitesInput>
  }

  export type DomainUpdateOneWithoutWebsitesNestedInput = {
    create?: XOR<DomainCreateWithoutWebsitesInput, DomainUncheckedCreateWithoutWebsitesInput>
    connectOrCreate?: DomainCreateOrConnectWithoutWebsitesInput
    upsert?: DomainUpsertWithoutWebsitesInput
    disconnect?: DomainWhereInput | boolean
    delete?: DomainWhereInput | boolean
    connect?: DomainWhereUniqueInput
    update?: XOR<XOR<DomainUpdateToOneWithWhereWithoutWebsitesInput, DomainUpdateWithoutWebsitesInput>, DomainUncheckedUpdateWithoutWebsitesInput>
  }

  export type HostingUpdateOneWithoutWebsitesNestedInput = {
    create?: XOR<HostingCreateWithoutWebsitesInput, HostingUncheckedCreateWithoutWebsitesInput>
    connectOrCreate?: HostingCreateOrConnectWithoutWebsitesInput
    upsert?: HostingUpsertWithoutWebsitesInput
    disconnect?: HostingWhereInput | boolean
    delete?: HostingWhereInput | boolean
    connect?: HostingWhereUniqueInput
    update?: XOR<XOR<HostingUpdateToOneWithWhereWithoutWebsitesInput, HostingUpdateWithoutWebsitesInput>, HostingUncheckedUpdateWithoutWebsitesInput>
  }

  export type VPSUpdateOneWithoutWebsitesNestedInput = {
    create?: XOR<VPSCreateWithoutWebsitesInput, VPSUncheckedCreateWithoutWebsitesInput>
    connectOrCreate?: VPSCreateOrConnectWithoutWebsitesInput
    upsert?: VPSUpsertWithoutWebsitesInput
    disconnect?: VPSWhereInput | boolean
    delete?: VPSWhereInput | boolean
    connect?: VPSWhereUniqueInput
    update?: XOR<XOR<VPSUpdateToOneWithWhereWithoutWebsitesInput, VPSUpdateWithoutWebsitesInput>, VPSUncheckedUpdateWithoutWebsitesInput>
  }

  export type ActivityLogUncheckedUpdateManyWithoutWebsiteNestedInput = {
    create?: XOR<ActivityLogCreateWithoutWebsiteInput, ActivityLogUncheckedCreateWithoutWebsiteInput> | ActivityLogCreateWithoutWebsiteInput[] | ActivityLogUncheckedCreateWithoutWebsiteInput[]
    connectOrCreate?: ActivityLogCreateOrConnectWithoutWebsiteInput | ActivityLogCreateOrConnectWithoutWebsiteInput[]
    upsert?: ActivityLogUpsertWithWhereUniqueWithoutWebsiteInput | ActivityLogUpsertWithWhereUniqueWithoutWebsiteInput[]
    createMany?: ActivityLogCreateManyWebsiteInputEnvelope
    set?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    disconnect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    delete?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    connect?: ActivityLogWhereUniqueInput | ActivityLogWhereUniqueInput[]
    update?: ActivityLogUpdateWithWhereUniqueWithoutWebsiteInput | ActivityLogUpdateWithWhereUniqueWithoutWebsiteInput[]
    updateMany?: ActivityLogUpdateManyWithWhereWithoutWebsiteInput | ActivityLogUpdateManyWithWhereWithoutWebsiteInput[]
    deleteMany?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
  }

  export type DomainCreateNestedOneWithoutActivitiesInput = {
    create?: XOR<DomainCreateWithoutActivitiesInput, DomainUncheckedCreateWithoutActivitiesInput>
    connectOrCreate?: DomainCreateOrConnectWithoutActivitiesInput
    connect?: DomainWhereUniqueInput
  }

  export type HostingCreateNestedOneWithoutActivitiesInput = {
    create?: XOR<HostingCreateWithoutActivitiesInput, HostingUncheckedCreateWithoutActivitiesInput>
    connectOrCreate?: HostingCreateOrConnectWithoutActivitiesInput
    connect?: HostingWhereUniqueInput
  }

  export type UserCreateNestedOneWithoutActivitiesInput = {
    create?: XOR<UserCreateWithoutActivitiesInput, UserUncheckedCreateWithoutActivitiesInput>
    connectOrCreate?: UserCreateOrConnectWithoutActivitiesInput
    connect?: UserWhereUniqueInput
  }

  export type VPSCreateNestedOneWithoutActivitiesInput = {
    create?: XOR<VPSCreateWithoutActivitiesInput, VPSUncheckedCreateWithoutActivitiesInput>
    connectOrCreate?: VPSCreateOrConnectWithoutActivitiesInput
    connect?: VPSWhereUniqueInput
  }

  export type WebsiteCreateNestedOneWithoutActivitiesInput = {
    create?: XOR<WebsiteCreateWithoutActivitiesInput, WebsiteUncheckedCreateWithoutActivitiesInput>
    connectOrCreate?: WebsiteCreateOrConnectWithoutActivitiesInput
    connect?: WebsiteWhereUniqueInput
  }

  export type EnumActivityTypeFieldUpdateOperationsInput = {
    set?: $Enums.ActivityType
  }

  export type EnumEntityTypeFieldUpdateOperationsInput = {
    set?: $Enums.EntityType
  }

  export type DomainUpdateOneWithoutActivitiesNestedInput = {
    create?: XOR<DomainCreateWithoutActivitiesInput, DomainUncheckedCreateWithoutActivitiesInput>
    connectOrCreate?: DomainCreateOrConnectWithoutActivitiesInput
    upsert?: DomainUpsertWithoutActivitiesInput
    disconnect?: DomainWhereInput | boolean
    delete?: DomainWhereInput | boolean
    connect?: DomainWhereUniqueInput
    update?: XOR<XOR<DomainUpdateToOneWithWhereWithoutActivitiesInput, DomainUpdateWithoutActivitiesInput>, DomainUncheckedUpdateWithoutActivitiesInput>
  }

  export type HostingUpdateOneWithoutActivitiesNestedInput = {
    create?: XOR<HostingCreateWithoutActivitiesInput, HostingUncheckedCreateWithoutActivitiesInput>
    connectOrCreate?: HostingCreateOrConnectWithoutActivitiesInput
    upsert?: HostingUpsertWithoutActivitiesInput
    disconnect?: HostingWhereInput | boolean
    delete?: HostingWhereInput | boolean
    connect?: HostingWhereUniqueInput
    update?: XOR<XOR<HostingUpdateToOneWithWhereWithoutActivitiesInput, HostingUpdateWithoutActivitiesInput>, HostingUncheckedUpdateWithoutActivitiesInput>
  }

  export type UserUpdateOneRequiredWithoutActivitiesNestedInput = {
    create?: XOR<UserCreateWithoutActivitiesInput, UserUncheckedCreateWithoutActivitiesInput>
    connectOrCreate?: UserCreateOrConnectWithoutActivitiesInput
    upsert?: UserUpsertWithoutActivitiesInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutActivitiesInput, UserUpdateWithoutActivitiesInput>, UserUncheckedUpdateWithoutActivitiesInput>
  }

  export type VPSUpdateOneWithoutActivitiesNestedInput = {
    create?: XOR<VPSCreateWithoutActivitiesInput, VPSUncheckedCreateWithoutActivitiesInput>
    connectOrCreate?: VPSCreateOrConnectWithoutActivitiesInput
    upsert?: VPSUpsertWithoutActivitiesInput
    disconnect?: VPSWhereInput | boolean
    delete?: VPSWhereInput | boolean
    connect?: VPSWhereUniqueInput
    update?: XOR<XOR<VPSUpdateToOneWithWhereWithoutActivitiesInput, VPSUpdateWithoutActivitiesInput>, VPSUncheckedUpdateWithoutActivitiesInput>
  }

  export type WebsiteUpdateOneWithoutActivitiesNestedInput = {
    create?: XOR<WebsiteCreateWithoutActivitiesInput, WebsiteUncheckedCreateWithoutActivitiesInput>
    connectOrCreate?: WebsiteCreateOrConnectWithoutActivitiesInput
    upsert?: WebsiteUpsertWithoutActivitiesInput
    disconnect?: WebsiteWhereInput | boolean
    delete?: WebsiteWhereInput | boolean
    connect?: WebsiteWhereUniqueInput
    update?: XOR<XOR<WebsiteUpdateToOneWithWhereWithoutActivitiesInput, WebsiteUpdateWithoutActivitiesInput>, WebsiteUncheckedUpdateWithoutActivitiesInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedEnumUserRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.UserRole | EnumUserRoleFieldRefInput<$PrismaModel>
    in?: $Enums.UserRole[]
    notIn?: $Enums.UserRole[]
    not?: NestedEnumUserRoleFilter<$PrismaModel> | $Enums.UserRole
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumUserRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.UserRole | EnumUserRoleFieldRefInput<$PrismaModel>
    in?: $Enums.UserRole[]
    notIn?: $Enums.UserRole[]
    not?: NestedEnumUserRoleWithAggregatesFilter<$PrismaModel> | $Enums.UserRole
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumUserRoleFilter<$PrismaModel>
    _max?: NestedEnumUserRoleFilter<$PrismaModel>
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedEnumDomainStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.DomainStatus | EnumDomainStatusFieldRefInput<$PrismaModel>
    in?: $Enums.DomainStatus[]
    notIn?: $Enums.DomainStatus[]
    not?: NestedEnumDomainStatusFilter<$PrismaModel> | $Enums.DomainStatus
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedEnumDomainStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.DomainStatus | EnumDomainStatusFieldRefInput<$PrismaModel>
    in?: $Enums.DomainStatus[]
    notIn?: $Enums.DomainStatus[]
    not?: NestedEnumDomainStatusWithAggregatesFilter<$PrismaModel> | $Enums.DomainStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumDomainStatusFilter<$PrismaModel>
    _max?: NestedEnumDomainStatusFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }
  export type NestedJsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<NestedJsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type NestedEnumHostingStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.HostingStatus | EnumHostingStatusFieldRefInput<$PrismaModel>
    in?: $Enums.HostingStatus[]
    notIn?: $Enums.HostingStatus[]
    not?: NestedEnumHostingStatusFilter<$PrismaModel> | $Enums.HostingStatus
  }

  export type NestedEnumHostingStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.HostingStatus | EnumHostingStatusFieldRefInput<$PrismaModel>
    in?: $Enums.HostingStatus[]
    notIn?: $Enums.HostingStatus[]
    not?: NestedEnumHostingStatusWithAggregatesFilter<$PrismaModel> | $Enums.HostingStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumHostingStatusFilter<$PrismaModel>
    _max?: NestedEnumHostingStatusFilter<$PrismaModel>
  }

  export type NestedEnumVPSStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.VPSStatus | EnumVPSStatusFieldRefInput<$PrismaModel>
    in?: $Enums.VPSStatus[]
    notIn?: $Enums.VPSStatus[]
    not?: NestedEnumVPSStatusFilter<$PrismaModel> | $Enums.VPSStatus
  }

  export type NestedEnumVPSStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.VPSStatus | EnumVPSStatusFieldRefInput<$PrismaModel>
    in?: $Enums.VPSStatus[]
    notIn?: $Enums.VPSStatus[]
    not?: NestedEnumVPSStatusWithAggregatesFilter<$PrismaModel> | $Enums.VPSStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumVPSStatusFilter<$PrismaModel>
    _max?: NestedEnumVPSStatusFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumWebsiteStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.WebsiteStatus | EnumWebsiteStatusFieldRefInput<$PrismaModel>
    in?: $Enums.WebsiteStatus[]
    notIn?: $Enums.WebsiteStatus[]
    not?: NestedEnumWebsiteStatusFilter<$PrismaModel> | $Enums.WebsiteStatus
  }

  export type NestedEnumSSLStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.SSLStatus | EnumSSLStatusFieldRefInput<$PrismaModel>
    in?: $Enums.SSLStatus[]
    notIn?: $Enums.SSLStatus[]
    not?: NestedEnumSSLStatusFilter<$PrismaModel> | $Enums.SSLStatus
  }

  export type NestedEnumWebsiteStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.WebsiteStatus | EnumWebsiteStatusFieldRefInput<$PrismaModel>
    in?: $Enums.WebsiteStatus[]
    notIn?: $Enums.WebsiteStatus[]
    not?: NestedEnumWebsiteStatusWithAggregatesFilter<$PrismaModel> | $Enums.WebsiteStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumWebsiteStatusFilter<$PrismaModel>
    _max?: NestedEnumWebsiteStatusFilter<$PrismaModel>
  }

  export type NestedEnumSSLStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.SSLStatus | EnumSSLStatusFieldRefInput<$PrismaModel>
    in?: $Enums.SSLStatus[]
    notIn?: $Enums.SSLStatus[]
    not?: NestedEnumSSLStatusWithAggregatesFilter<$PrismaModel> | $Enums.SSLStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumSSLStatusFilter<$PrismaModel>
    _max?: NestedEnumSSLStatusFilter<$PrismaModel>
  }

  export type NestedEnumActivityTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.ActivityType | EnumActivityTypeFieldRefInput<$PrismaModel>
    in?: $Enums.ActivityType[]
    notIn?: $Enums.ActivityType[]
    not?: NestedEnumActivityTypeFilter<$PrismaModel> | $Enums.ActivityType
  }

  export type NestedEnumEntityTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.EntityType | EnumEntityTypeFieldRefInput<$PrismaModel>
    in?: $Enums.EntityType[]
    notIn?: $Enums.EntityType[]
    not?: NestedEnumEntityTypeFilter<$PrismaModel> | $Enums.EntityType
  }

  export type NestedEnumActivityTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.ActivityType | EnumActivityTypeFieldRefInput<$PrismaModel>
    in?: $Enums.ActivityType[]
    notIn?: $Enums.ActivityType[]
    not?: NestedEnumActivityTypeWithAggregatesFilter<$PrismaModel> | $Enums.ActivityType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumActivityTypeFilter<$PrismaModel>
    _max?: NestedEnumActivityTypeFilter<$PrismaModel>
  }

  export type NestedEnumEntityTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.EntityType | EnumEntityTypeFieldRefInput<$PrismaModel>
    in?: $Enums.EntityType[]
    notIn?: $Enums.EntityType[]
    not?: NestedEnumEntityTypeWithAggregatesFilter<$PrismaModel> | $Enums.EntityType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEntityTypeFilter<$PrismaModel>
    _max?: NestedEnumEntityTypeFilter<$PrismaModel>
  }

  export type ActivityLogCreateWithoutUserInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    domain?: DomainCreateNestedOneWithoutActivitiesInput
    hosting?: HostingCreateNestedOneWithoutActivitiesInput
    vps?: VPSCreateNestedOneWithoutActivitiesInput
    website?: WebsiteCreateNestedOneWithoutActivitiesInput
  }

  export type ActivityLogUncheckedCreateWithoutUserInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    domainId?: string | null
    hostingId?: string | null
    vpsId?: string | null
    websiteId?: string | null
  }

  export type ActivityLogCreateOrConnectWithoutUserInput = {
    where: ActivityLogWhereUniqueInput
    create: XOR<ActivityLogCreateWithoutUserInput, ActivityLogUncheckedCreateWithoutUserInput>
  }

  export type ActivityLogCreateManyUserInputEnvelope = {
    data: ActivityLogCreateManyUserInput | ActivityLogCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type DomainCreateWithoutUserInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    isMainDomain?: boolean
    domainHosting?: string | null
    activities?: ActivityLogCreateNestedManyWithoutDomainInput
    hosting?: HostingCreateNestedOneWithoutDomainsInput
    vps?: VPSCreateNestedOneWithoutDomainsInput
    websites?: WebsiteCreateNestedManyWithoutDomainInput
  }

  export type DomainUncheckedCreateWithoutUserInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    hostingId?: string | null
    vpsId?: string | null
    isMainDomain?: boolean
    domainHosting?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutDomainInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutDomainInput
  }

  export type DomainCreateOrConnectWithoutUserInput = {
    where: DomainWhereUniqueInput
    create: XOR<DomainCreateWithoutUserInput, DomainUncheckedCreateWithoutUserInput>
  }

  export type DomainCreateManyUserInputEnvelope = {
    data: DomainCreateManyUserInput | DomainCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type HostingCreateWithoutUserInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogCreateNestedManyWithoutHostingInput
    domains?: DomainCreateNestedManyWithoutHostingInput
    websites?: WebsiteCreateNestedManyWithoutHostingInput
  }

  export type HostingUncheckedCreateWithoutUserInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogUncheckedCreateNestedManyWithoutHostingInput
    domains?: DomainUncheckedCreateNestedManyWithoutHostingInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutHostingInput
  }

  export type HostingCreateOrConnectWithoutUserInput = {
    where: HostingWhereUniqueInput
    create: XOR<HostingCreateWithoutUserInput, HostingUncheckedCreateWithoutUserInput>
  }

  export type HostingCreateManyUserInputEnvelope = {
    data: HostingCreateManyUserInput | HostingCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type SessionCreateWithoutUserInput = {
    id?: string
    sessionToken: string
    expires: Date | string
    createdAt?: Date | string
  }

  export type SessionUncheckedCreateWithoutUserInput = {
    id?: string
    sessionToken: string
    expires: Date | string
    createdAt?: Date | string
  }

  export type SessionCreateOrConnectWithoutUserInput = {
    where: SessionWhereUniqueInput
    create: XOR<SessionCreateWithoutUserInput, SessionUncheckedCreateWithoutUserInput>
  }

  export type SessionCreateManyUserInputEnvelope = {
    data: SessionCreateManyUserInput | SessionCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type VPSCreateWithoutUserInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    cpanelUrl?: string | null
    activities?: ActivityLogCreateNestedManyWithoutVpsInput
    domains?: DomainCreateNestedManyWithoutVpsInput
    websites?: WebsiteCreateNestedManyWithoutVpsInput
  }

  export type VPSUncheckedCreateWithoutUserInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    cpanelUrl?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutVpsInput
    domains?: DomainUncheckedCreateNestedManyWithoutVpsInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutVpsInput
  }

  export type VPSCreateOrConnectWithoutUserInput = {
    where: VPSWhereUniqueInput
    create: XOR<VPSCreateWithoutUserInput, VPSUncheckedCreateWithoutUserInput>
  }

  export type VPSCreateManyUserInputEnvelope = {
    data: VPSCreateManyUserInput | VPSCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type WebsiteCreateWithoutUserInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    password?: string | null
    username?: string | null
    activities?: ActivityLogCreateNestedManyWithoutWebsiteInput
    domain?: DomainCreateNestedOneWithoutWebsitesInput
    hosting?: HostingCreateNestedOneWithoutWebsitesInput
    vps?: VPSCreateNestedOneWithoutWebsitesInput
  }

  export type WebsiteUncheckedCreateWithoutUserInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    domainId?: string | null
    hostingId?: string | null
    vpsId?: string | null
    password?: string | null
    username?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutWebsiteInput
  }

  export type WebsiteCreateOrConnectWithoutUserInput = {
    where: WebsiteWhereUniqueInput
    create: XOR<WebsiteCreateWithoutUserInput, WebsiteUncheckedCreateWithoutUserInput>
  }

  export type WebsiteCreateManyUserInputEnvelope = {
    data: WebsiteCreateManyUserInput | WebsiteCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type ActivityLogUpsertWithWhereUniqueWithoutUserInput = {
    where: ActivityLogWhereUniqueInput
    update: XOR<ActivityLogUpdateWithoutUserInput, ActivityLogUncheckedUpdateWithoutUserInput>
    create: XOR<ActivityLogCreateWithoutUserInput, ActivityLogUncheckedCreateWithoutUserInput>
  }

  export type ActivityLogUpdateWithWhereUniqueWithoutUserInput = {
    where: ActivityLogWhereUniqueInput
    data: XOR<ActivityLogUpdateWithoutUserInput, ActivityLogUncheckedUpdateWithoutUserInput>
  }

  export type ActivityLogUpdateManyWithWhereWithoutUserInput = {
    where: ActivityLogScalarWhereInput
    data: XOR<ActivityLogUpdateManyMutationInput, ActivityLogUncheckedUpdateManyWithoutUserInput>
  }

  export type ActivityLogScalarWhereInput = {
    AND?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
    OR?: ActivityLogScalarWhereInput[]
    NOT?: ActivityLogScalarWhereInput | ActivityLogScalarWhereInput[]
    id?: StringFilter<"ActivityLog"> | string
    action?: EnumActivityTypeFilter<"ActivityLog"> | $Enums.ActivityType
    entity?: EnumEntityTypeFilter<"ActivityLog"> | $Enums.EntityType
    entityId?: StringFilter<"ActivityLog"> | string
    description?: StringFilter<"ActivityLog"> | string
    metadata?: JsonNullableFilter<"ActivityLog">
    ipAddress?: StringNullableFilter<"ActivityLog"> | string | null
    userAgent?: StringNullableFilter<"ActivityLog"> | string | null
    createdAt?: DateTimeFilter<"ActivityLog"> | Date | string
    userId?: StringFilter<"ActivityLog"> | string
    domainId?: StringNullableFilter<"ActivityLog"> | string | null
    hostingId?: StringNullableFilter<"ActivityLog"> | string | null
    vpsId?: StringNullableFilter<"ActivityLog"> | string | null
    websiteId?: StringNullableFilter<"ActivityLog"> | string | null
  }

  export type DomainUpsertWithWhereUniqueWithoutUserInput = {
    where: DomainWhereUniqueInput
    update: XOR<DomainUpdateWithoutUserInput, DomainUncheckedUpdateWithoutUserInput>
    create: XOR<DomainCreateWithoutUserInput, DomainUncheckedCreateWithoutUserInput>
  }

  export type DomainUpdateWithWhereUniqueWithoutUserInput = {
    where: DomainWhereUniqueInput
    data: XOR<DomainUpdateWithoutUserInput, DomainUncheckedUpdateWithoutUserInput>
  }

  export type DomainUpdateManyWithWhereWithoutUserInput = {
    where: DomainScalarWhereInput
    data: XOR<DomainUpdateManyMutationInput, DomainUncheckedUpdateManyWithoutUserInput>
  }

  export type DomainScalarWhereInput = {
    AND?: DomainScalarWhereInput | DomainScalarWhereInput[]
    OR?: DomainScalarWhereInput[]
    NOT?: DomainScalarWhereInput | DomainScalarWhereInput[]
    id?: StringFilter<"Domain"> | string
    name?: StringFilter<"Domain"> | string
    registrar?: StringNullableFilter<"Domain"> | string | null
    status?: EnumDomainStatusFilter<"Domain"> | $Enums.DomainStatus
    registeredAt?: DateTimeNullableFilter<"Domain"> | Date | string | null
    expiresAt?: DateTimeNullableFilter<"Domain"> | Date | string | null
    nameservers?: JsonNullableFilter<"Domain">
    whoisData?: JsonNullableFilter<"Domain">
    notes?: StringNullableFilter<"Domain"> | string | null
    createdAt?: DateTimeFilter<"Domain"> | Date | string
    updatedAt?: DateTimeFilter<"Domain"> | Date | string
    createdBy?: StringFilter<"Domain"> | string
    hostingId?: StringNullableFilter<"Domain"> | string | null
    vpsId?: StringNullableFilter<"Domain"> | string | null
    isMainDomain?: BoolFilter<"Domain"> | boolean
    domainHosting?: StringNullableFilter<"Domain"> | string | null
  }

  export type HostingUpsertWithWhereUniqueWithoutUserInput = {
    where: HostingWhereUniqueInput
    update: XOR<HostingUpdateWithoutUserInput, HostingUncheckedUpdateWithoutUserInput>
    create: XOR<HostingCreateWithoutUserInput, HostingUncheckedCreateWithoutUserInput>
  }

  export type HostingUpdateWithWhereUniqueWithoutUserInput = {
    where: HostingWhereUniqueInput
    data: XOR<HostingUpdateWithoutUserInput, HostingUncheckedUpdateWithoutUserInput>
  }

  export type HostingUpdateManyWithWhereWithoutUserInput = {
    where: HostingScalarWhereInput
    data: XOR<HostingUpdateManyMutationInput, HostingUncheckedUpdateManyWithoutUserInput>
  }

  export type HostingScalarWhereInput = {
    AND?: HostingScalarWhereInput | HostingScalarWhereInput[]
    OR?: HostingScalarWhereInput[]
    NOT?: HostingScalarWhereInput | HostingScalarWhereInput[]
    id?: StringFilter<"Hosting"> | string
    name?: StringFilter<"Hosting"> | string
    provider?: StringFilter<"Hosting"> | string
    status?: EnumHostingStatusFilter<"Hosting"> | $Enums.HostingStatus
    planName?: StringNullableFilter<"Hosting"> | string | null
    resources?: JsonNullableFilter<"Hosting">
    cpanelUrl?: StringNullableFilter<"Hosting"> | string | null
    username?: StringNullableFilter<"Hosting"> | string | null
    password?: StringNullableFilter<"Hosting"> | string | null
    expiresAt?: DateTimeNullableFilter<"Hosting"> | Date | string | null
    notes?: StringNullableFilter<"Hosting"> | string | null
    createdAt?: DateTimeFilter<"Hosting"> | Date | string
    updatedAt?: DateTimeFilter<"Hosting"> | Date | string
    createdBy?: StringFilter<"Hosting"> | string
  }

  export type SessionUpsertWithWhereUniqueWithoutUserInput = {
    where: SessionWhereUniqueInput
    update: XOR<SessionUpdateWithoutUserInput, SessionUncheckedUpdateWithoutUserInput>
    create: XOR<SessionCreateWithoutUserInput, SessionUncheckedCreateWithoutUserInput>
  }

  export type SessionUpdateWithWhereUniqueWithoutUserInput = {
    where: SessionWhereUniqueInput
    data: XOR<SessionUpdateWithoutUserInput, SessionUncheckedUpdateWithoutUserInput>
  }

  export type SessionUpdateManyWithWhereWithoutUserInput = {
    where: SessionScalarWhereInput
    data: XOR<SessionUpdateManyMutationInput, SessionUncheckedUpdateManyWithoutUserInput>
  }

  export type SessionScalarWhereInput = {
    AND?: SessionScalarWhereInput | SessionScalarWhereInput[]
    OR?: SessionScalarWhereInput[]
    NOT?: SessionScalarWhereInput | SessionScalarWhereInput[]
    id?: StringFilter<"Session"> | string
    sessionToken?: StringFilter<"Session"> | string
    userId?: StringFilter<"Session"> | string
    expires?: DateTimeFilter<"Session"> | Date | string
    createdAt?: DateTimeFilter<"Session"> | Date | string
  }

  export type VPSUpsertWithWhereUniqueWithoutUserInput = {
    where: VPSWhereUniqueInput
    update: XOR<VPSUpdateWithoutUserInput, VPSUncheckedUpdateWithoutUserInput>
    create: XOR<VPSCreateWithoutUserInput, VPSUncheckedCreateWithoutUserInput>
  }

  export type VPSUpdateWithWhereUniqueWithoutUserInput = {
    where: VPSWhereUniqueInput
    data: XOR<VPSUpdateWithoutUserInput, VPSUncheckedUpdateWithoutUserInput>
  }

  export type VPSUpdateManyWithWhereWithoutUserInput = {
    where: VPSScalarWhereInput
    data: XOR<VPSUpdateManyMutationInput, VPSUncheckedUpdateManyWithoutUserInput>
  }

  export type VPSScalarWhereInput = {
    AND?: VPSScalarWhereInput | VPSScalarWhereInput[]
    OR?: VPSScalarWhereInput[]
    NOT?: VPSScalarWhereInput | VPSScalarWhereInput[]
    id?: StringFilter<"VPS"> | string
    name?: StringFilter<"VPS"> | string
    provider?: StringFilter<"VPS"> | string
    status?: EnumVPSStatusFilter<"VPS"> | $Enums.VPSStatus
    ipAddress?: StringNullableFilter<"VPS"> | string | null
    specs?: JsonNullableFilter<"VPS">
    sshPort?: IntNullableFilter<"VPS"> | number | null
    sshKey?: StringNullableFilter<"VPS"> | string | null
    username?: StringNullableFilter<"VPS"> | string | null
    password?: StringNullableFilter<"VPS"> | string | null
    expiresAt?: DateTimeNullableFilter<"VPS"> | Date | string | null
    notes?: StringNullableFilter<"VPS"> | string | null
    createdAt?: DateTimeFilter<"VPS"> | Date | string
    updatedAt?: DateTimeFilter<"VPS"> | Date | string
    createdBy?: StringFilter<"VPS"> | string
    cpanelUrl?: StringNullableFilter<"VPS"> | string | null
  }

  export type WebsiteUpsertWithWhereUniqueWithoutUserInput = {
    where: WebsiteWhereUniqueInput
    update: XOR<WebsiteUpdateWithoutUserInput, WebsiteUncheckedUpdateWithoutUserInput>
    create: XOR<WebsiteCreateWithoutUserInput, WebsiteUncheckedCreateWithoutUserInput>
  }

  export type WebsiteUpdateWithWhereUniqueWithoutUserInput = {
    where: WebsiteWhereUniqueInput
    data: XOR<WebsiteUpdateWithoutUserInput, WebsiteUncheckedUpdateWithoutUserInput>
  }

  export type WebsiteUpdateManyWithWhereWithoutUserInput = {
    where: WebsiteScalarWhereInput
    data: XOR<WebsiteUpdateManyMutationInput, WebsiteUncheckedUpdateManyWithoutUserInput>
  }

  export type WebsiteScalarWhereInput = {
    AND?: WebsiteScalarWhereInput | WebsiteScalarWhereInput[]
    OR?: WebsiteScalarWhereInput[]
    NOT?: WebsiteScalarWhereInput | WebsiteScalarWhereInput[]
    id?: StringFilter<"Website"> | string
    name?: StringFilter<"Website"> | string
    url?: StringNullableFilter<"Website"> | string | null
    status?: EnumWebsiteStatusFilter<"Website"> | $Enums.WebsiteStatus
    cms?: StringNullableFilter<"Website"> | string | null
    cmsVersion?: StringNullableFilter<"Website"> | string | null
    phpVersion?: StringNullableFilter<"Website"> | string | null
    sslStatus?: EnumSSLStatusFilter<"Website"> | $Enums.SSLStatus
    sslExpiry?: DateTimeNullableFilter<"Website"> | Date | string | null
    backupStatus?: StringNullableFilter<"Website"> | string | null
    lastBackup?: DateTimeNullableFilter<"Website"> | Date | string | null
    notes?: StringNullableFilter<"Website"> | string | null
    createdAt?: DateTimeFilter<"Website"> | Date | string
    updatedAt?: DateTimeFilter<"Website"> | Date | string
    createdBy?: StringFilter<"Website"> | string
    domainId?: StringNullableFilter<"Website"> | string | null
    hostingId?: StringNullableFilter<"Website"> | string | null
    vpsId?: StringNullableFilter<"Website"> | string | null
    password?: StringNullableFilter<"Website"> | string | null
    username?: StringNullableFilter<"Website"> | string | null
  }

  export type UserCreateWithoutSessionsInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogCreateNestedManyWithoutUserInput
    domains?: DomainCreateNestedManyWithoutUserInput
    hosting?: HostingCreateNestedManyWithoutUserInput
    vps?: VPSCreateNestedManyWithoutUserInput
    websites?: WebsiteCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutSessionsInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogUncheckedCreateNestedManyWithoutUserInput
    domains?: DomainUncheckedCreateNestedManyWithoutUserInput
    hosting?: HostingUncheckedCreateNestedManyWithoutUserInput
    vps?: VPSUncheckedCreateNestedManyWithoutUserInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutSessionsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutSessionsInput, UserUncheckedCreateWithoutSessionsInput>
  }

  export type UserUpsertWithoutSessionsInput = {
    update: XOR<UserUpdateWithoutSessionsInput, UserUncheckedUpdateWithoutSessionsInput>
    create: XOR<UserCreateWithoutSessionsInput, UserUncheckedCreateWithoutSessionsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutSessionsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutSessionsInput, UserUncheckedUpdateWithoutSessionsInput>
  }

  export type UserUpdateWithoutSessionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUpdateManyWithoutUserNestedInput
    domains?: DomainUpdateManyWithoutUserNestedInput
    hosting?: HostingUpdateManyWithoutUserNestedInput
    vps?: VPSUpdateManyWithoutUserNestedInput
    websites?: WebsiteUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutSessionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUncheckedUpdateManyWithoutUserNestedInput
    domains?: DomainUncheckedUpdateManyWithoutUserNestedInput
    hosting?: HostingUncheckedUpdateManyWithoutUserNestedInput
    vps?: VPSUncheckedUpdateManyWithoutUserNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutUserNestedInput
  }

  export type ActivityLogCreateWithoutDomainInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    hosting?: HostingCreateNestedOneWithoutActivitiesInput
    user: UserCreateNestedOneWithoutActivitiesInput
    vps?: VPSCreateNestedOneWithoutActivitiesInput
    website?: WebsiteCreateNestedOneWithoutActivitiesInput
  }

  export type ActivityLogUncheckedCreateWithoutDomainInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    userId: string
    hostingId?: string | null
    vpsId?: string | null
    websiteId?: string | null
  }

  export type ActivityLogCreateOrConnectWithoutDomainInput = {
    where: ActivityLogWhereUniqueInput
    create: XOR<ActivityLogCreateWithoutDomainInput, ActivityLogUncheckedCreateWithoutDomainInput>
  }

  export type ActivityLogCreateManyDomainInputEnvelope = {
    data: ActivityLogCreateManyDomainInput | ActivityLogCreateManyDomainInput[]
    skipDuplicates?: boolean
  }

  export type UserCreateWithoutDomainsInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogCreateNestedManyWithoutUserInput
    hosting?: HostingCreateNestedManyWithoutUserInput
    sessions?: SessionCreateNestedManyWithoutUserInput
    vps?: VPSCreateNestedManyWithoutUserInput
    websites?: WebsiteCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutDomainsInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogUncheckedCreateNestedManyWithoutUserInput
    hosting?: HostingUncheckedCreateNestedManyWithoutUserInput
    sessions?: SessionUncheckedCreateNestedManyWithoutUserInput
    vps?: VPSUncheckedCreateNestedManyWithoutUserInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutDomainsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutDomainsInput, UserUncheckedCreateWithoutDomainsInput>
  }

  export type HostingCreateWithoutDomainsInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogCreateNestedManyWithoutHostingInput
    user: UserCreateNestedOneWithoutHostingInput
    websites?: WebsiteCreateNestedManyWithoutHostingInput
  }

  export type HostingUncheckedCreateWithoutDomainsInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    activities?: ActivityLogUncheckedCreateNestedManyWithoutHostingInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutHostingInput
  }

  export type HostingCreateOrConnectWithoutDomainsInput = {
    where: HostingWhereUniqueInput
    create: XOR<HostingCreateWithoutDomainsInput, HostingUncheckedCreateWithoutDomainsInput>
  }

  export type VPSCreateWithoutDomainsInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    cpanelUrl?: string | null
    activities?: ActivityLogCreateNestedManyWithoutVpsInput
    user: UserCreateNestedOneWithoutVpsInput
    websites?: WebsiteCreateNestedManyWithoutVpsInput
  }

  export type VPSUncheckedCreateWithoutDomainsInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    cpanelUrl?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutVpsInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutVpsInput
  }

  export type VPSCreateOrConnectWithoutDomainsInput = {
    where: VPSWhereUniqueInput
    create: XOR<VPSCreateWithoutDomainsInput, VPSUncheckedCreateWithoutDomainsInput>
  }

  export type WebsiteCreateWithoutDomainInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    password?: string | null
    username?: string | null
    activities?: ActivityLogCreateNestedManyWithoutWebsiteInput
    user: UserCreateNestedOneWithoutWebsitesInput
    hosting?: HostingCreateNestedOneWithoutWebsitesInput
    vps?: VPSCreateNestedOneWithoutWebsitesInput
  }

  export type WebsiteUncheckedCreateWithoutDomainInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    hostingId?: string | null
    vpsId?: string | null
    password?: string | null
    username?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutWebsiteInput
  }

  export type WebsiteCreateOrConnectWithoutDomainInput = {
    where: WebsiteWhereUniqueInput
    create: XOR<WebsiteCreateWithoutDomainInput, WebsiteUncheckedCreateWithoutDomainInput>
  }

  export type WebsiteCreateManyDomainInputEnvelope = {
    data: WebsiteCreateManyDomainInput | WebsiteCreateManyDomainInput[]
    skipDuplicates?: boolean
  }

  export type ActivityLogUpsertWithWhereUniqueWithoutDomainInput = {
    where: ActivityLogWhereUniqueInput
    update: XOR<ActivityLogUpdateWithoutDomainInput, ActivityLogUncheckedUpdateWithoutDomainInput>
    create: XOR<ActivityLogCreateWithoutDomainInput, ActivityLogUncheckedCreateWithoutDomainInput>
  }

  export type ActivityLogUpdateWithWhereUniqueWithoutDomainInput = {
    where: ActivityLogWhereUniqueInput
    data: XOR<ActivityLogUpdateWithoutDomainInput, ActivityLogUncheckedUpdateWithoutDomainInput>
  }

  export type ActivityLogUpdateManyWithWhereWithoutDomainInput = {
    where: ActivityLogScalarWhereInput
    data: XOR<ActivityLogUpdateManyMutationInput, ActivityLogUncheckedUpdateManyWithoutDomainInput>
  }

  export type UserUpsertWithoutDomainsInput = {
    update: XOR<UserUpdateWithoutDomainsInput, UserUncheckedUpdateWithoutDomainsInput>
    create: XOR<UserCreateWithoutDomainsInput, UserUncheckedCreateWithoutDomainsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutDomainsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutDomainsInput, UserUncheckedUpdateWithoutDomainsInput>
  }

  export type UserUpdateWithoutDomainsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUpdateManyWithoutUserNestedInput
    hosting?: HostingUpdateManyWithoutUserNestedInput
    sessions?: SessionUpdateManyWithoutUserNestedInput
    vps?: VPSUpdateManyWithoutUserNestedInput
    websites?: WebsiteUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutDomainsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUncheckedUpdateManyWithoutUserNestedInput
    hosting?: HostingUncheckedUpdateManyWithoutUserNestedInput
    sessions?: SessionUncheckedUpdateManyWithoutUserNestedInput
    vps?: VPSUncheckedUpdateManyWithoutUserNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutUserNestedInput
  }

  export type HostingUpsertWithoutDomainsInput = {
    update: XOR<HostingUpdateWithoutDomainsInput, HostingUncheckedUpdateWithoutDomainsInput>
    create: XOR<HostingCreateWithoutDomainsInput, HostingUncheckedCreateWithoutDomainsInput>
    where?: HostingWhereInput
  }

  export type HostingUpdateToOneWithWhereWithoutDomainsInput = {
    where?: HostingWhereInput
    data: XOR<HostingUpdateWithoutDomainsInput, HostingUncheckedUpdateWithoutDomainsInput>
  }

  export type HostingUpdateWithoutDomainsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUpdateManyWithoutHostingNestedInput
    user?: UserUpdateOneRequiredWithoutHostingNestedInput
    websites?: WebsiteUpdateManyWithoutHostingNestedInput
  }

  export type HostingUncheckedUpdateWithoutDomainsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    activities?: ActivityLogUncheckedUpdateManyWithoutHostingNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutHostingNestedInput
  }

  export type VPSUpsertWithoutDomainsInput = {
    update: XOR<VPSUpdateWithoutDomainsInput, VPSUncheckedUpdateWithoutDomainsInput>
    create: XOR<VPSCreateWithoutDomainsInput, VPSUncheckedCreateWithoutDomainsInput>
    where?: VPSWhereInput
  }

  export type VPSUpdateToOneWithWhereWithoutDomainsInput = {
    where?: VPSWhereInput
    data: XOR<VPSUpdateWithoutDomainsInput, VPSUncheckedUpdateWithoutDomainsInput>
  }

  export type VPSUpdateWithoutDomainsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutVpsNestedInput
    user?: UserUpdateOneRequiredWithoutVpsNestedInput
    websites?: WebsiteUpdateManyWithoutVpsNestedInput
  }

  export type VPSUncheckedUpdateWithoutDomainsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutVpsNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutVpsNestedInput
  }

  export type WebsiteUpsertWithWhereUniqueWithoutDomainInput = {
    where: WebsiteWhereUniqueInput
    update: XOR<WebsiteUpdateWithoutDomainInput, WebsiteUncheckedUpdateWithoutDomainInput>
    create: XOR<WebsiteCreateWithoutDomainInput, WebsiteUncheckedCreateWithoutDomainInput>
  }

  export type WebsiteUpdateWithWhereUniqueWithoutDomainInput = {
    where: WebsiteWhereUniqueInput
    data: XOR<WebsiteUpdateWithoutDomainInput, WebsiteUncheckedUpdateWithoutDomainInput>
  }

  export type WebsiteUpdateManyWithWhereWithoutDomainInput = {
    where: WebsiteScalarWhereInput
    data: XOR<WebsiteUpdateManyMutationInput, WebsiteUncheckedUpdateManyWithoutDomainInput>
  }

  export type ActivityLogCreateWithoutHostingInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    domain?: DomainCreateNestedOneWithoutActivitiesInput
    user: UserCreateNestedOneWithoutActivitiesInput
    vps?: VPSCreateNestedOneWithoutActivitiesInput
    website?: WebsiteCreateNestedOneWithoutActivitiesInput
  }

  export type ActivityLogUncheckedCreateWithoutHostingInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    userId: string
    domainId?: string | null
    vpsId?: string | null
    websiteId?: string | null
  }

  export type ActivityLogCreateOrConnectWithoutHostingInput = {
    where: ActivityLogWhereUniqueInput
    create: XOR<ActivityLogCreateWithoutHostingInput, ActivityLogUncheckedCreateWithoutHostingInput>
  }

  export type ActivityLogCreateManyHostingInputEnvelope = {
    data: ActivityLogCreateManyHostingInput | ActivityLogCreateManyHostingInput[]
    skipDuplicates?: boolean
  }

  export type DomainCreateWithoutHostingInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    isMainDomain?: boolean
    domainHosting?: string | null
    activities?: ActivityLogCreateNestedManyWithoutDomainInput
    user: UserCreateNestedOneWithoutDomainsInput
    vps?: VPSCreateNestedOneWithoutDomainsInput
    websites?: WebsiteCreateNestedManyWithoutDomainInput
  }

  export type DomainUncheckedCreateWithoutHostingInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    vpsId?: string | null
    isMainDomain?: boolean
    domainHosting?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutDomainInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutDomainInput
  }

  export type DomainCreateOrConnectWithoutHostingInput = {
    where: DomainWhereUniqueInput
    create: XOR<DomainCreateWithoutHostingInput, DomainUncheckedCreateWithoutHostingInput>
  }

  export type DomainCreateManyHostingInputEnvelope = {
    data: DomainCreateManyHostingInput | DomainCreateManyHostingInput[]
    skipDuplicates?: boolean
  }

  export type UserCreateWithoutHostingInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogCreateNestedManyWithoutUserInput
    domains?: DomainCreateNestedManyWithoutUserInput
    sessions?: SessionCreateNestedManyWithoutUserInput
    vps?: VPSCreateNestedManyWithoutUserInput
    websites?: WebsiteCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutHostingInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogUncheckedCreateNestedManyWithoutUserInput
    domains?: DomainUncheckedCreateNestedManyWithoutUserInput
    sessions?: SessionUncheckedCreateNestedManyWithoutUserInput
    vps?: VPSUncheckedCreateNestedManyWithoutUserInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutHostingInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutHostingInput, UserUncheckedCreateWithoutHostingInput>
  }

  export type WebsiteCreateWithoutHostingInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    password?: string | null
    username?: string | null
    activities?: ActivityLogCreateNestedManyWithoutWebsiteInput
    user: UserCreateNestedOneWithoutWebsitesInput
    domain?: DomainCreateNestedOneWithoutWebsitesInput
    vps?: VPSCreateNestedOneWithoutWebsitesInput
  }

  export type WebsiteUncheckedCreateWithoutHostingInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    domainId?: string | null
    vpsId?: string | null
    password?: string | null
    username?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutWebsiteInput
  }

  export type WebsiteCreateOrConnectWithoutHostingInput = {
    where: WebsiteWhereUniqueInput
    create: XOR<WebsiteCreateWithoutHostingInput, WebsiteUncheckedCreateWithoutHostingInput>
  }

  export type WebsiteCreateManyHostingInputEnvelope = {
    data: WebsiteCreateManyHostingInput | WebsiteCreateManyHostingInput[]
    skipDuplicates?: boolean
  }

  export type ActivityLogUpsertWithWhereUniqueWithoutHostingInput = {
    where: ActivityLogWhereUniqueInput
    update: XOR<ActivityLogUpdateWithoutHostingInput, ActivityLogUncheckedUpdateWithoutHostingInput>
    create: XOR<ActivityLogCreateWithoutHostingInput, ActivityLogUncheckedCreateWithoutHostingInput>
  }

  export type ActivityLogUpdateWithWhereUniqueWithoutHostingInput = {
    where: ActivityLogWhereUniqueInput
    data: XOR<ActivityLogUpdateWithoutHostingInput, ActivityLogUncheckedUpdateWithoutHostingInput>
  }

  export type ActivityLogUpdateManyWithWhereWithoutHostingInput = {
    where: ActivityLogScalarWhereInput
    data: XOR<ActivityLogUpdateManyMutationInput, ActivityLogUncheckedUpdateManyWithoutHostingInput>
  }

  export type DomainUpsertWithWhereUniqueWithoutHostingInput = {
    where: DomainWhereUniqueInput
    update: XOR<DomainUpdateWithoutHostingInput, DomainUncheckedUpdateWithoutHostingInput>
    create: XOR<DomainCreateWithoutHostingInput, DomainUncheckedCreateWithoutHostingInput>
  }

  export type DomainUpdateWithWhereUniqueWithoutHostingInput = {
    where: DomainWhereUniqueInput
    data: XOR<DomainUpdateWithoutHostingInput, DomainUncheckedUpdateWithoutHostingInput>
  }

  export type DomainUpdateManyWithWhereWithoutHostingInput = {
    where: DomainScalarWhereInput
    data: XOR<DomainUpdateManyMutationInput, DomainUncheckedUpdateManyWithoutHostingInput>
  }

  export type UserUpsertWithoutHostingInput = {
    update: XOR<UserUpdateWithoutHostingInput, UserUncheckedUpdateWithoutHostingInput>
    create: XOR<UserCreateWithoutHostingInput, UserUncheckedCreateWithoutHostingInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutHostingInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutHostingInput, UserUncheckedUpdateWithoutHostingInput>
  }

  export type UserUpdateWithoutHostingInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUpdateManyWithoutUserNestedInput
    domains?: DomainUpdateManyWithoutUserNestedInput
    sessions?: SessionUpdateManyWithoutUserNestedInput
    vps?: VPSUpdateManyWithoutUserNestedInput
    websites?: WebsiteUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutHostingInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUncheckedUpdateManyWithoutUserNestedInput
    domains?: DomainUncheckedUpdateManyWithoutUserNestedInput
    sessions?: SessionUncheckedUpdateManyWithoutUserNestedInput
    vps?: VPSUncheckedUpdateManyWithoutUserNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutUserNestedInput
  }

  export type WebsiteUpsertWithWhereUniqueWithoutHostingInput = {
    where: WebsiteWhereUniqueInput
    update: XOR<WebsiteUpdateWithoutHostingInput, WebsiteUncheckedUpdateWithoutHostingInput>
    create: XOR<WebsiteCreateWithoutHostingInput, WebsiteUncheckedCreateWithoutHostingInput>
  }

  export type WebsiteUpdateWithWhereUniqueWithoutHostingInput = {
    where: WebsiteWhereUniqueInput
    data: XOR<WebsiteUpdateWithoutHostingInput, WebsiteUncheckedUpdateWithoutHostingInput>
  }

  export type WebsiteUpdateManyWithWhereWithoutHostingInput = {
    where: WebsiteScalarWhereInput
    data: XOR<WebsiteUpdateManyMutationInput, WebsiteUncheckedUpdateManyWithoutHostingInput>
  }

  export type ActivityLogCreateWithoutVpsInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    domain?: DomainCreateNestedOneWithoutActivitiesInput
    hosting?: HostingCreateNestedOneWithoutActivitiesInput
    user: UserCreateNestedOneWithoutActivitiesInput
    website?: WebsiteCreateNestedOneWithoutActivitiesInput
  }

  export type ActivityLogUncheckedCreateWithoutVpsInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    userId: string
    domainId?: string | null
    hostingId?: string | null
    websiteId?: string | null
  }

  export type ActivityLogCreateOrConnectWithoutVpsInput = {
    where: ActivityLogWhereUniqueInput
    create: XOR<ActivityLogCreateWithoutVpsInput, ActivityLogUncheckedCreateWithoutVpsInput>
  }

  export type ActivityLogCreateManyVpsInputEnvelope = {
    data: ActivityLogCreateManyVpsInput | ActivityLogCreateManyVpsInput[]
    skipDuplicates?: boolean
  }

  export type DomainCreateWithoutVpsInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    isMainDomain?: boolean
    domainHosting?: string | null
    activities?: ActivityLogCreateNestedManyWithoutDomainInput
    user: UserCreateNestedOneWithoutDomainsInput
    hosting?: HostingCreateNestedOneWithoutDomainsInput
    websites?: WebsiteCreateNestedManyWithoutDomainInput
  }

  export type DomainUncheckedCreateWithoutVpsInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    hostingId?: string | null
    isMainDomain?: boolean
    domainHosting?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutDomainInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutDomainInput
  }

  export type DomainCreateOrConnectWithoutVpsInput = {
    where: DomainWhereUniqueInput
    create: XOR<DomainCreateWithoutVpsInput, DomainUncheckedCreateWithoutVpsInput>
  }

  export type DomainCreateManyVpsInputEnvelope = {
    data: DomainCreateManyVpsInput | DomainCreateManyVpsInput[]
    skipDuplicates?: boolean
  }

  export type UserCreateWithoutVpsInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogCreateNestedManyWithoutUserInput
    domains?: DomainCreateNestedManyWithoutUserInput
    hosting?: HostingCreateNestedManyWithoutUserInput
    sessions?: SessionCreateNestedManyWithoutUserInput
    websites?: WebsiteCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutVpsInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogUncheckedCreateNestedManyWithoutUserInput
    domains?: DomainUncheckedCreateNestedManyWithoutUserInput
    hosting?: HostingUncheckedCreateNestedManyWithoutUserInput
    sessions?: SessionUncheckedCreateNestedManyWithoutUserInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutVpsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutVpsInput, UserUncheckedCreateWithoutVpsInput>
  }

  export type WebsiteCreateWithoutVpsInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    password?: string | null
    username?: string | null
    activities?: ActivityLogCreateNestedManyWithoutWebsiteInput
    user: UserCreateNestedOneWithoutWebsitesInput
    domain?: DomainCreateNestedOneWithoutWebsitesInput
    hosting?: HostingCreateNestedOneWithoutWebsitesInput
  }

  export type WebsiteUncheckedCreateWithoutVpsInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    domainId?: string | null
    hostingId?: string | null
    password?: string | null
    username?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutWebsiteInput
  }

  export type WebsiteCreateOrConnectWithoutVpsInput = {
    where: WebsiteWhereUniqueInput
    create: XOR<WebsiteCreateWithoutVpsInput, WebsiteUncheckedCreateWithoutVpsInput>
  }

  export type WebsiteCreateManyVpsInputEnvelope = {
    data: WebsiteCreateManyVpsInput | WebsiteCreateManyVpsInput[]
    skipDuplicates?: boolean
  }

  export type ActivityLogUpsertWithWhereUniqueWithoutVpsInput = {
    where: ActivityLogWhereUniqueInput
    update: XOR<ActivityLogUpdateWithoutVpsInput, ActivityLogUncheckedUpdateWithoutVpsInput>
    create: XOR<ActivityLogCreateWithoutVpsInput, ActivityLogUncheckedCreateWithoutVpsInput>
  }

  export type ActivityLogUpdateWithWhereUniqueWithoutVpsInput = {
    where: ActivityLogWhereUniqueInput
    data: XOR<ActivityLogUpdateWithoutVpsInput, ActivityLogUncheckedUpdateWithoutVpsInput>
  }

  export type ActivityLogUpdateManyWithWhereWithoutVpsInput = {
    where: ActivityLogScalarWhereInput
    data: XOR<ActivityLogUpdateManyMutationInput, ActivityLogUncheckedUpdateManyWithoutVpsInput>
  }

  export type DomainUpsertWithWhereUniqueWithoutVpsInput = {
    where: DomainWhereUniqueInput
    update: XOR<DomainUpdateWithoutVpsInput, DomainUncheckedUpdateWithoutVpsInput>
    create: XOR<DomainCreateWithoutVpsInput, DomainUncheckedCreateWithoutVpsInput>
  }

  export type DomainUpdateWithWhereUniqueWithoutVpsInput = {
    where: DomainWhereUniqueInput
    data: XOR<DomainUpdateWithoutVpsInput, DomainUncheckedUpdateWithoutVpsInput>
  }

  export type DomainUpdateManyWithWhereWithoutVpsInput = {
    where: DomainScalarWhereInput
    data: XOR<DomainUpdateManyMutationInput, DomainUncheckedUpdateManyWithoutVpsInput>
  }

  export type UserUpsertWithoutVpsInput = {
    update: XOR<UserUpdateWithoutVpsInput, UserUncheckedUpdateWithoutVpsInput>
    create: XOR<UserCreateWithoutVpsInput, UserUncheckedCreateWithoutVpsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutVpsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutVpsInput, UserUncheckedUpdateWithoutVpsInput>
  }

  export type UserUpdateWithoutVpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUpdateManyWithoutUserNestedInput
    domains?: DomainUpdateManyWithoutUserNestedInput
    hosting?: HostingUpdateManyWithoutUserNestedInput
    sessions?: SessionUpdateManyWithoutUserNestedInput
    websites?: WebsiteUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutVpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUncheckedUpdateManyWithoutUserNestedInput
    domains?: DomainUncheckedUpdateManyWithoutUserNestedInput
    hosting?: HostingUncheckedUpdateManyWithoutUserNestedInput
    sessions?: SessionUncheckedUpdateManyWithoutUserNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutUserNestedInput
  }

  export type WebsiteUpsertWithWhereUniqueWithoutVpsInput = {
    where: WebsiteWhereUniqueInput
    update: XOR<WebsiteUpdateWithoutVpsInput, WebsiteUncheckedUpdateWithoutVpsInput>
    create: XOR<WebsiteCreateWithoutVpsInput, WebsiteUncheckedCreateWithoutVpsInput>
  }

  export type WebsiteUpdateWithWhereUniqueWithoutVpsInput = {
    where: WebsiteWhereUniqueInput
    data: XOR<WebsiteUpdateWithoutVpsInput, WebsiteUncheckedUpdateWithoutVpsInput>
  }

  export type WebsiteUpdateManyWithWhereWithoutVpsInput = {
    where: WebsiteScalarWhereInput
    data: XOR<WebsiteUpdateManyMutationInput, WebsiteUncheckedUpdateManyWithoutVpsInput>
  }

  export type ActivityLogCreateWithoutWebsiteInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    domain?: DomainCreateNestedOneWithoutActivitiesInput
    hosting?: HostingCreateNestedOneWithoutActivitiesInput
    user: UserCreateNestedOneWithoutActivitiesInput
    vps?: VPSCreateNestedOneWithoutActivitiesInput
  }

  export type ActivityLogUncheckedCreateWithoutWebsiteInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    userId: string
    domainId?: string | null
    hostingId?: string | null
    vpsId?: string | null
  }

  export type ActivityLogCreateOrConnectWithoutWebsiteInput = {
    where: ActivityLogWhereUniqueInput
    create: XOR<ActivityLogCreateWithoutWebsiteInput, ActivityLogUncheckedCreateWithoutWebsiteInput>
  }

  export type ActivityLogCreateManyWebsiteInputEnvelope = {
    data: ActivityLogCreateManyWebsiteInput | ActivityLogCreateManyWebsiteInput[]
    skipDuplicates?: boolean
  }

  export type UserCreateWithoutWebsitesInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogCreateNestedManyWithoutUserInput
    domains?: DomainCreateNestedManyWithoutUserInput
    hosting?: HostingCreateNestedManyWithoutUserInput
    sessions?: SessionCreateNestedManyWithoutUserInput
    vps?: VPSCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutWebsitesInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogUncheckedCreateNestedManyWithoutUserInput
    domains?: DomainUncheckedCreateNestedManyWithoutUserInput
    hosting?: HostingUncheckedCreateNestedManyWithoutUserInput
    sessions?: SessionUncheckedCreateNestedManyWithoutUserInput
    vps?: VPSUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutWebsitesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutWebsitesInput, UserUncheckedCreateWithoutWebsitesInput>
  }

  export type DomainCreateWithoutWebsitesInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    isMainDomain?: boolean
    domainHosting?: string | null
    activities?: ActivityLogCreateNestedManyWithoutDomainInput
    user: UserCreateNestedOneWithoutDomainsInput
    hosting?: HostingCreateNestedOneWithoutDomainsInput
    vps?: VPSCreateNestedOneWithoutDomainsInput
  }

  export type DomainUncheckedCreateWithoutWebsitesInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    hostingId?: string | null
    vpsId?: string | null
    isMainDomain?: boolean
    domainHosting?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutDomainInput
  }

  export type DomainCreateOrConnectWithoutWebsitesInput = {
    where: DomainWhereUniqueInput
    create: XOR<DomainCreateWithoutWebsitesInput, DomainUncheckedCreateWithoutWebsitesInput>
  }

  export type HostingCreateWithoutWebsitesInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    activities?: ActivityLogCreateNestedManyWithoutHostingInput
    domains?: DomainCreateNestedManyWithoutHostingInput
    user: UserCreateNestedOneWithoutHostingInput
  }

  export type HostingUncheckedCreateWithoutWebsitesInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    activities?: ActivityLogUncheckedCreateNestedManyWithoutHostingInput
    domains?: DomainUncheckedCreateNestedManyWithoutHostingInput
  }

  export type HostingCreateOrConnectWithoutWebsitesInput = {
    where: HostingWhereUniqueInput
    create: XOR<HostingCreateWithoutWebsitesInput, HostingUncheckedCreateWithoutWebsitesInput>
  }

  export type VPSCreateWithoutWebsitesInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    cpanelUrl?: string | null
    activities?: ActivityLogCreateNestedManyWithoutVpsInput
    domains?: DomainCreateNestedManyWithoutVpsInput
    user: UserCreateNestedOneWithoutVpsInput
  }

  export type VPSUncheckedCreateWithoutWebsitesInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    cpanelUrl?: string | null
    activities?: ActivityLogUncheckedCreateNestedManyWithoutVpsInput
    domains?: DomainUncheckedCreateNestedManyWithoutVpsInput
  }

  export type VPSCreateOrConnectWithoutWebsitesInput = {
    where: VPSWhereUniqueInput
    create: XOR<VPSCreateWithoutWebsitesInput, VPSUncheckedCreateWithoutWebsitesInput>
  }

  export type ActivityLogUpsertWithWhereUniqueWithoutWebsiteInput = {
    where: ActivityLogWhereUniqueInput
    update: XOR<ActivityLogUpdateWithoutWebsiteInput, ActivityLogUncheckedUpdateWithoutWebsiteInput>
    create: XOR<ActivityLogCreateWithoutWebsiteInput, ActivityLogUncheckedCreateWithoutWebsiteInput>
  }

  export type ActivityLogUpdateWithWhereUniqueWithoutWebsiteInput = {
    where: ActivityLogWhereUniqueInput
    data: XOR<ActivityLogUpdateWithoutWebsiteInput, ActivityLogUncheckedUpdateWithoutWebsiteInput>
  }

  export type ActivityLogUpdateManyWithWhereWithoutWebsiteInput = {
    where: ActivityLogScalarWhereInput
    data: XOR<ActivityLogUpdateManyMutationInput, ActivityLogUncheckedUpdateManyWithoutWebsiteInput>
  }

  export type UserUpsertWithoutWebsitesInput = {
    update: XOR<UserUpdateWithoutWebsitesInput, UserUncheckedUpdateWithoutWebsitesInput>
    create: XOR<UserCreateWithoutWebsitesInput, UserUncheckedCreateWithoutWebsitesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutWebsitesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutWebsitesInput, UserUncheckedUpdateWithoutWebsitesInput>
  }

  export type UserUpdateWithoutWebsitesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUpdateManyWithoutUserNestedInput
    domains?: DomainUpdateManyWithoutUserNestedInput
    hosting?: HostingUpdateManyWithoutUserNestedInput
    sessions?: SessionUpdateManyWithoutUserNestedInput
    vps?: VPSUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutWebsitesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUncheckedUpdateManyWithoutUserNestedInput
    domains?: DomainUncheckedUpdateManyWithoutUserNestedInput
    hosting?: HostingUncheckedUpdateManyWithoutUserNestedInput
    sessions?: SessionUncheckedUpdateManyWithoutUserNestedInput
    vps?: VPSUncheckedUpdateManyWithoutUserNestedInput
  }

  export type DomainUpsertWithoutWebsitesInput = {
    update: XOR<DomainUpdateWithoutWebsitesInput, DomainUncheckedUpdateWithoutWebsitesInput>
    create: XOR<DomainCreateWithoutWebsitesInput, DomainUncheckedCreateWithoutWebsitesInput>
    where?: DomainWhereInput
  }

  export type DomainUpdateToOneWithWhereWithoutWebsitesInput = {
    where?: DomainWhereInput
    data: XOR<DomainUpdateWithoutWebsitesInput, DomainUncheckedUpdateWithoutWebsitesInput>
  }

  export type DomainUpdateWithoutWebsitesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutDomainNestedInput
    user?: UserUpdateOneRequiredWithoutDomainsNestedInput
    hosting?: HostingUpdateOneWithoutDomainsNestedInput
    vps?: VPSUpdateOneWithoutDomainsNestedInput
  }

  export type DomainUncheckedUpdateWithoutWebsitesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutDomainNestedInput
  }

  export type HostingUpsertWithoutWebsitesInput = {
    update: XOR<HostingUpdateWithoutWebsitesInput, HostingUncheckedUpdateWithoutWebsitesInput>
    create: XOR<HostingCreateWithoutWebsitesInput, HostingUncheckedCreateWithoutWebsitesInput>
    where?: HostingWhereInput
  }

  export type HostingUpdateToOneWithWhereWithoutWebsitesInput = {
    where?: HostingWhereInput
    data: XOR<HostingUpdateWithoutWebsitesInput, HostingUncheckedUpdateWithoutWebsitesInput>
  }

  export type HostingUpdateWithoutWebsitesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUpdateManyWithoutHostingNestedInput
    domains?: DomainUpdateManyWithoutHostingNestedInput
    user?: UserUpdateOneRequiredWithoutHostingNestedInput
  }

  export type HostingUncheckedUpdateWithoutWebsitesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    activities?: ActivityLogUncheckedUpdateManyWithoutHostingNestedInput
    domains?: DomainUncheckedUpdateManyWithoutHostingNestedInput
  }

  export type VPSUpsertWithoutWebsitesInput = {
    update: XOR<VPSUpdateWithoutWebsitesInput, VPSUncheckedUpdateWithoutWebsitesInput>
    create: XOR<VPSCreateWithoutWebsitesInput, VPSUncheckedCreateWithoutWebsitesInput>
    where?: VPSWhereInput
  }

  export type VPSUpdateToOneWithWhereWithoutWebsitesInput = {
    where?: VPSWhereInput
    data: XOR<VPSUpdateWithoutWebsitesInput, VPSUncheckedUpdateWithoutWebsitesInput>
  }

  export type VPSUpdateWithoutWebsitesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutVpsNestedInput
    domains?: DomainUpdateManyWithoutVpsNestedInput
    user?: UserUpdateOneRequiredWithoutVpsNestedInput
  }

  export type VPSUncheckedUpdateWithoutWebsitesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutVpsNestedInput
    domains?: DomainUncheckedUpdateManyWithoutVpsNestedInput
  }

  export type DomainCreateWithoutActivitiesInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    isMainDomain?: boolean
    domainHosting?: string | null
    user: UserCreateNestedOneWithoutDomainsInput
    hosting?: HostingCreateNestedOneWithoutDomainsInput
    vps?: VPSCreateNestedOneWithoutDomainsInput
    websites?: WebsiteCreateNestedManyWithoutDomainInput
  }

  export type DomainUncheckedCreateWithoutActivitiesInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    hostingId?: string | null
    vpsId?: string | null
    isMainDomain?: boolean
    domainHosting?: string | null
    websites?: WebsiteUncheckedCreateNestedManyWithoutDomainInput
  }

  export type DomainCreateOrConnectWithoutActivitiesInput = {
    where: DomainWhereUniqueInput
    create: XOR<DomainCreateWithoutActivitiesInput, DomainUncheckedCreateWithoutActivitiesInput>
  }

  export type HostingCreateWithoutActivitiesInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    domains?: DomainCreateNestedManyWithoutHostingInput
    user: UserCreateNestedOneWithoutHostingInput
    websites?: WebsiteCreateNestedManyWithoutHostingInput
  }

  export type HostingUncheckedCreateWithoutActivitiesInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    domains?: DomainUncheckedCreateNestedManyWithoutHostingInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutHostingInput
  }

  export type HostingCreateOrConnectWithoutActivitiesInput = {
    where: HostingWhereUniqueInput
    create: XOR<HostingCreateWithoutActivitiesInput, HostingUncheckedCreateWithoutActivitiesInput>
  }

  export type UserCreateWithoutActivitiesInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    domains?: DomainCreateNestedManyWithoutUserInput
    hosting?: HostingCreateNestedManyWithoutUserInput
    sessions?: SessionCreateNestedManyWithoutUserInput
    vps?: VPSCreateNestedManyWithoutUserInput
    websites?: WebsiteCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutActivitiesInput = {
    id?: string
    email: string
    password: string
    name?: string | null
    role?: $Enums.UserRole
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    domains?: DomainUncheckedCreateNestedManyWithoutUserInput
    hosting?: HostingUncheckedCreateNestedManyWithoutUserInput
    sessions?: SessionUncheckedCreateNestedManyWithoutUserInput
    vps?: VPSUncheckedCreateNestedManyWithoutUserInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutActivitiesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutActivitiesInput, UserUncheckedCreateWithoutActivitiesInput>
  }

  export type VPSCreateWithoutActivitiesInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    cpanelUrl?: string | null
    domains?: DomainCreateNestedManyWithoutVpsInput
    user: UserCreateNestedOneWithoutVpsInput
    websites?: WebsiteCreateNestedManyWithoutVpsInput
  }

  export type VPSUncheckedCreateWithoutActivitiesInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    cpanelUrl?: string | null
    domains?: DomainUncheckedCreateNestedManyWithoutVpsInput
    websites?: WebsiteUncheckedCreateNestedManyWithoutVpsInput
  }

  export type VPSCreateOrConnectWithoutActivitiesInput = {
    where: VPSWhereUniqueInput
    create: XOR<VPSCreateWithoutActivitiesInput, VPSUncheckedCreateWithoutActivitiesInput>
  }

  export type WebsiteCreateWithoutActivitiesInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    password?: string | null
    username?: string | null
    user: UserCreateNestedOneWithoutWebsitesInput
    domain?: DomainCreateNestedOneWithoutWebsitesInput
    hosting?: HostingCreateNestedOneWithoutWebsitesInput
    vps?: VPSCreateNestedOneWithoutWebsitesInput
  }

  export type WebsiteUncheckedCreateWithoutActivitiesInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    domainId?: string | null
    hostingId?: string | null
    vpsId?: string | null
    password?: string | null
    username?: string | null
  }

  export type WebsiteCreateOrConnectWithoutActivitiesInput = {
    where: WebsiteWhereUniqueInput
    create: XOR<WebsiteCreateWithoutActivitiesInput, WebsiteUncheckedCreateWithoutActivitiesInput>
  }

  export type DomainUpsertWithoutActivitiesInput = {
    update: XOR<DomainUpdateWithoutActivitiesInput, DomainUncheckedUpdateWithoutActivitiesInput>
    create: XOR<DomainCreateWithoutActivitiesInput, DomainUncheckedCreateWithoutActivitiesInput>
    where?: DomainWhereInput
  }

  export type DomainUpdateToOneWithWhereWithoutActivitiesInput = {
    where?: DomainWhereInput
    data: XOR<DomainUpdateWithoutActivitiesInput, DomainUncheckedUpdateWithoutActivitiesInput>
  }

  export type DomainUpdateWithoutActivitiesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    user?: UserUpdateOneRequiredWithoutDomainsNestedInput
    hosting?: HostingUpdateOneWithoutDomainsNestedInput
    vps?: VPSUpdateOneWithoutDomainsNestedInput
    websites?: WebsiteUpdateManyWithoutDomainNestedInput
  }

  export type DomainUncheckedUpdateWithoutActivitiesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    websites?: WebsiteUncheckedUpdateManyWithoutDomainNestedInput
  }

  export type HostingUpsertWithoutActivitiesInput = {
    update: XOR<HostingUpdateWithoutActivitiesInput, HostingUncheckedUpdateWithoutActivitiesInput>
    create: XOR<HostingCreateWithoutActivitiesInput, HostingUncheckedCreateWithoutActivitiesInput>
    where?: HostingWhereInput
  }

  export type HostingUpdateToOneWithWhereWithoutActivitiesInput = {
    where?: HostingWhereInput
    data: XOR<HostingUpdateWithoutActivitiesInput, HostingUncheckedUpdateWithoutActivitiesInput>
  }

  export type HostingUpdateWithoutActivitiesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domains?: DomainUpdateManyWithoutHostingNestedInput
    user?: UserUpdateOneRequiredWithoutHostingNestedInput
    websites?: WebsiteUpdateManyWithoutHostingNestedInput
  }

  export type HostingUncheckedUpdateWithoutActivitiesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    domains?: DomainUncheckedUpdateManyWithoutHostingNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutHostingNestedInput
  }

  export type UserUpsertWithoutActivitiesInput = {
    update: XOR<UserUpdateWithoutActivitiesInput, UserUncheckedUpdateWithoutActivitiesInput>
    create: XOR<UserCreateWithoutActivitiesInput, UserUncheckedCreateWithoutActivitiesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutActivitiesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutActivitiesInput, UserUncheckedUpdateWithoutActivitiesInput>
  }

  export type UserUpdateWithoutActivitiesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domains?: DomainUpdateManyWithoutUserNestedInput
    hosting?: HostingUpdateManyWithoutUserNestedInput
    sessions?: SessionUpdateManyWithoutUserNestedInput
    vps?: VPSUpdateManyWithoutUserNestedInput
    websites?: WebsiteUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutActivitiesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumUserRoleFieldUpdateOperationsInput | $Enums.UserRole
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domains?: DomainUncheckedUpdateManyWithoutUserNestedInput
    hosting?: HostingUncheckedUpdateManyWithoutUserNestedInput
    sessions?: SessionUncheckedUpdateManyWithoutUserNestedInput
    vps?: VPSUncheckedUpdateManyWithoutUserNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutUserNestedInput
  }

  export type VPSUpsertWithoutActivitiesInput = {
    update: XOR<VPSUpdateWithoutActivitiesInput, VPSUncheckedUpdateWithoutActivitiesInput>
    create: XOR<VPSCreateWithoutActivitiesInput, VPSUncheckedCreateWithoutActivitiesInput>
    where?: VPSWhereInput
  }

  export type VPSUpdateToOneWithWhereWithoutActivitiesInput = {
    where?: VPSWhereInput
    data: XOR<VPSUpdateWithoutActivitiesInput, VPSUncheckedUpdateWithoutActivitiesInput>
  }

  export type VPSUpdateWithoutActivitiesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    domains?: DomainUpdateManyWithoutVpsNestedInput
    user?: UserUpdateOneRequiredWithoutVpsNestedInput
    websites?: WebsiteUpdateManyWithoutVpsNestedInput
  }

  export type VPSUncheckedUpdateWithoutActivitiesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    domains?: DomainUncheckedUpdateManyWithoutVpsNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutVpsNestedInput
  }

  export type WebsiteUpsertWithoutActivitiesInput = {
    update: XOR<WebsiteUpdateWithoutActivitiesInput, WebsiteUncheckedUpdateWithoutActivitiesInput>
    create: XOR<WebsiteCreateWithoutActivitiesInput, WebsiteUncheckedCreateWithoutActivitiesInput>
    where?: WebsiteWhereInput
  }

  export type WebsiteUpdateToOneWithWhereWithoutActivitiesInput = {
    where?: WebsiteWhereInput
    data: XOR<WebsiteUpdateWithoutActivitiesInput, WebsiteUncheckedUpdateWithoutActivitiesInput>
  }

  export type WebsiteUpdateWithoutActivitiesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    user?: UserUpdateOneRequiredWithoutWebsitesNestedInput
    domain?: DomainUpdateOneWithoutWebsitesNestedInput
    hosting?: HostingUpdateOneWithoutWebsitesNestedInput
    vps?: VPSUpdateOneWithoutWebsitesNestedInput
  }

  export type WebsiteUncheckedUpdateWithoutActivitiesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogCreateManyUserInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    domainId?: string | null
    hostingId?: string | null
    vpsId?: string | null
    websiteId?: string | null
  }

  export type DomainCreateManyUserInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    hostingId?: string | null
    vpsId?: string | null
    isMainDomain?: boolean
    domainHosting?: string | null
  }

  export type HostingCreateManyUserInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.HostingStatus
    planName?: string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SessionCreateManyUserInput = {
    id?: string
    sessionToken: string
    expires: Date | string
    createdAt?: Date | string
  }

  export type VPSCreateManyUserInput = {
    id?: string
    name: string
    provider: string
    status?: $Enums.VPSStatus
    ipAddress?: string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: number | null
    sshKey?: string | null
    username?: string | null
    password?: string | null
    expiresAt?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    cpanelUrl?: string | null
  }

  export type WebsiteCreateManyUserInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    domainId?: string | null
    hostingId?: string | null
    vpsId?: string | null
    password?: string | null
    username?: string | null
  }

  export type ActivityLogUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domain?: DomainUpdateOneWithoutActivitiesNestedInput
    hosting?: HostingUpdateOneWithoutActivitiesNestedInput
    vps?: VPSUpdateOneWithoutActivitiesNestedInput
    website?: WebsiteUpdateOneWithoutActivitiesNestedInput
  }

  export type ActivityLogUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    websiteId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    websiteId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type DomainUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutDomainNestedInput
    hosting?: HostingUpdateOneWithoutDomainsNestedInput
    vps?: VPSUpdateOneWithoutDomainsNestedInput
    websites?: WebsiteUpdateManyWithoutDomainNestedInput
  }

  export type DomainUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutDomainNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutDomainNestedInput
  }

  export type DomainUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type HostingUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUpdateManyWithoutHostingNestedInput
    domains?: DomainUpdateManyWithoutHostingNestedInput
    websites?: WebsiteUpdateManyWithoutHostingNestedInput
  }

  export type HostingUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    activities?: ActivityLogUncheckedUpdateManyWithoutHostingNestedInput
    domains?: DomainUncheckedUpdateManyWithoutHostingNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutHostingNestedInput
  }

  export type HostingUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumHostingStatusFieldUpdateOperationsInput | $Enums.HostingStatus
    planName?: NullableStringFieldUpdateOperationsInput | string | null
    resources?: NullableJsonNullValueInput | InputJsonValue
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SessionUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SessionUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SessionUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VPSUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutVpsNestedInput
    domains?: DomainUpdateManyWithoutVpsNestedInput
    websites?: WebsiteUpdateManyWithoutVpsNestedInput
  }

  export type VPSUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutVpsNestedInput
    domains?: DomainUncheckedUpdateManyWithoutVpsNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutVpsNestedInput
  }

  export type VPSUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    status?: EnumVPSStatusFieldUpdateOperationsInput | $Enums.VPSStatus
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    specs?: NullableJsonNullValueInput | InputJsonValue
    sshPort?: NullableIntFieldUpdateOperationsInput | number | null
    sshKey?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    cpanelUrl?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type WebsiteUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutWebsiteNestedInput
    domain?: DomainUpdateOneWithoutWebsitesNestedInput
    hosting?: HostingUpdateOneWithoutWebsitesNestedInput
    vps?: VPSUpdateOneWithoutWebsitesNestedInput
  }

  export type WebsiteUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutWebsiteNestedInput
  }

  export type WebsiteUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogCreateManyDomainInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    userId: string
    hostingId?: string | null
    vpsId?: string | null
    websiteId?: string | null
  }

  export type WebsiteCreateManyDomainInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    hostingId?: string | null
    vpsId?: string | null
    password?: string | null
    username?: string | null
  }

  export type ActivityLogUpdateWithoutDomainInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    hosting?: HostingUpdateOneWithoutActivitiesNestedInput
    user?: UserUpdateOneRequiredWithoutActivitiesNestedInput
    vps?: VPSUpdateOneWithoutActivitiesNestedInput
    website?: WebsiteUpdateOneWithoutActivitiesNestedInput
  }

  export type ActivityLogUncheckedUpdateWithoutDomainInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    websiteId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogUncheckedUpdateManyWithoutDomainInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    websiteId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type WebsiteUpdateWithoutDomainInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutWebsiteNestedInput
    user?: UserUpdateOneRequiredWithoutWebsitesNestedInput
    hosting?: HostingUpdateOneWithoutWebsitesNestedInput
    vps?: VPSUpdateOneWithoutWebsitesNestedInput
  }

  export type WebsiteUncheckedUpdateWithoutDomainInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutWebsiteNestedInput
  }

  export type WebsiteUncheckedUpdateManyWithoutDomainInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogCreateManyHostingInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    userId: string
    domainId?: string | null
    vpsId?: string | null
    websiteId?: string | null
  }

  export type DomainCreateManyHostingInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    vpsId?: string | null
    isMainDomain?: boolean
    domainHosting?: string | null
  }

  export type WebsiteCreateManyHostingInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    domainId?: string | null
    vpsId?: string | null
    password?: string | null
    username?: string | null
  }

  export type ActivityLogUpdateWithoutHostingInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domain?: DomainUpdateOneWithoutActivitiesNestedInput
    user?: UserUpdateOneRequiredWithoutActivitiesNestedInput
    vps?: VPSUpdateOneWithoutActivitiesNestedInput
    website?: WebsiteUpdateOneWithoutActivitiesNestedInput
  }

  export type ActivityLogUncheckedUpdateWithoutHostingInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    websiteId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogUncheckedUpdateManyWithoutHostingInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    websiteId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type DomainUpdateWithoutHostingInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutDomainNestedInput
    user?: UserUpdateOneRequiredWithoutDomainsNestedInput
    vps?: VPSUpdateOneWithoutDomainsNestedInput
    websites?: WebsiteUpdateManyWithoutDomainNestedInput
  }

  export type DomainUncheckedUpdateWithoutHostingInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutDomainNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutDomainNestedInput
  }

  export type DomainUncheckedUpdateManyWithoutHostingInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type WebsiteUpdateWithoutHostingInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutWebsiteNestedInput
    user?: UserUpdateOneRequiredWithoutWebsitesNestedInput
    domain?: DomainUpdateOneWithoutWebsitesNestedInput
    vps?: VPSUpdateOneWithoutWebsitesNestedInput
  }

  export type WebsiteUncheckedUpdateWithoutHostingInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutWebsiteNestedInput
  }

  export type WebsiteUncheckedUpdateManyWithoutHostingInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogCreateManyVpsInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    userId: string
    domainId?: string | null
    hostingId?: string | null
    websiteId?: string | null
  }

  export type DomainCreateManyVpsInput = {
    id?: string
    name: string
    registrar?: string | null
    status?: $Enums.DomainStatus
    registeredAt?: Date | string | null
    expiresAt?: Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    hostingId?: string | null
    isMainDomain?: boolean
    domainHosting?: string | null
  }

  export type WebsiteCreateManyVpsInput = {
    id?: string
    name: string
    url?: string | null
    status?: $Enums.WebsiteStatus
    cms?: string | null
    cmsVersion?: string | null
    phpVersion?: string | null
    sslStatus?: $Enums.SSLStatus
    sslExpiry?: Date | string | null
    backupStatus?: string | null
    lastBackup?: Date | string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    createdBy: string
    domainId?: string | null
    hostingId?: string | null
    password?: string | null
    username?: string | null
  }

  export type ActivityLogUpdateWithoutVpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domain?: DomainUpdateOneWithoutActivitiesNestedInput
    hosting?: HostingUpdateOneWithoutActivitiesNestedInput
    user?: UserUpdateOneRequiredWithoutActivitiesNestedInput
    website?: WebsiteUpdateOneWithoutActivitiesNestedInput
  }

  export type ActivityLogUncheckedUpdateWithoutVpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    websiteId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogUncheckedUpdateManyWithoutVpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    websiteId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type DomainUpdateWithoutVpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutDomainNestedInput
    user?: UserUpdateOneRequiredWithoutDomainsNestedInput
    hosting?: HostingUpdateOneWithoutDomainsNestedInput
    websites?: WebsiteUpdateManyWithoutDomainNestedInput
  }

  export type DomainUncheckedUpdateWithoutVpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutDomainNestedInput
    websites?: WebsiteUncheckedUpdateManyWithoutDomainNestedInput
  }

  export type DomainUncheckedUpdateManyWithoutVpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    registrar?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumDomainStatusFieldUpdateOperationsInput | $Enums.DomainStatus
    registeredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    nameservers?: NullableJsonNullValueInput | InputJsonValue
    whoisData?: NullableJsonNullValueInput | InputJsonValue
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    isMainDomain?: BoolFieldUpdateOperationsInput | boolean
    domainHosting?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type WebsiteUpdateWithoutVpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUpdateManyWithoutWebsiteNestedInput
    user?: UserUpdateOneRequiredWithoutWebsitesNestedInput
    domain?: DomainUpdateOneWithoutWebsitesNestedInput
    hosting?: HostingUpdateOneWithoutWebsitesNestedInput
  }

  export type WebsiteUncheckedUpdateWithoutVpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
    activities?: ActivityLogUncheckedUpdateManyWithoutWebsiteNestedInput
  }

  export type WebsiteUncheckedUpdateManyWithoutVpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    url?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumWebsiteStatusFieldUpdateOperationsInput | $Enums.WebsiteStatus
    cms?: NullableStringFieldUpdateOperationsInput | string | null
    cmsVersion?: NullableStringFieldUpdateOperationsInput | string | null
    phpVersion?: NullableStringFieldUpdateOperationsInput | string | null
    sslStatus?: EnumSSLStatusFieldUpdateOperationsInput | $Enums.SSLStatus
    sslExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    backupStatus?: NullableStringFieldUpdateOperationsInput | string | null
    lastBackup?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    username?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogCreateManyWebsiteInput = {
    id?: string
    action: $Enums.ActivityType
    entity: $Enums.EntityType
    entityId: string
    description: string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: string | null
    userAgent?: string | null
    createdAt?: Date | string
    userId: string
    domainId?: string | null
    hostingId?: string | null
    vpsId?: string | null
  }

  export type ActivityLogUpdateWithoutWebsiteInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    domain?: DomainUpdateOneWithoutActivitiesNestedInput
    hosting?: HostingUpdateOneWithoutActivitiesNestedInput
    user?: UserUpdateOneRequiredWithoutActivitiesNestedInput
    vps?: VPSUpdateOneWithoutActivitiesNestedInput
  }

  export type ActivityLogUncheckedUpdateWithoutWebsiteInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ActivityLogUncheckedUpdateManyWithoutWebsiteInput = {
    id?: StringFieldUpdateOperationsInput | string
    action?: EnumActivityTypeFieldUpdateOperationsInput | $Enums.ActivityType
    entity?: EnumEntityTypeFieldUpdateOperationsInput | $Enums.EntityType
    entityId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    metadata?: NullableJsonNullValueInput | InputJsonValue
    ipAddress?: NullableStringFieldUpdateOperationsInput | string | null
    userAgent?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userId?: StringFieldUpdateOperationsInput | string
    domainId?: NullableStringFieldUpdateOperationsInput | string | null
    hostingId?: NullableStringFieldUpdateOperationsInput | string | null
    vpsId?: NullableStringFieldUpdateOperationsInput | string | null
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}